# D06 local evidence selection and confirmation: host evidence

Run the unchanged repository verifier:
python3 scripts/verify-image-grid-evidence.py docs/evidence/d06-evidence-selection-host.zip --repo-root .
Or run this archive's verify.py against the ZIP; no extraction, SDK or network needed.

closure/ contains original XML, captures, exact methods, verified report and all
source-input bytes from the final 941-method JVM run (925 accepted + 16 new).
The real execution HEAD precedes committing the tested changes; the input fingerprint
and final Git blob byte comparison, rather than HEAD alone, bind the tested code.
File nanosecond mtimes are in file-times.json because ZIP metadata cannot preserve them.
The earlier targeted 15/15 pass is logged separately and is not additive coverage.

current-python/tests.log is this slice's actual rerun of 151 cases (no new methods).
Historical queue 149 / historical Python 151 are copied unchanged from the accepted
base evidence to support the existing verifier; they are not additive new coverage.
Queue 149 was not rerun. method-delta.json lists the 16 new unique JVM methods.

Only local selection/confirmation over the existing candidates and SQL proof.
The synthetic provider is an in-memory recorder with no HTTP or secret resolver.
No real or sendable remote request is produced. No new schema, dependency,
credential, permission or consent/SDK acceptance. The read-only SDK preflight FAIL
is preserved. Android/Room/SQLCipher/Compose/Preview/device/performance gates remain
NOT RUN, no new APK, no Actions access or deployment, new CI unknown.
