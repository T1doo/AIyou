from pathlib import Path
import json,subprocess
root=Path('/workspace/AIyou');ev=Path('/workspace/scratch/aiyou-readonly-capability-audit-20261017')
cache=root/'.toolchains/gradle-home/caches/modules-2/files-2.1'
compiler=[]
for line in(root/'checks/ai-protocol/remote-text/gradle.lockfile').read_text().splitlines():
    if line.startswith('#')or '='not in line:continue
    coord,conf=line.split('=',1)
    if 'kotlinCompilerClasspath'not in conf.split(',')or coord=='empty':continue
    group,module,ver=coord.split(':');compiler+=sorted((cache/group/module/ver).glob('*/*.jar'))
assert compiler
runtime=json.loads(Path('/workspace/scratch/aiyou-people-open-generation-20261017/readonly-probe-classpath.json').read_text())
assert all((root/path).exists()for path in runtime)
cp=':'.join(str(root/path)for path in runtime);compiler_cp=':'.join(map(str,compiler))
java=root/'.toolchains/jdk-17.0.17+10/bin/java';assert java.is_file()
output=ev/'classes';output.mkdir(exist_ok=False)
friends=','.join(str(root/path)for path in('checks/ai-protocol/remote-text/build/classes/kotlin/main','checks/ai-protocol/remote-text/build/classes/kotlin/test'))
with(ev/'probe.log').open('w')as log:
    result=subprocess.run([str(java),'-cp',compiler_cp,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',cp,'-Xfriend-paths='+friends,'-jvm-target','17','-d',str(output),str(ev/'ReadonlyCaptureDiscardProbe.kt')],stdout=log,stderr=subprocess.STDOUT,timeout=90)
    log.write('COMPILE_EXIT='+str(result.returncode)+'\n');log.flush()
    if result.returncode:print((ev/'probe.log').read_text());raise SystemExit(result.returncode)
    result=subprocess.run([str(java),'-cp',str(output)+':'+cp,'com.t1doo.aiyou.records.ReadonlyCaptureDiscardProbeKt'],stdout=log,stderr=subprocess.STDOUT,timeout=90)
    log.write('RUN_EXIT='+str(result.returncode)+'\n');log.flush()
print((ev/'probe.log').read_text());raise SystemExit(result.returncode)
