package com.t1doo.aiyou.records

import com.t1doo.aiyou.data.*
import com.t1doo.aiyou.domain.*
import java.time.Clock
import kotlinx.coroutines.runBlocking

/** Scratch only: uses current compiled controller/SQL on an owned synthetic fixture. */
fun main()=runBlocking {
    for(mode in listOf("lost-discard-ack","cleanup-io-failure")) {
        MixedCaptureSqlTest.fixture().use { f ->
            val repo=MixedCaptureSqlTest.repo(f)
            var local=LocalRecordUiState(ready=true,opening=false,supportsMixedCapture=true,mixedCapture=MixedCaptureUiState())
            val queue=ArrayDeque<suspend(EntryRepository)->Unit>()
            var loseAck=mode=="lost-discard-ack"
            val store=object:EntryRepository {
                override val captureRecords=object:CaptureRepository by repo {
                    override suspend fun discard(draftId:String):com.t1doo.aiyou.model.CaptureDraft {
                        val result=repo.discard(draftId)
                        if(loseAck){loseAck=false;error("Synthetic lost discard ACK after actual commit")}
                        return result
                    }
                }
                override val manualTags=f.tags
                override suspend fun entries()=emptyList<com.t1doo.aiyou.model.StoredEntry>()
                override suspend fun readDraft():com.t1doo.aiyou.model.TextDraft?=null
                override suspend fun updateDraft(text:String):com.t1doo.aiyou.model.TextDraft=error("unused")
                override suspend fun saveDraft(expected:com.t1doo.aiyou.model.TextDraft,capturedAtMillis:Long,captureTimeZone:String):com.t1doo.aiyou.model.StoredEntry=error("unused")
                override suspend fun revisions(entryId:String)=emptyList<com.t1doo.aiyou.model.OriginalRevision>()
                override suspend fun revise(entryId:String,expectedRevision:Int,text:String,createdAtMillis:Long):com.t1doo.aiyou.model.StoredEntry=error("unused")
            }
            val controller=MixedCaptureController({local},{local=it(local)},{queue.add(it);true},
                {object:AttachmentPicture{override val width=1;override val height=1}},Clock.systemUTC())
            suspend fun drain(){while(queue.isNotEmpty())queue.removeFirst()(store)}
            fun ui()=checkNotNull(local.mixedCapture)
            controller.initialize(store);controller.edit("合成原草稿");drain()
            if(mode=="cleanup-io-failure") {
                controller.select();val s=ui().selection!!;check(controller.claimPicker(s.requestId))
                controller.selected(s.requestId,object:SelectedImageSource {
                    override fun mediaType()="image/png"
                    override fun open()=MixedCaptureSqlTest.png.inputStream()
                });drain();check(ui().draft!!.images.size==1)
                var once=true
                f.mediaCheckpoint={if(it=="package-cleaned"&&once){once=false;error("Synthetic actual cleanup IO failure")}}
            }
            val oldId=ui().draft!!.id
            controller.requestDiscard();check(ui().confirmDiscard);controller.confirmDiscard();drain()
            check(ui().error!=null&&!ui().busy&&ui().confirmDiscard)
            check(ui().draft!!.id==oldId&&!ui().draft!!.discarding)
            controller.cancelDiscard()
            check(!ui().confirmDiscard&&!ui().busy&&ui().selection==null&&!ui().uncertainSave&&!ui().draft!!.discarding)
            controller.edit("合成点击继续编辑后的新输入");drain()
            check(ui().text=="合成点击继续编辑后的新输入"&&ui().error!=null)
            controller.refresh();drain()
            val durable=repo.current()
            check(durable.id!=oldId&&durable.text.isEmpty())
            check(ui().draft!!.id==oldId&&ui().text=="合成点击继续编辑后的新输入"&&ui().error!=null)
            controller.save();drain()
            check(ui().error!=null&&!ui().busy)
            check(f.db.read("SELECT id FROM entries").isEmpty())
            check(repo.current().text.isEmpty())
            println("$mode: REPRODUCED; continue-edit+refresh+save leaves stale UI identity, new text only in memory, DB fresh empty, zero saved entries")
            // Existing original-clear replay still works if the user explicitly chooses to clear again.
            controller.requestDiscard();controller.confirmDiscard();drain()
            check(ui().draft!!.id==durable.id&&ui().text.isEmpty()&&ui().error==null)
            println("$mode: POSITIVE; explicitly reconfirming original clear recovers current identity, no old record resurrection")
            controller.dispose();drain();controller.disposeOnIo()
        }
    }
}
