# F01: verify the same confirmed draft clear before accepting more input

Verify with the unchanged repository portable verifier:
python3 scripts/verify-image-grid-evidence.py docs/evidence/f01-capture-discard-recovery-host.zip --repo-root .

1018 actual unique JVM methods = accepted8e45 baseline1013 plus5. No previous method
removed, zero failures/errors/skips, one complete run and no full retry. Actual source
bytes/captures/raw XML/nanosecond times and inventories are bound to this final cohort.
Final staged and committed Git blob comparisons are recorded outside the archive.
Historical queue149/Python151 are retained only, neither rerun in this slice.

Read-only baseline probe used actual8e45 controller/SQL with owned synthetic fixtures.
Both lost discard ACK after real commit and a real encrypted-image cleanup checkpoint
failure reproduced: closing the prompt said continue editing, allowed new text/picker,
then refresh/save stayed on old draft identity. New input remained in RAM, not durable.
NO saved-record loss is claimed. Same original clear retry already worked; this remains
positive. The probe, source, current-plan capability matrix and log are retained.

Initial new fixture compilation failed anonymous inferred store type, before any tests.
The explicit interface annotation fixed it; snapshot assertions compare all value fields
because CaptureDraft intentionally has identity semantics. No old test or deadline was
changed. The actual baseline5 methods then had3 failures and2 positives, raw XML preserved.

The controller now freezes the original clear snapshot. Until the existing repository
acknowledges that same identity, editing/image/removal/metadata/save actions pause.
Closing the prompt means later verification, not continued editing. The persistent
visible retry and normal refresh both replay only the original clear. No blanket draft
identity adoption, schema, SQL mutation/receipt, media deletion rule or restore path changes.
A first queue rejection is known not executed, so normal cancel/edit remain available.
A newer durable draft returned by original-clear replay is displayed without clearing or
overwriting it. Ordinary unrelated refresh still rejects an unowned replacement.

The new actual VM test demonstrates lost ACK, blocked premature input, explicit refresh,
same original ID twice, then a successful new LOCAL_ONLY save. Other actual controller/SQL
methods exercise image cleanup failure, blocked actions, exact replay/current newer-draft
preservation, queue rejection and unrelated-owner positive. Corrected targeted16 pass.
The Compose source adds one exact-inventory method for the real Now visible retry at
320dp/200%font with controlled storage. NONE of the5 Compose source methods was compiled
or run. Click/IME/scroll/Preview/device behavior remains NOT RUN, no new APK.

Capabilities are not all waiting only for SDK: raw-audio storage accepts MIME internally
but recording/ASR UI/pipeline is absent; OCR engine/source-map/index pipeline is absent;
reminder encrypted plan/outbox/version gates exist but actual OS driver/receivers and
permission flows are missing; two text protocols/SSE/consent/source sending exist but
production model/secret configuration and Activity provider wiring are absent. Synthetic
answer provider is test-only, not a real multi-source authorization or semantic proof.
Original-plan sections and exact source preconditions are in readonly-audit JSON.

No new schema/domain/model API, dependency, permission, live model, secret, fee, workflow,
network permission, plaintext cache or deployment. Both original plans and previous ZIPs
are unchanged. Existing SDK diagnosis retained without repetition; no terms/download or
configuration. Real KSP11 then12 committed exports/fixtures, Room/SQLCipher, Android build,
Compose/Preview/device acceptance remain blocked/unrun. Notification permissions and live
models remain unapproved. Parent original email reported246/cd5/771 Android CI FAIL, cause
UNKNOWN;8e45 and new commit CI UNKNOWN. No Actions or alternate access. Old AI preparation
failure root remains UNKNOWN; original logs/archives unchanged. Parent independent review
of this slice is pending.
