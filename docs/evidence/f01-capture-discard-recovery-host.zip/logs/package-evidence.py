from pathlib import Path
import ast, hashlib, json, zipfile, datetime, subprocess

root=Path('/workspace/AIyou')
evidence=Path('/workspace/scratch/aiyou-capture-discard-recovery-20261017')
base='8e45ea49d71299b4cf2a734766c091df06a7055c'
items={}
def add(name,data):
    assert name not in items,name
    items[name]=data
def file(name,path):add(name,Path(path).read_bytes())
def document(name,value):add(name,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())

paths=[]
class Recorder:
    def __init__(self):self.h=hashlib.sha256();self.n=0
    def update(self,data):
        if self.n%2==0:
            assert data.endswith(b'\0')
            paths.append(data[:-1].decode())
        self.n+=1;self.h.update(data)
    def hexdigest(self):return self.h.hexdigest()
class RecordingHashlib:
    @staticmethod
    def sha256(data=None):return Recorder() if data is None else hashlib.sha256(data)
tree=ast.parse((root/'scripts/verify-ai-protocol-results.py').read_text())
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='input_fingerprint')
ns={'root':root,'hashlib':RecordingHashlib}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'<production fingerprint>','exec'),ns)
digest=ns['input_fingerprint']()
report=json.loads((evidence/'verified-contracts.json').read_text())
assert report['source_sha256']==digest and sum(m['tests']for m in report['results'])==1018
assert digest==json.loads((evidence/'full-inputs.json').read_text())['source_sha256']
for name in paths:file('closure/source-inputs/'+name,root/name)
file('closure/verified-report.json',evidence/'verified-contracts.json')
document('closure/methods.json',{r['module']:r['methods']for r in report['results']})
times={}
for module in report['results']:
    label=module['module'].split(':')[-1]
    folder=evidence/'raw-xml'/label
    path=folder/'inputs-at-test.json';key=f'closure/captures/{label}.json'
    file(key,path);times[key]=path.stat().st_mtime_ns
    for xml in module['xml']:
        path=folder/Path(xml['path']).name
        assert hashlib.sha256(path.read_bytes()).hexdigest()==xml['sha256']
        key=f'closure/xml/{label}/{path.name}';file(key,path);times[key]=path.stat().st_mtime_ns
document('closure/file-times.json',times)

old=root/'docs/evidence/f01-now-recent-records-host.zip'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='4febe42a7839b841048f63b97687da3a118e70494291d0eb66bfa3f8571ca935'
with zipfile.ZipFile(old)as z:
    for name in z.namelist():
        if name.startswith(('historical-queue/','historical-python/')):add(name,z.read(name))
    previous=json.loads(z.read('closure/verified-report.json'))
    before={tuple(c)for r in previous['results']for c in r['methods']}
    after={tuple(c)for r in report['results']for c in r['methods']}
    assert len(before)==1013 and before<=after and len(after-before)==5
    document('method-delta.json',{'base':base,'previous':1013,'current':1018,'added':sorted(after-before),'removed':[]})

for path in sorted(evidence.iterdir()):
    if path.is_file() and (path.suffix in ('.log','.json','.xml','.kt')or path.name.startswith('baseline-')or path.name=='package-evidence.py'):
        if path.name not in ('archive-receipt.json','verified-contracts.json','final-validation.json','writer-completed.json'):
            file('logs/'+path.name,path)
for path in sorted((evidence/'targeted-xml').glob('*.xml')):file('targeted/'+path.name,path)
audit=Path('/workspace/scratch/aiyou-readonly-capability-audit-20261017')
for path in sorted(audit.iterdir()):
    if path.is_file():file('readonly-audit/'+path.name,path)
native='app/src/test/kotlin/com/t1doo/aiyou/MixedCapturePresentationTest.kt'
file('uncompiled-native-source/'+native,root/native)
document('uncompiled-native-source/status.json',{'source':native,'status':'NOT COMPILED / NOT RUN','existing_methods_extended':0,'new_methods':1,'exact_inventory_added':'scripts/verify-test-results.py','claim':'No Android/Compose/device/UI result is inferred from host state tests'})
file('verify.py',root/'scripts/verify-image-grid-evidence.py')
add('README.md',b'# F01: verify the same confirmed draft clear before accepting more input\n\nVerify with the unchanged repository portable verifier:\npython3 scripts/verify-image-grid-evidence.py docs/evidence/f01-capture-discard-recovery-host.zip --repo-root .\n\n1018 actual unique JVM methods = accepted8e45 baseline1013 plus5. No previous method\nremoved, zero failures/errors/skips, one complete run and no full retry. Actual source\nbytes/captures/raw XML/nanosecond times and inventories are bound to this final cohort.\nFinal staged and committed Git blob comparisons are recorded outside the archive.\nHistorical queue149/Python151 are retained only, neither rerun in this slice.\n\nRead-only baseline probe used actual8e45 controller/SQL with owned synthetic fixtures.\nBoth lost discard ACK after real commit and a real encrypted-image cleanup checkpoint\nfailure reproduced: closing the prompt said continue editing, allowed new text/picker,\nthen refresh/save stayed on old draft identity. New input remained in RAM, not durable.\nNO saved-record loss is claimed. Same original clear retry already worked; this remains\npositive. The probe, source, current-plan capability matrix and log are retained.\n\nInitial new fixture compilation failed anonymous inferred store type, before any tests.\nThe explicit interface annotation fixed it; snapshot assertions compare all value fields\nbecause CaptureDraft intentionally has identity semantics. No old test or deadline was\nchanged. The actual baseline5 methods then had3 failures and2 positives, raw XML preserved.\n\nThe controller now freezes the original clear snapshot. Until the existing repository\nacknowledges that same identity, editing/image/removal/metadata/save actions pause.\nClosing the prompt means later verification, not continued editing. The persistent\nvisible retry and normal refresh both replay only the original clear. No blanket draft\nidentity adoption, schema, SQL mutation/receipt, media deletion rule or restore path changes.\nA first queue rejection is known not executed, so normal cancel/edit remain available.\nA newer durable draft returned by original-clear replay is displayed without clearing or\noverwriting it. Ordinary unrelated refresh still rejects an unowned replacement.\n\nThe new actual VM test demonstrates lost ACK, blocked premature input, explicit refresh,\nsame original ID twice, then a successful new LOCAL_ONLY save. Other actual controller/SQL\nmethods exercise image cleanup failure, blocked actions, exact replay/current newer-draft\npreservation, queue rejection and unrelated-owner positive. Corrected targeted16 pass.\nThe Compose source adds one exact-inventory method for the real Now visible retry at\n320dp/200%font with controlled storage. NONE of the5 Compose source methods was compiled\nor run. Click/IME/scroll/Preview/device behavior remains NOT RUN, no new APK.\n\nCapabilities are not all waiting only for SDK: raw-audio storage accepts MIME internally\nbut recording/ASR UI/pipeline is absent; OCR engine/source-map/index pipeline is absent;\nreminder encrypted plan/outbox/version gates exist but actual OS driver/receivers and\npermission flows are missing; two text protocols/SSE/consent/source sending exist but\nproduction model/secret configuration and Activity provider wiring are absent. Synthetic\nanswer provider is test-only, not a real multi-source authorization or semantic proof.\nOriginal-plan sections and exact source preconditions are in readonly-audit JSON.\n\nNo new schema/domain/model API, dependency, permission, live model, secret, fee, workflow,\nnetwork permission, plaintext cache or deployment. Both original plans and previous ZIPs\nare unchanged. Existing SDK diagnosis retained without repetition; no terms/download or\nconfiguration. Real KSP11 then12 committed exports/fixtures, Room/SQLCipher, Android build,\nCompose/Preview/device acceptance remain blocked/unrun. Notification permissions and live\nmodels remain unapproved. Parent original email reported246/cd5/771 Android CI FAIL, cause\nUNKNOWN;8e45 and new commit CI UNKNOWN. No Actions or alternate access. Old AI preparation\nfailure root remains UNKNOWN; original logs/archives unchanged. Parent independent review\nof this slice is pending.\n')
manifest={'format':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'cohorts':[{'id':'closure','source_prefix':'closure/source-inputs/','source_sha256':digest,
                      'tests':1018,'execution_git_head':report['head'],'source_git_base':base}],
          'python_rerun':False,'queue_rerun':False,
          'files':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for name,data in sorted(items.items())}}
document('manifest.json',manifest)
output=root/'docs/evidence/f01-capture-discard-recovery-host.zip'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for name,data in sorted(items.items()):z.writestr(name,data)
print(json.dumps({'archive':str(output),'bytes':output.stat().st_size,
                  'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'source_sha256':digest,
                  'source_inputs':len(paths),'zip_members':len(items),'methods':1018,'added':5,
                  'python_rerun':False,'queue_rerun':False},indent=2))
