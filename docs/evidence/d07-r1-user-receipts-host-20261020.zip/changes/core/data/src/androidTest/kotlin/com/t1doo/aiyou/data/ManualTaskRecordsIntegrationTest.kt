package com.t1doo.aiyou.data

import android.content.Context
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.t1doo.aiyou.domain.*
import com.t1doo.aiyou.model.*
import java.io.File
import java.util.UUID
import java.util.Base64
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith

/** Formal Room/SQLCipher contracts; compilation/DEX inventory is never device acceptance. */
@RunWith(AndroidJUnit4::class)
class ManualTaskRecordsIntegrationTest {
    @Test fun nativeV3PackageTransfersTasksAndDraftsAcrossEncryptedOwnersWithoutConfirmingOrRestoringConsent():Unit=runBlocking {
        val source=open();val entry=source.saveDraft(source.updateDraft("合成加密迁移原文与草稿"),50,"UTC")
        val choice=source.localProcessing.change(LocalProcessingChange(source.localProcessing.read(SourceVersion(entry.id,1)),LocalProcessingChoice.AI_NONE,"package-none"))
        val b=TaskSourceBinding(choice.source,choice.sourceHash,choice.generation,0,5)
        source.manualTasks.create(ManualTaskCreate("portable-native-task","合成迁移正式待办",60,"UTC","create",due("2026-11-01","01:30","America/New_York",ManualTaskOccurrence.SECOND)))
        source.taskProposals.write(TaskProposalWrite("portable-native-draft",0,b,"合成迁移待确认输入",ManualTaskDateInput("2026-"),60,"UTC",60,"draft"))
        val snapshot=source.originalExport.capture(listOf(SourceVersion(entry.id,1)),UUID.randomUUID().toString(),70)
        val out=java.io.ByteArrayOutputStream();val prepared=source.mediaPackages.seal(source.mediaPackages.previewActivities(snapshot),"synthetic native portable tasks".toCharArray())
        try {prepared.writeTo(out) {true}} finally {prepared.release()};source.closeAndAwait()
        val targetKey=ByteArray(32) {(it+87).toByte()};val targetFile=File(directory,"package-target.db")
        fun target()=EncryptedEntryRepository.openWithKey(context,targetFile,targetKey.copyOf()).also(stores::add)
        try {
            val first=target();val bytes=out.toByteArray();val copyId=UUID.randomUUID().toString()
            val verified=first.mediaPackages.open({bytes.inputStream()},"synthetic native portable tasks".toCharArray())
            try {
                assertTrue(first.manualTasks.snapshots().isEmpty());assertTrue(first.taskProposals.list().isEmpty())
                val result=first.mediaPackages.restore(verified,listOf(copyId),100)
                assertEquals(1,result.taskIds.size);assertEquals(1,result.proposalIds.size)
                assertEquals(ProcessingPolicy.AI_NONE,first.entries().single().policy)
                val draft=first.taskProposals.list().single();assertTrue(draft.sourceAvailable)
                assertEquals(SourceVersion(copyId,1),draft.proposal.binding.source);assertEquals(1L,draft.proposal.binding.generation)
                assertEquals("2026-",draft.proposal.dateInput.date);assertEquals(1,first.manualTasks.snapshots().size)
                assertEquals(-18000,first.manualTasks.snapshots().single().schedule!!.offsetSeconds)
                val task=first.manualTasks.snapshots().single();first.manualTasks.change(ManualTaskMutation(task.id,task.version,ManualTaskStatus.COMPLETED,110,"finish"))
            } finally {verified.release()};first.closeAndAwait()
            val cold=target();val reopened=cold.mediaPackages.open({bytes.inputStream()},"synthetic native portable tasks".toCharArray())
            try {assertTrue(cold.mediaPackages.restore(reopened,listOf(UUID.randomUUID().toString()),200).replayed)} finally {reopened.release()}
            assertEquals(ManualTaskStatus.COMPLETED,cold.manualTasks.snapshots().single().status);assertEquals(1,cold.taskProposals.list().size)
            val taskOnly=OriginalExportSnapshot(UUID.randomUUID().toString(),210,emptyList(),true)
            val tasksOut=java.io.ByteArrayOutputStream();val tasksPrepared=cold.mediaPackages.seal(cold.mediaPackages.previewActivities(taskOnly),"synthetic native portable tasks".toCharArray())
            try {tasksPrepared.writeTo(tasksOut) {true}} finally {tasksPrepared.release()}
            val third=EncryptedEntryRepository.openWithKey(context,File(directory,"task-only-target.db"),ByteArray(32) {(it+99).toByte()}).also(stores::add)
            val tasksPack=third.mediaPackages.open({tasksOut.toByteArray().inputStream()},"synthetic native portable tasks".toCharArray())
            try {
                assertTrue(third.mediaPackages.restore(tasksPack,emptyList(),220).ids.isEmpty())
                assertTrue(third.entries().isEmpty());assertEquals(1,third.manualTasks.snapshots().size)
                assertFalse(third.taskProposals.list().single().sourceAvailable)
            } finally {tasksPack.release()}
        } finally {targetKey.fill(0)}
    }
    @Test fun nativeTaskProposalColdDraftEditRejectAndAtomicConfirmationStaySeparate():Unit=runBlocking {
        val store=open();val entry=store.saveDraft(store.updateDraft("合成原文：明天三点只是引用"),50,"UTC")
        val source=SourceVersion(entry.id,1)
        val policy=store.localProcessing.change(LocalProcessingChange(store.localProcessing.read(source),LocalProcessingChoice.AI_NONE,"none"))
        val b=TaskSourceBinding(source,policy.sourceHash,policy.generation,0,5)
        val initial=TaskProposalWrite("native-proposal",0,b,"",ManualTaskDateInput("2026-"),60,"UTC",60,"draft")
        store.taskProposals.write(initial);assertTrue(store.manualTasks.snapshots().isEmpty());store.closeAndAwait()
        val cold=open();val restored=cold.taskProposals.list().single().proposal
        assertEquals("2026-",restored.dateInput.date);assertEquals("",restored.titleInput)
        val edited=cold.taskProposals.write(initial.copy(expectedVersion=1,titleInput="合成人工明确标题",dateInput=ManualTaskDateInput(),atMillis=70,mutationId="edit"))
        val confirm=TaskProposalConfirm(edited,80,"confirm");val saved=cold.taskProposals.confirm(confirm)
        assertTrue(cold.taskProposals.list().isEmpty());assertNull(saved.schedule);cold.closeAndAwait()
        val reopened=open();assertEquals(saved,reopened.taskProposals.confirm(confirm))
        assertThrows(TaskProposalConflict::class.java) {reopened.taskProposals.write(initial)}
        val other=reopened.taskProposals.write(initial.copy(id="native-other",titleInput="合成不同人工意图",dateInput=ManualTaskDateInput()))
        val rejected=reopened.taskProposals.write(initial.copy(id=other.id,expectedVersion=1,titleInput=other.titleInput,dateInput=other.dateInput,
            atMillis=90,mutationId="reject",action=TaskProposalAction.REJECT))
        assertEquals(TaskProposalState.REJECTED,rejected.state);assertEquals(1,reopened.manualTasks.snapshots().size)
        assertEquals(ProcessingPolicy.AI_NONE,reopened.entries().single().policy)
    }
    @Test fun nativeSourceTaskReceiptSurvivesCompletionColdReopenAndRejectsChangedSourceLocation():Unit=runBlocking {
        val store=open();val text="合成原文：明天三点只是引用，不推断日期。"
        val entry=store.saveDraft(store.updateDraft(text),50,"UTC");val source=SourceVersion(entry.id,1)
        val p=store.localProcessing.change(LocalProcessingChange(store.localProcessing.read(source),LocalProcessingChoice.AI_NONE,"none"))
        val binding=TaskSourceBinding(source,p.sourceHash,p.generation,0,text.codePointCount(0,text.length))
        val preview=store.sourceTasks.preview(binding)
        val request=SourceTaskCreate(preview,ManualTaskCreate(SourceTasks.id(binding),"合成用户明确创建的任务",60,"UTC","create"))
        val created=store.sourceTasks.create(request);assertNull(created.schedule)
        val completed=store.manualTasks.change(ManualTaskMutation(created.id,1,ManualTaskStatus.COMPLETED,70,"complete"))
        store.closeAndAwait();val cold=open()
        assertEquals(completed,cold.sourceTasks.create(request));assertEquals(1,cold.manualTasks.snapshots().size)
        var located:TaskSourceBinding?=null
        assertTrue(cold.sourceTasks.locate(created.id,completed.version) { located=it });assertEquals(binding,located)
        cold.revise(entry.id,1,"合成第二版，与旧来源不同",80)
        assertThrows(SourceTaskConflict::class.java) { cold.sourceTasks.locate(created.id,completed.version) { fail("changed source") } }
        assertEquals(completed,cold.sourceTasks.create(request))
        assertEquals(ProcessingPolicy.AI_NONE,cold.entries().single().policy)
        assertEquals(listOf(text,"合成第二版，与旧来源不同"),cold.revisions(entry.id).map { it.originalText })
    }
    private lateinit var context: Context
    private lateinit var directory: File
    private val key = ByteArray(32) { (it + 43).toByte() }
    private val stores = mutableListOf<EncryptedEntryRepository>()
    private val file get() = File(directory, "records.db")
    @Before fun before() {
        context = InstrumentationRegistry.getInstrumentation().targetContext
        directory = File(context.noBackupFilesDir, "manual-tasks-" + UUID.randomUUID()).also { check(it.mkdirs()) }
        System.loadLibrary("sqlcipher")
    }
    @After fun after() { try { stores.forEach { it.closeAndAwait() } } finally { key.fill(0); if (::directory.isInitialized) directory.deleteRecursively() } }
    @Test fun freshVersionTenPersistsExplicitTaskAndTerminalStatesAcrossEncryptedReopen(): Unit = runBlocking {
        val store = open(); NativeRecordsSchemaFixture.assertCurrentSchema(store.database.openHelper.writableDatabase)
        assertTrue(store.manualTasks.snapshots().isEmpty()); assertTrue(store.entries().isEmpty())
        val day = due("2042-11-19")
        val overlap = due("2026-11-01", "01:30", "America/New_York", ManualTaskOccurrence.SECOND)
        store.manualTasks.create(create("one", day)); store.manualTasks.create(create("two", overlap))
        store.manualTasks.change(change("one", ManualTaskStatus.COMPLETED)); store.manualTasks.change(change("two", ManualTaskStatus.CANCELLED))
        store.closeAndAwait(); val reopened = open()
        assertEquals(ManualTaskStatus.COMPLETED, reopened.manualTasks.snapshots().single { it.id == "one" }.status)
        assertEquals(ManualTaskStatus.CANCELLED, reopened.manualTasks.snapshots().single { it.id == "two" }.status)
        assertEquals("合成手工待办🙂", reopened.manualTasks.snapshots().first().title)
        assertEquals(day, reopened.manualTasks.snapshots().single { it.id == "one" }.schedule)
        assertNull(reopened.manualTasks.snapshots().single { it.id == "one" }.schedule!!.instant())
        assertEquals(overlap, reopened.manualTasks.snapshots().single { it.id == "two" }.schedule)
        assertEquals(-18_000, reopened.manualTasks.snapshots().single { it.id == "two" }.schedule!!.offsetSeconds)
        assertTrue(reopened.entries().isEmpty()); assertNull(reopened.readDraft())
        assertFalse(file.readBytes().toString(Charsets.UTF_8).contains("合成手工待办"))
    }
    @Test fun encryptedVersionFiveMigrationPreservesOriginalDraftJobAndManualTag(): Unit = runBlocking {
        val tagCipher = ManualTagCipher(key)
        val blob = try { tagCipher.seal("legacy", 1, "legacy-tag", listOf("合成原标签")) } finally { tagCipher.wipe() }
        NativeRecordsSchemaFixture.create(file, key, 5) { sql ->
            sql.execSQL("INSERT INTO entries VALUES('legacy',1,55,'UTC','LOCAL_ONLY')")
            sql.execSQL("INSERT INTO entry_revisions VALUES('legacy',1,?,?,55)", arrayOf("合成原文", contentHash("合成原文")))
            sql.execSQL("INSERT INTO capture_draft VALUES(1,'draft',7,'合成独立草稿')")
            sql.execSQL("INSERT INTO local_jobs VALUES('job','legacy',1,'LOCAL_INDEX','PENDING')")
            sql.execSQL("INSERT INTO entry_manual_tags VALUES('legacy',1,'legacy-tag',?)", arrayOf(blob))
        }
        val store = open(); NativeRecordsSchemaFixture.assertCurrentSchema(store.database.openHelper.writableDatabase)
        assertTrue(store.manualTasks.snapshots().isEmpty()); assertEquals(listOf("合成原标签"), store.manualTags.read("legacy").names)
        assertEquals("合成独立草稿", store.readDraft()!!.text); assertEquals("合成原文", store.entries().single().originalText)
        val day = due("2042-11-19")
        store.manualTasks.create(create("one", day)); store.closeAndAwait(); val reopened = open()
        assertEquals(1, reopened.manualTasks.snapshots().size); assertEquals(7L, reopened.readDraft()!!.version)
        assertEquals(day, reopened.manualTasks.snapshots().single().schedule)
        assertEquals(1, reopened.revisions("legacy").size); assertEquals(listOf("合成原标签"), reopened.manualTags.read("legacy").names)
        reopened.database.openHelper.writableDatabase.query("SELECT state FROM local_jobs").use {
            assertTrue(it.moveToFirst()); assertEquals("PENDING", it.getString(0)); assertFalse(it.moveToNext())
        }
    }
    @Test fun actualNativeTransitionAbortAndIndependentRoomsCasKeepSingleVersion(): Unit = runBlocking {
        val first = open(); first.manualTasks.create(create("one")); val second = open()
        val sql = first.database.openHelper.writableDatabase
        sql.execSQL("CREATE TRIGGER synthetic_task_abort AFTER UPDATE ON manual_tasks BEGIN SELECT RAISE(ABORT,'synthetic abort'); END")
        assertThrows(ManualTaskStorageFailure::class.java) { first.manualTasks.change(change("one", ManualTaskStatus.COMPLETED)) }
        val date = schedule("one", 1, ManualTaskDateOperation.SET, due("2042-11-19"))
        assertThrows(ManualTaskStorageFailure::class.java) { first.manualTasks.reschedule(date) }
        assertNull(second.manualTasks.snapshots().single().schedule)
        assertEquals(1L, second.manualTasks.snapshots().single().version); sql.execSQL("DROP TRIGGER synthetic_task_abort")
        val pool = Executors.newFixedThreadPool(2); val go = CountDownLatch(1)
        try {
            val outcomes = listOf(first, second).mapIndexed { index, store -> pool.submit<String> {
                go.await(); try {
                    if (index == 0) store.manualTasks.reschedule(date)
                    else store.manualTasks.change(change("one", ManualTaskStatus.COMPLETED))
                    "saved"
                } catch (_: ManualTaskConflict) { "conflict" }
            } }; go.countDown()
            assertEquals(listOf("conflict", "saved"), outcomes.map { it.get(2, TimeUnit.SECONDS) }.sorted())
        } finally { pool.shutdownNow(); assertTrue(pool.awaitTermination(2, TimeUnit.SECONDS)) }
        assertEquals(2L, first.manualTasks.snapshots().single().version); assertEquals(1, second.manualTasks.snapshots().size)
        val winner = first.manualTasks.snapshots().single()
        if (winner.status == ManualTaskStatus.OPEN) assertEquals(date.schedule, winner.schedule)
        else { assertEquals(ManualTaskStatus.COMPLETED, winner.status); assertNull(winner.schedule) }
    }
    @Test fun nativeReplayAuthenticationAndOwnerCloseNeverReplaceTaskCiphertext(): Unit = runBlocking {
        var store = open(); val request = create("one"); store.manualTasks.create(request)
        assertEquals(1L, store.manualTasks.create(request).version)
        // Frozen independently with Python cryptography AESGCM and the pre-date v1 serializer.
        val legacy = Base64.getDecoder().decode("AQcICQoLDA0ODxAREj+AQ5fjXQigaqORmrvxsniFI5Uq+lFmJEkiVwViL76VDEiIay58TVr3H8FYul/hQYr7dRPdtKZ8r75916F0aGiynNPQoMxvfw0Tqcgf4Qp5WuTTNXH/1mYXR3vK7OCqXw==")
        store.database.openHelper.writableDatabase.execSQL("INSERT INTO manual_tasks VALUES(?,?,?,?)",
            arrayOf<Any>("legacy", 1, "legacy-create", legacy))
        store.closeAndAwait(); store = open()
        assertNull(store.manualTasks.snapshots().single { it.id == "legacy" }.schedule)
        assertArrayEquals(legacy, ciphertext(store, "legacy"))
        val set = schedule("legacy", 1, ManualTaskDateOperation.SET, due("2042-11-19"))
        store.manualTasks.reschedule(set); val dated = ciphertext(store, "legacy")
        assertEquals(5.toByte(), dated[0]); store.manualTasks.reschedule(set)
        assertArrayEquals(dated, ciphertext(store, "legacy"))
        store.manualTasks.reschedule(schedule("legacy", 2, ManualTaskDateOperation.POSTPONE, due("2042-11-20")))
        store.manualTasks.reschedule(schedule("legacy", 3, ManualTaskDateOperation.CLEAR, null))
        val terminal = change("one", ManualTaskStatus.COMPLETED)
        store.manualTasks.change(terminal); assertEquals(2L, store.manualTasks.change(terminal).version)
        assertThrows(ManualTaskConflict::class.java) { store.manualTasks.create(request) }
        val borrowed = store.manualTasks; store.closeAndAwait()
        assertThrows(ManualTaskStorageFailure::class.java) { borrowed.snapshots() }
        val reopened = open(); val sql = reopened.database.openHelper.writableDatabase
        assertNull(reopened.manualTasks.snapshots().single { it.id == "legacy" }.schedule)
        assertEquals(4L, reopened.manualTasks.snapshots().single { it.id == "legacy" }.version)
        val blob = ciphertext(reopened, "one")
        blob[blob.lastIndex] = (blob.last().toInt() xor 1).toByte()
        sql.execSQL("UPDATE manual_tasks SET version=version+1,ciphertext=? WHERE id='one'", arrayOf(blob))
        assertThrows(ManualTaskStorageFailure::class.java) { reopened.manualTasks.snapshots() }
        assertThrows(ManualTaskStorageFailure::class.java) { reopened.manualTasks.create(request) }
        reopened.closeAndAwait(); assertThrows(ManualTaskStorageFailure::class.java) { open().manualTasks.snapshots() }
    }
    private fun open() = EncryptedEntryRepository.openWithKey(context, file, key.copyOf()).also(stores::add)
    private fun create(id: String, due: ManualTaskSchedule? = null) = ManualTaskCreate(id, "合成手工待办🙂", 55, "Asia/Shanghai", "create-$id", due)
    private fun change(id: String, status: ManualTaskStatus) = ManualTaskMutation(id, 1, status, 99, "change-$id-$status")
    private fun due(day: String, time: String = "", zone: String = "Asia/Shanghai", occurrence: ManualTaskOccurrence? = null) =
        checkNotNull(ManualTaskDateInput(day, time, zone, occurrence).parse())
    private fun schedule(id: String, version: Long, operation: ManualTaskDateOperation, due: ManualTaskSchedule?) =
        ManualTaskScheduleMutation(id, version, operation, due, 99, "date-$id-$version-$operation")
    private fun ciphertext(store: EncryptedEntryRepository, id: String) =
        store.database.openHelper.writableDatabase.query("SELECT ciphertext FROM manual_tasks WHERE id=?", arrayOf(id)).use { cursor ->
            check(cursor.moveToFirst()); cursor.getBlob(0).also { check(!cursor.moveToNext()) }
        }
}
