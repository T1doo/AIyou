# Image grid host execution evidence

Run `python3 verify.py evidence.zip` without extraction, or use the repository script.
Add `--repo-root /path/to/AIyou` to check closure source inputs against the checkout.
No SDK, network, Actions access or third-party Python package is used.

Cohorts are separate observations, not additive coverage counts. baseline-full is
the original 907-method run, with its exact pre-queue report and raw XML.
baseline-after-queue pairs the former final report with the 18 AI/domain XML files
updated by that queue run plus unchanged remote-text XML. Both reports and both
XML cohorts are preserved unchanged. closure adds four methods (911 total).
The historical queue 149 and Python 151 are prior results, not new closure coverage.

Reports retain their real execution Git HEAD (which had uncommitted tested changes).
The captured source-input bytes, recomputed fingerprint and XML method inventory
bind actual test inputs; execution Git HEAD alone is not a clean-tree build claim.
File mtimes are original observed nanoseconds, retained in file-times.json because
ZIP timestamps do not preserve nanoseconds. XML/capture/report bytes are unchanged.

These are JVM platform shells, synthetic image ports and a bounded host Python
SQLite transport. They do not certify Android, Room/SQLCipher, Compose, real devices,
navigation return positioning, narrow/large fonts or rapid-scroll peak memory.
The old failed fixture log/XML and SDK preflight failure remain in logs/.
