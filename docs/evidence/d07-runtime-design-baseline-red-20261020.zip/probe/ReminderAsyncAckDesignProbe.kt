package com.t1doo.aiyou.data

import com.t1doo.aiyou.domain.*
import com.t1doo.aiyou.model.*
import org.junit.Assert.*
import org.junit.Test

/** Baseline design probe, not a new accepted gate or Android/device result. */
class ReminderAsyncAckDesignProbe {
    @Test fun lostUiConfirmationMustRemainReplayableAfterSystemAckAndColdReopen() {
        LocalCandidateFixture().use { local ->
            var tasks = SqlManualTaskRepository(local.gateway, LocalCandidateFixture.KEY)
            try {
                val due = ManualTaskDateSqlTest.date("2042-11-19", "09:30", "Pacific/Chatham")
                val initial = tasks.create(ManualTaskCreate("one", "合成明确待办", 55, "UTC", "create", due))
                val request = TaskReminderMutation(initial, TaskReminderMode.EXACT, 99, "same-confirm")
                var lost = false
                local.db.afterSql = { if (it == "COMMIT" && !lost) { lost = true; error("Synthetic lost UI commit acknowledgement") } }
                try { assertThrows(ManualTaskStorageFailure::class.java) { tasks.changeReminder(request) } }
                finally { local.db.afterSql = null }
                assertTrue(lost)
                val confirmed = tasks.snapshots().single()
                val command = confirmed.reminder!!.commands.single()
                assertTrue(tasks.acknowledgeReminder(command, TaskReminderPhase.SCHEDULED, 100))
                tasks.wipeKey(); local.reopen()
                tasks = SqlManualTaskRepository(local.gateway, LocalCandidateFixture.KEY)
                val current = tasks.snapshots().single()
                assertEquals(TaskReminderPhase.SCHEDULED, current.reminder!!.phase)
                // Expected red on 681e07: the system ACK retired the sole user mutation receipt.
                assertEquals(current, tasks.changeReminder(request))
                assertTrue(tasks.reminderCommands().isEmpty())
            } finally { tasks.wipeKey() }
        }
    }
}
