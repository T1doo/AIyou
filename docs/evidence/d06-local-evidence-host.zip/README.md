# D06 local evidence candidates: host execution evidence

Run the unchanged repository verifier:
python3 scripts/verify-image-grid-evidence.py docs/evidence/d06-local-evidence-host.zip --repo-root .
Or run this archive's verify.py against the ZIP; no extraction, SDK or network needed.

closure/ contains original XML, captures, exact methods, verified report and
all source-input bytes for the actual 925-method JVM run (911 baseline + 14 new).
The report keeps its real execution HEAD, before the tested changes were committed.
The input fingerprint and source byte comparison bind the tested code, not HEAD alone.
File nanosecond mtimes are in file-times.json; ZIP metadata cannot preserve them.

current-python/tests.log is the actual rerun of 151 Python cases (no new methods).
The legacy verifier also checks historical queue 149 / historical Python 151 copied
unchanged from the independently checked grid evidence. Those are not additive coverage.
Queue 149 was not rerun for this slice. method-delta.json lists all 14 new JVM methods.
Initial two fixture failures and corrected targeted logs are preserved in logs/.

Local evidence is a bounded view of existing literal search hits, not natural-language
understanding or a generated answer. No model, credential, permission or schema is added.
Android, Room/SQLCipher, Compose, Preview, devices and return-position/performance gates
remain NOT RUN. No Actions access, SDK acceptance, APK or deployment is claimed.
