import hashlib
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
expected = '488f87cef8247b1943fee38d2ac0f9854361f574'
original = json.loads((root / 'job-log-original.json').read_text())
raw = original['text'].encode('utf-8')
assert original['source_job_id'] == 118719313762
(root / 'job-118719313762.log').write_bytes(raw)
text = raw.decode('utf-8')
assert not re.search(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|AKIA[0-9A-Z]{16}|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}', text), 'Review potential sensitive material before archiving'
run = json.loads((root / 'run-terminal.json').read_text())
jobs = json.loads((root / 'jobs-terminal.json').read_text())
artifacts = json.loads((root / 'artifacts-terminal.json').read_text())
assert run['head_sha'] == expected and run['status'] == 'completed'
assert artifacts['total_count'] == len(artifacts['artifacts'])
for item in artifacts['artifacts']:
    assert item['workflow_run']['head_sha'] == expected
    assert item['workflow_run']['id'] == run['id']
    assert item['size_in_bytes'] > 0 and item['expired'] is False
    assert re.fullmatch(r'sha256:[0-9a-f]{64}', item['reported_digest'])

def marker(name):
    results = []
    for line in text.splitlines():
        if name in line:
            try:
                results.append(json.loads(line.split(name, 1)[1]))
            except json.JSONDecodeError:
                pass
    assert len(results) == 1, (name, len(results))
    return results[0]

host = marker('AI_PROTOCOL_XML_SNAPSHOT_JSON ')
native = marker('REMINDER_CONTROLLED_NATIVE=')
apk = marker('D04_RECORD_AI_PERMISSIONS=')
assert host['head'] == native['sha'] == apk['source_sha'] == expected
assert host['status'] == apk['status'] == 'PASS'
assert apk['internet_permission'] is False
suite_counts = dict((m[0], int(m[1])) for m in re.findall(r'PASS: (.+?) tests=(\d+) actual=\d+ failures=0 errors=0 skipped=0', text))
lint = []
for match in re.finditer(r'/home/runner/work/AIyou/AIyou/(.+?):(\d+): (Error|Warning|Hint): (.+?) \[([^\]\r\n]+)\]', text):
    row = dict(zip(['path', 'line', 'severity', 'message', 'issue'], match.groups()))
    row['line'] = int(row['line'])
    if row not in lint:
        lint.append(row)
result = {'ci_id': run['id'], 'head_sha': expected, 'conclusion': run['conclusion'],
          'raw_log_bytes': len(raw), 'raw_log_sha256': hashlib.sha256(raw).hexdigest(),
          'host': host, 'controlled_native': native, 'suite_counts_from_actual_log': suite_counts,
          'python_test_runs': [int(n) for n in re.findall(r'Ran (\d+) tests? in ', text)],
          'lint_findings': lint, 'apk_permission_audit': apk,
          'failed_steps': [s for j in jobs['jobs'] for s in j['steps'] if s['conclusion'] == 'failure'],
          'skipped_steps': [s['name'] for j in jobs['jobs'] for s in j['steps'] if s['conclusion'] == 'skipped'],
          'artifact_count': artifacts['total_count'],
          'artifact_verification': 'Metadata only; reported digests, no binary downloads or local archive rehash',
          'device_permissions_alarms_notifications': 'NOT RUN', 'sqlcipher_native_runtime': 'NOT RUN',
          'manual_visual_acceptance': 'NOT RUN'}
(root / 'actual-evidence.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
print(json.dumps(result, ensure_ascii=False))
