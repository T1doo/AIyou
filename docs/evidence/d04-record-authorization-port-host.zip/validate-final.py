from pathlib import Path
import hashlib,json,subprocess,zipfile,sys
root=Path('/workspace/AIyou');e=Path('/workspace/scratch/aiyou-record-authorization-20261017')
base='8a295f9ff46d00f7ecaaf003f47d49b34211ace9'
branch='codex/d04-record-authorization-port-20261017'
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
phase=sys.argv[1];assert phase in ('staged','committed')
head=git('rev-parse','HEAD').decode().strip()
assert git('branch','--show-current').decode().strip()==branch
archive=root/'docs/evidence/d04-record-authorization-port-host.zip'
receipt=json.loads((e/'archive-receipt.json').read_text())
assert hashlib.sha256(archive.read_bytes()).hexdigest()==receipt['sha256']
count=0
with zipfile.ZipFile(archive)as z:
    for n in z.namelist():
        prefixes=('closure/source-inputs/','uncompiled-native-source/')
        for prefix in prefixes:
            if n.startswith(prefix):
                path=n[len(prefix):]
                if path=='status.json':continue
                data=z.read(n);assert data==(root/path).read_bytes(),path
                spec=(':'+path) if phase=='staged' else ('HEAD:'+path)
                assert git('show',spec)==data,(phase,path)
                count+=1
    # Bind archive and documentation as well, beyond the execution fingerprint.
    for path in ('docs/D04_APP_RECORD_AI_SESSION.md','docs/evidence/d04-record-authorization-port-host.zip'):
        spec=(':'+path) if phase=='staged' else ('HEAD:'+path)
        assert git('show',spec)==(root/path).read_bytes(),path
pre=json.loads((e/'preflight.json').read_text())
for p,digest in pre['originals'].items():
    assert hashlib.sha256((root/p).read_bytes()).hexdigest()==digest
for a in (base,'01584dd7df71d9ffa3754ffa2555fe4580c6abc0','7383e502418f5f9fc0c540ef2072742359343d40'):
    subprocess.run(['git','merge-base','--is-ancestor',a,'HEAD'],cwd=root,check=True)
protected=['core/data/schemas','core/data/src/androidTest','core/data/src/main/kotlin/com/t1doo/aiyou/data/RecordsDatabase.kt','core/data/src/main/kotlin/com/t1doo/aiyou/data/RecordEntities.kt','core/data/src/main/kotlin/com/t1doo/aiyou/data/RemoteTextTransactions.kt','core/data/src/main/kotlin/com/t1doo/aiyou/data/RemoteTextCodec.kt','core/data/src/main/kotlin/com/t1doo/aiyou/data/AndroidDatabaseKeyProvider.kt','core/ai','schemas','.github','gradle','scripts','app/src/main','app/src/test','app/build.gradle.kts','docs/D03_MIXED_CAPTURE.md']
for p in protected:subprocess.run(['git','diff','--exit-code',base,'--',p],cwd=root,check=True,stdout=subprocess.DEVNULL)
# All previous evidence ZIPs remain byte-identical; only the current new file is allowed.
for p in git('ls-tree','-r','--name-only',base,'docs/evidence').decode().splitlines():
    if p.endswith('.zip'):assert git('show',base+':'+p)==(root/p).read_bytes(),p
lock=root/'.git/codex-index-refresh.lock';assert lock.stat().st_size==0 and lock.stat().st_mtime_ns==1792195365150796372
result={'phase':phase,'head':head,'branch':branch,'executed_plus_uncompiled_sources_bound_to_git_blobs':count,
        'source_sha256':receipt['source_sha256'],'archive_sha256':receipt['sha256'],
        'originals_prior_archives_protected_roots':'UNCHANGED','unknown_lock':'UNCHANGED'}
if phase=='committed':
    refs=git('ls-remote','--heads','origin','main',branch,'codex/f05-restored-people-publication-20261017',
             'codex/f05-metadata-visible-reread-20261017','codex/f01-now-recent-records-20261017','codex/f01-capture-discard-recovery-20261017','codex/f01-discard-retry-queue-message-20261017').decode().splitlines()
    assert head+'\trefs/heads/'+branch in refs
    assert '7383e502418f5f9fc0c540ef2072742359343d40\trefs/heads/main' in refs
    assert '75e130d146e77ab722ea6a498a0a9b65ca0b5143\trefs/heads/codex/f05-restored-people-publication-20261017' in refs
    assert '8e45ea49d71299b4cf2a734766c091df06a7055c\trefs/heads/codex/f01-now-recent-records-20261017' in refs
    assert '016d03ecb094f4f451855954ca9209a1749aa978\trefs/heads/codex/f01-capture-discard-recovery-20261017' in refs
    assert base+'\trefs/heads/codex/f01-discard-retry-queue-message-20261017' in refs
    assert '771eb998a80906fa605769501378848eb7f038a3\trefs/heads/codex/f05-metadata-visible-reread-20261017' in refs
    assert git('status','--porcelain')==b''
    assert git('rev-list','--left-right','--count','origin/'+branch+'...HEAD').decode().strip()=='0\t0'
    assert git('rev-list','--left-right','--count',base+'...HEAD').decode().strip()=='0\t1'
    result.update(remote_refs=refs,remote_diff='0/0',base_diff='0/1',main_diff=git('rev-list','--left-right','--count','origin/main...HEAD').decode().strip(),uncommitted=0,unpushed=0,CI='UNKNOWN; no Actions access',native='NOT RUN; no APK')
output=e/('precommit-validation.json'if phase=='staged'else'final-validation.json')
output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
