from pathlib import Path
import ast, hashlib, json, zipfile, datetime, subprocess

root=Path('/workspace/AIyou')
evidence=Path('/workspace/scratch/aiyou-record-authorization-20261017')
base='8a295f9ff46d00f7ecaaf003f47d49b34211ace9'
items={}
def add(name,data):
    assert name not in items,name
    items[name]=data
def file(name,path):add(name,Path(path).read_bytes())
def document(name,value):add(name,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())

paths=[]
class Recorder:
    def __init__(self):self.h=hashlib.sha256();self.n=0
    def update(self,data):
        if self.n%2==0:
            assert data.endswith(b'\0')
            paths.append(data[:-1].decode())
        self.n+=1;self.h.update(data)
    def hexdigest(self):return self.h.hexdigest()
class RecordingHashlib:
    @staticmethod
    def sha256(data=None):return Recorder() if data is None else hashlib.sha256(data)
tree=ast.parse((root/'scripts/verify-ai-protocol-results.py').read_text())
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='input_fingerprint')
ns={'root':root,'hashlib':RecordingHashlib}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'<production fingerprint>','exec'),ns)
digest=ns['input_fingerprint']()
report=json.loads((evidence/'verified-contracts.json').read_text())
assert report['source_sha256']==digest and sum(m['tests']for m in report['results'])==1030
assert digest==json.loads((evidence/'full-inputs.json').read_text())['source_sha256']
for name in paths:file('closure/source-inputs/'+name,root/name)
file('closure/verified-report.json',evidence/'verified-contracts.json')
document('closure/methods.json',{r['module']:r['methods']for r in report['results']})
times={}
for module in report['results']:
    label=module['module'].split(':')[-1]
    folder=evidence/'raw-xml'/label
    path=folder/'inputs-at-test.json';key=f'closure/captures/{label}.json'
    file(key,path);times[key]=path.stat().st_mtime_ns
    for xml in module['xml']:
        path=folder/Path(xml['path']).name
        assert hashlib.sha256(path.read_bytes()).hexdigest()==xml['sha256']
        key=f'closure/xml/{label}/{path.name}';file(key,path);times[key]=path.stat().st_mtime_ns
document('closure/file-times.json',times)

old=root/'docs/evidence/f01-discard-retry-queue-message-host.zip'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='6f4fa9e54253fda545e5aca00154b30f643d687635c19f1b86acda628a239f8d'
with zipfile.ZipFile(old)as z:
    for name in z.namelist():
        if name.startswith(('historical-queue/','historical-python/')):add(name,z.read(name))
    previous=json.loads(z.read('closure/verified-report.json'))
    before={tuple(c)for r in previous['results']for c in r['methods']}
    after={tuple(c)for r in report['results']for c in r['methods']}
    assert len(before)==1019 and before<=after and len(after-before)==11
    document('method-delta.json',{'base':base,'previous':1019,'current':1030,'added':sorted(after-before),'removed':[]})

for path in sorted(evidence.iterdir()):
    if path.is_file() and (path.suffix in ('.log','.json','.xml','.kt')or path.name.startswith('baseline-')or path.name=='package-evidence.py'):
        if path.name not in ('archive-receipt.json','verified-contracts.json','final-validation.json','writer-completed.json'):
            file('logs/'+path.name,path)
for path in sorted((evidence/'targeted-xml').glob('*.xml')):file('targeted/'+path.name,path)
for directory in ('first-full-pass','first-targeted-pass'):
    for path in sorted((evidence/directory).rglob('*')):
        if path.is_file():file(('earlier-full-pass' if directory=='first-full-pass' else 'earlier-targeted-pass')+'/'+str(path.relative_to(evidence/directory)),path)
file('validate-final.py',evidence/'validate-final.py')
file('verify.py',root/'scripts/verify-image-grid-evidence.py')
add('README.md',b'# Independent metadata-only record authorization management port\n\npython3 scripts/verify-image-grid-evidence.py docs/evidence/d04-record-authorization-port-host.zip --repo-root .\n\n1030 actual unique JVM methods = accepted8a1019 plus11. All previous methods retained,\nzero failures/errors/skips, final complete run on updated sources; no same-source retry. First complete run\npassed1029 before review added one explicit source-revision ABA method; its raw results\nand exact changed test source are retained under earlier-full-pass/. Exact raw XML, captures,\nnanosecond times, report and source fingerprints agree; final Git blobs bound outside\nthis archive. Historical queue149/Python151 retained only, not rerun/new coverage.\n\nStorage decision and blocker: a formal no-key connection-draft catalog belongs in\nmanaged storage in the same encrypted Room database, not display preferences, backup\nreceipts, dummy records or an extra file store. Current per-source BLOBs encode complete\nProviderConnection/ConsentGrant and cannot honestly represent a missing secretRef draft.\nA new managed catalog needs12to13 and genuine committed KSP11 then12 prerequisite pairs.\nThose real pairs are absent and SDK terms unapproved. NO catalog/schema/migration/UI\nsave path or parallel store is implemented here. No fake Room export/fixture, invented\nproduction reference or misleading connected/ready page. Draft persistence and the full\nconfiguration UI remain BLOCKED/NOT IMPLEMENTED, not claimed as delivered.\n\nThis independent slice adds a typed permission-management capability over existing\nremote_source_access rows and only a hash-bound decision receipt in local_jobs, using\nthe existing same owner/transaction. The port reads existing complete metadata, previews\nagainst frozen source/version/hash/generation, explicitly confirms a bounded ConsentGrant\nor withdraws toLOCAL_ONLY/AI_NONE. It reuses RemoteTextTransactions.updateAuthorization\nCAS/invalidation with nested same-owner transactions. Old send-only/local-policy ports\nare not expanded. Default new records stayLOCAL_ONLY; opening/previewing never grants.\n\nNo operation resolves secrets, constructs clients/exchanges, calls queue/admit/commit,\nor creates remote_text_jobs/annotations. Preview says NOT_CONFIGURED orUNVERIFIED and\nexecutionReady=false, even if a consent is current. Current consent metadata is not\ncredential readiness. ProductionbindAi=null/INTERNET removal stay byte-identical.\nNo new settings/reader/diagnostic page; production catalog/user flow remains incomplete.\n\nOne immutable mutation ID binds action/source/hash/generation/full previous config/grant\nand desired grant/policy. Actual metadata change, old-result invalidation and receipt\ncommit together. Exact lost-ACK retry never extends consent or increments again. A late\nknown receipt after revoke/config drift/expiry returns current metadata with its decision\nno longer current; it never reapplies old authority. Changed source/hash/deletion/fences\nor a mismatched receipt reject. Clock expiry/cancellation before final commit roll back.\n\nActual11 SQL methods cover missing configuration/default/no-work; preview cancellation;\nexplicit confirmation and reopen; real COMMIT followed by lost ACK+reopen/exact replay;\nactual transaction abort; withdrawal/late old ACK; first-read and confirm ABA; configuration\nchanges and nonce collision; expiry/final-clock cancellation; independent SQLite writers;\nactual source-revision1to2to1 ABA, and source/hash/deletion/permanent-erasure rejection. New fixtures use the existing actual\nv7->8 host contract, not fake Room11/12/13. Synthetic complete metadata/references are seeded\nonly in tests via the existing API, with no real credential material or network activity.\nEvery fixture asserts no sending jobs/annotations. New API did not exist onbaseline: no\nbaseline business-red test is claimed. Initial compile failed cross-module nullable-grant\nsmartcast, before tests. Immutable local binding corrected it; original log/source retained.\nTargeted11PASS, final full1030PASS. Host SQLite/platform shells are not native proof.\n\nOriginal plans, Room schema/exports/native fixtures, old protocol codec/transactions,\nworkflow/permissions/dependencies/UI/8a capture fix/SDK decisions remain unchanged.\nNo extra SDK diagnosis/terms/download/secret/real provider/fee/Actions/alternative route.\nTrue Room/SQLCipher/Android/Compose/Preview/device remain NOT RUN, no APK. Prior reported\nAndroid CI failures and old AI preparation failure remain cause UNKNOWN; newCI UNKNOWN.\nThis is a partial backend delivery subject to parent review, not fullD04 or production\nmodel/configuration availability.\n')
manifest={'format':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'cohorts':[{'id':'closure','source_prefix':'closure/source-inputs/','source_sha256':digest,
                      'tests':1030,'execution_git_head':report['head'],'source_git_base':base}],
          'python_rerun':False,'queue_rerun':False,
          'files':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for name,data in sorted(items.items())}}
document('manifest.json',manifest)
output=root/'docs/evidence/d04-record-authorization-port-host.zip'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for name,data in sorted(items.items()):z.writestr(name,data)
print(json.dumps({'archive':str(output),'bytes':output.stat().st_size,
                  'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'source_sha256':digest,
                  'source_inputs':len(paths),'zip_members':len(items),'methods':1030,'added':11,
                  'python_rerun':False,'queue_rerun':False},indent=2))
