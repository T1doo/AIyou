# Independent metadata-only record authorization management port

python3 scripts/verify-image-grid-evidence.py docs/evidence/d04-record-authorization-port-host.zip --repo-root .

1030 actual unique JVM methods = accepted8a1019 plus11. All previous methods retained,
zero failures/errors/skips, final complete run on updated sources; no same-source retry. First complete run
passed1029 before review added one explicit source-revision ABA method; its raw results
and exact changed test source are retained under earlier-full-pass/. Exact raw XML, captures,
nanosecond times, report and source fingerprints agree; final Git blobs bound outside
this archive. Historical queue149/Python151 retained only, not rerun/new coverage.

Storage decision and blocker: a formal no-key connection-draft catalog belongs in
managed storage in the same encrypted Room database, not display preferences, backup
receipts, dummy records or an extra file store. Current per-source BLOBs encode complete
ProviderConnection/ConsentGrant and cannot honestly represent a missing secretRef draft.
A new managed catalog needs12to13 and genuine committed KSP11 then12 prerequisite pairs.
Those real pairs are absent and SDK terms unapproved. NO catalog/schema/migration/UI
save path or parallel store is implemented here. No fake Room export/fixture, invented
production reference or misleading connected/ready page. Draft persistence and the full
configuration UI remain BLOCKED/NOT IMPLEMENTED, not claimed as delivered.

This independent slice adds a typed permission-management capability over existing
remote_source_access rows and only a hash-bound decision receipt in local_jobs, using
the existing same owner/transaction. The port reads existing complete metadata, previews
against frozen source/version/hash/generation, explicitly confirms a bounded ConsentGrant
or withdraws toLOCAL_ONLY/AI_NONE. It reuses RemoteTextTransactions.updateAuthorization
CAS/invalidation with nested same-owner transactions. Old send-only/local-policy ports
are not expanded. Default new records stayLOCAL_ONLY; opening/previewing never grants.

No operation resolves secrets, constructs clients/exchanges, calls queue/admit/commit,
or creates remote_text_jobs/annotations. Preview says NOT_CONFIGURED orUNVERIFIED and
executionReady=false, even if a consent is current. Current consent metadata is not
credential readiness. ProductionbindAi=null/INTERNET removal stay byte-identical.
No new settings/reader/diagnostic page; production catalog/user flow remains incomplete.

One immutable mutation ID binds action/source/hash/generation/full previous config/grant
and desired grant/policy. Actual metadata change, old-result invalidation and receipt
commit together. Exact lost-ACK retry never extends consent or increments again. A late
known receipt after revoke/config drift/expiry returns current metadata with its decision
no longer current; it never reapplies old authority. Changed source/hash/deletion/fences
or a mismatched receipt reject. Clock expiry/cancellation before final commit roll back.

Actual11 SQL methods cover missing configuration/default/no-work; preview cancellation;
explicit confirmation and reopen; real COMMIT followed by lost ACK+reopen/exact replay;
actual transaction abort; withdrawal/late old ACK; first-read and confirm ABA; configuration
changes and nonce collision; expiry/final-clock cancellation; independent SQLite writers;
actual source-revision1to2to1 ABA, and source/hash/deletion/permanent-erasure rejection. New fixtures use the existing actual
v7->8 host contract, not fake Room11/12/13. Synthetic complete metadata/references are seeded
only in tests via the existing API, with no real credential material or network activity.
Every fixture asserts no sending jobs/annotations. New API did not exist onbaseline: no
baseline business-red test is claimed. Initial compile failed cross-module nullable-grant
smartcast, before tests. Immutable local binding corrected it; original log/source retained.
Targeted11PASS, final full1030PASS. Host SQLite/platform shells are not native proof.

Original plans, Room schema/exports/native fixtures, old protocol codec/transactions,
workflow/permissions/dependencies/UI/8a capture fix/SDK decisions remain unchanged.
No extra SDK diagnosis/terms/download/secret/real provider/fee/Actions/alternative route.
True Room/SQLCipher/Android/Compose/Preview/device remain NOT RUN, no APK. Prior reported
Android CI failures and old AI preparation failure remain cause UNKNOWN; newCI UNKNOWN.
This is a partial backend delivery subject to parent review, not fullD04 or production
model/configuration availability.
