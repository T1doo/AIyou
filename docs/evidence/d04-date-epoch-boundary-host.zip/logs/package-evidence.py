from pathlib import Path
import ast,hashlib,json,zipfile,datetime
r=Path('/workspace/AIyou');e=Path('/workspace/scratch/aiyou-date-epoch-causality-20261017');base='f77cc358679c20e4e3f7b641c03f618519902f5e';items={};paths=[]
def add(n,b):assert n not in items,n;items[n]=b
def file(n,p):add(n,Path(p).read_bytes())
def doc(n,v):add(n,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
class Recorder:
    def __init__(self):self.h=hashlib.sha256();self.n=0
    def update(self,b):
        if self.n%2==0:assert b.endswith(b'\0');paths.append(b[:-1].decode())
        self.n+=1;self.h.update(b)
    def hexdigest(self):return self.h.hexdigest()
class RecordingHashlib:
    @staticmethod
    def sha256(b=None):return Recorder()if b is None else hashlib.sha256(b)
fn=next(n for n in ast.parse((r/'scripts/verify-ai-protocol-results.py').read_text()).body if isinstance(n,ast.FunctionDef)and n.name=='input_fingerprint')
ns={'root':r,'hashlib':RecordingHashlib};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<unchanged fingerprint>','exec'),ns);digest=ns['input_fingerprint']()
report=json.loads((e/'verified-contracts.json').read_text());assert report['source_sha256']==digest==json.loads((e/'full-inputs.json').read_text())['source_sha256'];assert sum(m['tests']for m in report['results'])==1040
for p in paths:file('closure/source-inputs/'+p,r/p)
file('closure/verified-report.json',e/'verified-contracts.json');doc('closure/methods.json',{m['module']:m['methods']for m in report['results']});times={}
for m in report['results']:
    label=m['module'].split(':')[-1];folder=e/'raw-xml'/label;p=folder/'inputs-at-test.json';n='closure/captures/'+label+'.json';file(n,p);times[n]=p.stat().st_mtime_ns
    for x in m['xml']:
        p=folder/Path(x['path']).name;assert hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256'];n='closure/xml/'+label+'/'+p.name;file(n,p);times[n]=p.stat().st_mtime_ns
doc('closure/file-times.json',times)
old=r/'docs/evidence/d04-record-authorization-view-withdraw-host-failed.zip';assert hashlib.sha256(old.read_bytes()).hexdigest()=='3d3efd8469f58a2c3650752e0eb34fddc8df2bffdc1325b1f51301cfde92bd33'
with zipfile.ZipFile(old)as z:
    before={tuple(t)for t in json.loads(z.read('manifest.json'))['full_method_inventory']};after={tuple(t)for m in report['results']for t in m['methods']}
    assert len(before)==1039 and before<=after and len(after-before)==1
    doc('method-delta.json',{'base':base,'previous':1039,'current':1040,'added':sorted(after-before),'removed':[]})
    for n in z.namelist():
        if n=='logs/delivery-status.json'or n=='logs/isolated-date-epoch.log'or n.startswith(('runs/first-full-failure/','runs/second-full-failure/','runs/isolated-date-epoch/'))and(n.endswith(('full-jvm.log','full-inputs.json','inputs-at-test.json'))or'MetadataSourceGenerationViewModelTest.xml'in n):add('historical-f77/'+n,z.read(n))
    doc('historical-f77/archive-reference.json',{'archive':str(old.relative_to(r)),'sha256':'3d3efd8469f58a2c3650752e0eb34fddc8df2bffdc1325b1f51301cfde92bd33','included':'original failed date XML/log/captures and isolated green only; complete immutable original archive remains in Git'})
prior=r/'docs/evidence/d04-record-authorization-port-host.zip';assert hashlib.sha256(prior.read_bytes()).hexdigest()=='3f0ffce06992bb77e3f8fff6fe1e32c0c85418393ac29ceeee4a213259a6ba44'
with zipfile.ZipFile(prior)as z:
    for n in z.namelist():
        if n.startswith(('historical-queue/','historical-python/')):add(n,z.read(n))
for p in sorted(e.iterdir()):
    if p.is_file()and p.name not in ('archive-receipt.json','verified-contracts.json','final-validation.json','writer-completed.json'):
        file('logs/'+p.name,p)
for folder in ('f77-controlled-red','aa-controlled-red','aa-controlled-green','fixed-targeted-xml'):
    for p in sorted((e/folder).rglob('*')):
        if p.is_file():file('experiments/'+str(p.relative_to(e)),p)
file('verify.py',r/'scripts/verify-image-grid-evidence.py')
add('README.md',b'''# Date-receipt epoch: controlled causality and test-boundary correction

python3 scripts/verify-image-grid-evidence.py docs/evidence/d04-date-epoch-boundary-host.zip --repo-root .

Final complete fixed-source closure1040 actual unique JVM methods; old1039 retained +1
causal diagnostic. Zero failures/errors/skips. One final complete run, unfiltered; source
inputs/rawXML/captures/nanosecond times/report agree. Git blob binding is checked outside
the archive. Targeted34PASS = metadata10 + authVM9 + localPolicyVM4 + backendSQL11.
Historical queue149/Python151 are retained, not rerun/new coverage.

Original f77 two full1039/1FAIL runs and unchanged isolated1PASS remain immutable in the
failed archive referenced above; relevant raw records are extracted here. Their historical
UNKNOWN cause entries are not rewritten. New experiments identify the concrete defect:
generation3 visibility was incorrectly treated as the restored index completion boundary.

Same bounded latch/SQL tracing source on actualf77 and acceptedaa independently yields
the original strict assertion deterministic10vs11 RED plus the causal diagnostic PASS.
Both SQL traces are byte-identical. A latch pauses the generation3 restored IndexBatch
BEFORE its real transaction, leavingepoch10 readable. Release recordsINDEX_SQL BEGIN,
exactly one epoch CAS update, FTS/document/job writes andCOMMIT. Actual owner return/ACK
and visibilityGeneration3 indexed document prove completion at11. Subsequent date receipt
transaction is BEGIN/SELECT/COMMIT only: noDML, identical mutation object/id, version1,
epoch unchanged11. The legal independent index batch owned the increment, not a duplicate
date change. The source epoch-path map identifies all trigger/reset/batch routes.

Minimal fix is TEST ONLY: take the no-business-write baseline after the exact generation3
index COMMIT ACK, not after generation publication or merely !localIndexBusy. Date and
the analogous favorite receipt keep their strict epoch equality/nonce/version assertions.
Date also explicitly asserts actual transaction noDML. A new deterministic diagnostic
asserts index+1 then receipt+0. No expected value, comparison or original15s/5s budget is
relaxed; no sleep or filtered acceptance. aa fixed controlled2PASS and main targeted34PASS.
The owned detachedaa checkout reused the existing pinned JDK/offline cache explicitly;
it did not initialize/configure/download/accept AndroidSDK. Its only modified test was
copied as evidence, restored, then normal clean worktree removal; other worktrees/locks
were untouched. Initial orchestration/JDK bootstrap stops occurred before tests and are
preserved, never counted as causal red evidence.

Product App/core/domain/model/data, SQL/schema/migrations/native fixtures, authorization,
manifest/permissions/dependencies/key provider/workflows/gates stay byte-identical tof77.
This corrects test synchronization, not production date/index logic. The f77 original
detail view/withdrawal remains source-wired and host-tested; production configuration/
grant creation still absent, bindAi null and no sending/secret/client scope changes.

Host SQLite/platform shells are not Room/SQLCipher/Android/Compose/Preview/device proof;
those remainNOTRUN, noAPK. Formal managed sameRoom draft catalog still blocked on genuine
Room11 then12 prerequisite pairs/approved toolchain before12to13, no substitute store.
No SDK diagnosis/acceptance/download, real model, fees or Actions/log/API/alternative path.
Parent original emails confirm aa/f77 D01CI failures, causeUNKNOWN. Do not equate their
cause to this local host test defect. NewCI UNKNOWN. Old AI preparation failure remains
separate/unexplained; later passes do not erase it. New slice awaits parent independent
review; complete D04/native availability is not claimed.
''')
doc('manifest.json',{'format':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cohorts':[{'id':'closure','source_prefix':'closure/source-inputs/','source_sha256':digest,'tests':1040,'execution_git_head':report['head'],'source_git_base':base}],'python_rerun':False,'queue_rerun':False,'files':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for n,b in sorted(items.items())}})
out=r/'docs/evidence/d04-date-epoch-boundary-host.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for n,b in sorted(items.items()):z.writestr(n,b)
print(json.dumps({'archive':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_sha256':digest,'source_inputs':len(paths),'zip_members':len(items),'methods':1040,'added':1,'targeted':34,'queue_rerun':False,'python_rerun':False},indent=2))
