from pathlib import Path
import hashlib,json,subprocess,zipfile,sys
r=Path('/workspace/AIyou');e=Path('/workspace/scratch/aiyou-date-epoch-causality-20261017');base='f77cc358679c20e4e3f7b641c03f618519902f5e';aa='aa61658306dd0a7df251f1fe0501ae7bdef256d9';branch='codex/fix-date-epoch-boundary-20261017'
def git(*a):return subprocess.check_output(['git',*a],cwd=r)
phase=sys.argv[1];assert phase in ('staged','committed');head=git('rev-parse','HEAD').decode().strip();assert git('branch','--show-current').decode().strip()==branch
archive='docs/evidence/d04-date-epoch-boundary-host.zip';receipt=json.loads((e/'archive-receipt.json').read_text());assert hashlib.sha256((r/archive).read_bytes()).hexdigest()==receipt['sha256'];count=0
with zipfile.ZipFile(r/archive)as z:
    for n in z.namelist():
        if n.startswith('closure/source-inputs/'):
            p=n[len('closure/source-inputs/'):];b=z.read(n);assert b==(r/p).read_bytes()==git('show',(':'if phase=='staged'else'HEAD:')+p),p;count+=1
for p in [archive,'docs/D04_APP_RECORD_AI_SESSION.md']:assert (r/p).read_bytes()==git('show',(':'if phase=='staged'else'HEAD:')+p),p
pre=json.loads((e/'preflight.json').read_text())
for p,h in pre['originals'].items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,p
allowed={'checks/ai-protocol/remote-text/src/test/kotlin/com/t1doo/aiyou/records/MetadataSourceGenerationViewModelTest.kt','docs/D04_APP_RECORD_AI_SESSION.md',archive}
assert set(git('diff','--name-only',base).decode().splitlines())==allowed
for p in ['app','core','schemas','scripts','.github','gradle','checks/ai-protocol/remote-text/build.gradle.kts','docs/D03_MIXED_CAPTURE.md']:
    subprocess.run(['git','diff','--exit-code',base,'--',p],cwd=r,check=True,stdout=subprocess.DEVNULL)
for p in git('ls-tree','-r','--name-only',base,'docs/evidence').decode().splitlines():
    if p.endswith('.zip'):assert git('show',base+':'+p)==(r/p).read_bytes(),p
for a in [base,aa,'01584dd7df71d9ffa3754ffa2555fe4580c6abc0','7383e502418f5f9fc0c540ef2072742359343d40']:subprocess.run(['git','merge-base','--is-ancestor',a,'HEAD'],cwd=r,check=True)
l=r/'.git/codex-index-refresh.lock';assert l.stat().st_size==0 and l.stat().st_mtime_ns==1792195365150796372
assert not Path('/workspace/scratch/aiyou-date-epoch-aa-20261017').exists()
result={'phase':phase,'head':head,'branch':branch,'source_inputs_bound_to_git_blobs':count,'source_sha256':receipt['source_sha256'],'archive_sha256':receipt['sha256'],'protected_production_originals_prior_archives_unknown_lock':'UNCHANGED','only_change':'test synchronization and causal regression; no production change fromf77','causal_proof':'same red10vs11/identical SQL trace onaa/f77; index owns +1, date replay noDML; baseline after generation3 actual index COMMIT ACK','targeted':34,'full_unique':1040,'native':'NOT RUN; no newAPK'}
if phase=='committed':
    refs=git('ls-remote','--heads','origin','main',branch,'codex/d04-record-authorization-view-withdraw-20261017','codex/d04-record-authorization-port-20261017').decode().splitlines()
    for sha,name in [(head,branch),(base,'codex/d04-record-authorization-view-withdraw-20261017'),(aa,'codex/d04-record-authorization-port-20261017'),('7383e502418f5f9fc0c540ef2072742359343d40','main')]:assert sha+'\trefs/heads/'+name in refs
    assert git('status','--porcelain')==b''
    for target,expected in [('origin/'+branch,'0\t0'),(base,'0\t1'),(aa,'0\t2')]:assert git('rev-list','--left-right','--count',target+'...HEAD').decode().strip()==expected
    result.update(remote_refs=refs,remote_diff='0/0',f77_diff='0/1',aa_diff='0/2',main_diff=git('rev-list','--left-right','--count','origin/main...HEAD').decode().strip(),uncommitted=0,unpushed=0,CI='new commitUNKNOWN; aa/f77 reportedFAIL with UNKNOWN cause, independent of local test diagnosis; no Actions access')
(e/('precommit-validation.json'if phase=='staged'else'final-validation.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
