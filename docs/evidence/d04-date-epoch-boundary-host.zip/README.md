# Date-receipt epoch: controlled causality and test-boundary correction

python3 scripts/verify-image-grid-evidence.py docs/evidence/d04-date-epoch-boundary-host.zip --repo-root .

Final complete fixed-source closure1040 actual unique JVM methods; old1039 retained +1
causal diagnostic. Zero failures/errors/skips. One final complete run, unfiltered; source
inputs/rawXML/captures/nanosecond times/report agree. Git blob binding is checked outside
the archive. Targeted34PASS = metadata10 + authVM9 + localPolicyVM4 + backendSQL11.
Historical queue149/Python151 are retained, not rerun/new coverage.

Original f77 two full1039/1FAIL runs and unchanged isolated1PASS remain immutable in the
failed archive referenced above; relevant raw records are extracted here. Their historical
UNKNOWN cause entries are not rewritten. New experiments identify the concrete defect:
generation3 visibility was incorrectly treated as the restored index completion boundary.

Same bounded latch/SQL tracing source on actualf77 and acceptedaa independently yields
the original strict assertion deterministic10vs11 RED plus the causal diagnostic PASS.
Both SQL traces are byte-identical. A latch pauses the generation3 restored IndexBatch
BEFORE its real transaction, leavingepoch10 readable. Release recordsINDEX_SQL BEGIN,
exactly one epoch CAS update, FTS/document/job writes andCOMMIT. Actual owner return/ACK
and visibilityGeneration3 indexed document prove completion at11. Subsequent date receipt
transaction is BEGIN/SELECT/COMMIT only: noDML, identical mutation object/id, version1,
epoch unchanged11. The legal independent index batch owned the increment, not a duplicate
date change. The source epoch-path map identifies all trigger/reset/batch routes.

Minimal fix is TEST ONLY: take the no-business-write baseline after the exact generation3
index COMMIT ACK, not after generation publication or merely !localIndexBusy. Date and
the analogous favorite receipt keep their strict epoch equality/nonce/version assertions.
Date also explicitly asserts actual transaction noDML. A new deterministic diagnostic
asserts index+1 then receipt+0. No expected value, comparison or original15s/5s budget is
relaxed; no sleep or filtered acceptance. aa fixed controlled2PASS and main targeted34PASS.
The owned detachedaa checkout reused the existing pinned JDK/offline cache explicitly;
it did not initialize/configure/download/accept AndroidSDK. Its only modified test was
copied as evidence, restored, then normal clean worktree removal; other worktrees/locks
were untouched. Initial orchestration/JDK bootstrap stops occurred before tests and are
preserved, never counted as causal red evidence.

Product App/core/domain/model/data, SQL/schema/migrations/native fixtures, authorization,
manifest/permissions/dependencies/key provider/workflows/gates stay byte-identical tof77.
This corrects test synchronization, not production date/index logic. The f77 original
detail view/withdrawal remains source-wired and host-tested; production configuration/
grant creation still absent, bindAi null and no sending/secret/client scope changes.

Host SQLite/platform shells are not Room/SQLCipher/Android/Compose/Preview/device proof;
those remainNOTRUN, noAPK. Formal managed sameRoom draft catalog still blocked on genuine
Room11 then12 prerequisite pairs/approved toolchain before12to13, no substitute store.
No SDK diagnosis/acceptance/download, real model, fees or Actions/log/API/alternative path.
Parent original emails confirm aa/f77 D01CI failures, causeUNKNOWN. Do not equate their
cause to this local host test defect. NewCI UNKNOWN. Old AI preparation failure remains
separate/unexplained; later passes do not erase it. New slice awaits parent independent
review; complete D04/native availability is not claimed.
