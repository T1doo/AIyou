from pathlib import Path
import ast, hashlib, json, zipfile, datetime, subprocess

root=Path('/workspace/AIyou')
evidence=Path('/workspace/scratch/aiyou-discard-retry-queue-message-20261017')
base='016d03ecb094f4f451855954ca9209a1749aa978'
items={}
def add(name,data):
    assert name not in items,name
    items[name]=data
def file(name,path):add(name,Path(path).read_bytes())
def document(name,value):add(name,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())

paths=[]
class Recorder:
    def __init__(self):self.h=hashlib.sha256();self.n=0
    def update(self,data):
        if self.n%2==0:
            assert data.endswith(b'\0')
            paths.append(data[:-1].decode())
        self.n+=1;self.h.update(data)
    def hexdigest(self):return self.h.hexdigest()
class RecordingHashlib:
    @staticmethod
    def sha256(data=None):return Recorder() if data is None else hashlib.sha256(data)
tree=ast.parse((root/'scripts/verify-ai-protocol-results.py').read_text())
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='input_fingerprint')
ns={'root':root,'hashlib':RecordingHashlib}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'<production fingerprint>','exec'),ns)
digest=ns['input_fingerprint']()
report=json.loads((evidence/'verified-contracts.json').read_text())
assert report['source_sha256']==digest and sum(m['tests']for m in report['results'])==1019
assert digest==json.loads((evidence/'full-inputs.json').read_text())['source_sha256']
for name in paths:file('closure/source-inputs/'+name,root/name)
file('closure/verified-report.json',evidence/'verified-contracts.json')
document('closure/methods.json',{r['module']:r['methods']for r in report['results']})
times={}
for module in report['results']:
    label=module['module'].split(':')[-1]
    folder=evidence/'raw-xml'/label
    path=folder/'inputs-at-test.json';key=f'closure/captures/{label}.json'
    file(key,path);times[key]=path.stat().st_mtime_ns
    for xml in module['xml']:
        path=folder/Path(xml['path']).name
        assert hashlib.sha256(path.read_bytes()).hexdigest()==xml['sha256']
        key=f'closure/xml/{label}/{path.name}';file(key,path);times[key]=path.stat().st_mtime_ns
document('closure/file-times.json',times)

old=root/'docs/evidence/f01-capture-discard-recovery-host.zip'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='7b9bae15a78fbfd53f05f282499cd66fb6c5306eff74c7cc70613f66b937d4a7'
with zipfile.ZipFile(old)as z:
    for name in z.namelist():
        if name.startswith(('historical-queue/','historical-python/')):add(name,z.read(name))
    previous=json.loads(z.read('closure/verified-report.json'))
    before={tuple(c)for r in previous['results']for c in r['methods']}
    after={tuple(c)for r in report['results']for c in r['methods']}
    assert len(before)==1018 and before<=after and len(after-before)==1
    document('method-delta.json',{'base':base,'previous':1018,'current':1019,'added':sorted(after-before),'removed':[]})

for path in sorted(evidence.iterdir()):
    if path.is_file() and (path.suffix in ('.log','.json','.xml','.kt')or path.name.startswith('baseline-')or path.name=='package-evidence.py'):
        if path.name not in ('archive-receipt.json','verified-contracts.json','final-validation.json','writer-completed.json'):
            file('logs/'+path.name,path)
for path in sorted((evidence/'targeted-xml').glob('*.xml')):file('targeted/'+path.name,path)
file('verify.py',root/'scripts/verify-image-grid-evidence.py')
add('README.md',b'# Truthful queue-rejection message for an unacknowledged capture clear\n\nVerify with the unchanged portable verifier:\npython3 scripts/verify-image-grid-evidence.py docs/evidence/f01-discard-retry-queue-message-host.zip --repo-root .\n\n1019 actual unique JVM methods = parent-limited accepted016d1018 plus1; all previous\nmethods retained, zero failures/errors/skips. One complete run, no complete retry.\nExact source bytes/captures/XML/nanosecond times/method inventories are bound. Git\nstaged/final blob comparisons are recorded outside this archive. Queue149/Python151\nare preserved historical evidence only, not rerun or new coverage.\n\nParent review found the real followup: after an actual discard commit loses its ACK,\na retry rejected before enqueue still said text/images were retained. They may already\nhave been cleaned. The actual new composite method first saves an encrypted draft\npicture, performs real discard+lost ACK, and prepares another durable draft with its\nown authenticated image. Rejected retry must report clear result still unverified,\nnever promise retained data; existing freeze and original clear identity must remain.\nSuccessful retry then replays only the old clear; the newer draft, version/text/image\nbytes remain unchanged, and a retained confirm cannot clear it again.\n\nActual baseline1 method failed at the inaccurate rejection message assertion. Identical\nnew test source is retained before/after. Corrected targeted17 pass (capture6/mixed7/Now4),\nincluding the unchanged positive where first clear never enters the queue and cancel/\ncontinued editing remains allowed. Raw baseline failure, logs, source and captures are\npreserved. No assertion, deadline, first-rejection behavior or core receipt was loosened.\n\nProduction change only supplies a private optional submit rejection message, selected\nfrom the PREVIOUS discardPending state when retrying the already-confirmed clear.\nNo transient false retained-data message is published for that retry. All other submit\ncalls and the known-not-executed first clear retain their original default behavior.\nNo schema/SQL/model/domain API, UI/navigation/native tests, permission, dependency,\nworkflow, AI/configuration or lifecycle change. Closed-owner/cold-start behavior was\nsource-reviewed only this slice, not a new executed race/native acceptance.\n\nInitial normal Git read returned503, no mutation/denial/uncertain push. Its output was\npreserved; exactly one normal read retry succeeded. No alternate route, TLS bypass,\ncredentials or Actions. The orchestration initially continued the known new regression\nbefore inspecting failed preflight; only that requested test was changed, then carried\nwith identical HEAD/source bytes onto the isolated new branch before product edits.\nNo accepted commit or prior ZIP was rewritten. No unknown lock or process was removed.\n\nOriginal plans and old archives unchanged; no SDK diagnosis repeated or agreement/\ndownload/configuration/new permission/live key/model call. Real KSP11 then12 exports/\nfixtures, Room/SQLCipher/Android/Compose/Preview/device remain NOT RUN, no new APK.\nThe separate model-entry analysis is read-only and not implemented in this patch.\nNew CI UNKNOWN; prior reported Android CI failures remain cause UNKNOWN; old AI\npreparation assertion failure root remains UNKNOWN. Parent review of this followup\nis pending. This does not expand F01/D03/native acceptance.\n')
manifest={'format':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'cohorts':[{'id':'closure','source_prefix':'closure/source-inputs/','source_sha256':digest,
                      'tests':1019,'execution_git_head':report['head'],'source_git_base':base}],
          'python_rerun':False,'queue_rerun':False,
          'files':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for name,data in sorted(items.items())}}
document('manifest.json',manifest)
output=root/'docs/evidence/f01-discard-retry-queue-message-host.zip'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for name,data in sorted(items.items()):z.writestr(name,data)
print(json.dumps({'archive':str(output),'bytes':output.stat().st_size,
                  'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'source_sha256':digest,
                  'source_inputs':len(paths),'zip_members':len(items),'methods':1019,'added':1,
                  'python_rerun':False,'queue_rerun':False},indent=2))
