# Truthful queue-rejection message for an unacknowledged capture clear

Verify with the unchanged portable verifier:
python3 scripts/verify-image-grid-evidence.py docs/evidence/f01-discard-retry-queue-message-host.zip --repo-root .

1019 actual unique JVM methods = parent-limited accepted016d1018 plus1; all previous
methods retained, zero failures/errors/skips. One complete run, no complete retry.
Exact source bytes/captures/XML/nanosecond times/method inventories are bound. Git
staged/final blob comparisons are recorded outside this archive. Queue149/Python151
are preserved historical evidence only, not rerun or new coverage.

Parent review found the real followup: after an actual discard commit loses its ACK,
a retry rejected before enqueue still said text/images were retained. They may already
have been cleaned. The actual new composite method first saves an encrypted draft
picture, performs real discard+lost ACK, and prepares another durable draft with its
own authenticated image. Rejected retry must report clear result still unverified,
never promise retained data; existing freeze and original clear identity must remain.
Successful retry then replays only the old clear; the newer draft, version/text/image
bytes remain unchanged, and a retained confirm cannot clear it again.

Actual baseline1 method failed at the inaccurate rejection message assertion. Identical
new test source is retained before/after. Corrected targeted17 pass (capture6/mixed7/Now4),
including the unchanged positive where first clear never enters the queue and cancel/
continued editing remains allowed. Raw baseline failure, logs, source and captures are
preserved. No assertion, deadline, first-rejection behavior or core receipt was loosened.

Production change only supplies a private optional submit rejection message, selected
from the PREVIOUS discardPending state when retrying the already-confirmed clear.
No transient false retained-data message is published for that retry. All other submit
calls and the known-not-executed first clear retain their original default behavior.
No schema/SQL/model/domain API, UI/navigation/native tests, permission, dependency,
workflow, AI/configuration or lifecycle change. Closed-owner/cold-start behavior was
source-reviewed only this slice, not a new executed race/native acceptance.

Initial normal Git read returned503, no mutation/denial/uncertain push. Its output was
preserved; exactly one normal read retry succeeded. No alternate route, TLS bypass,
credentials or Actions. The orchestration initially continued the known new regression
before inspecting failed preflight; only that requested test was changed, then carried
with identical HEAD/source bytes onto the isolated new branch before product edits.
No accepted commit or prior ZIP was rewritten. No unknown lock or process was removed.

Original plans and old archives unchanged; no SDK diagnosis repeated or agreement/
download/configuration/new permission/live key/model call. Real KSP11 then12 exports/
fixtures, Room/SQLCipher/Android/Compose/Preview/device remain NOT RUN, no new APK.
The separate model-entry analysis is read-only and not implemented in this patch.
New CI UNKNOWN; prior reported Android CI failures remain cause UNKNOWN; old AI
preparation assertion failure root remains UNKNOWN. Parent review of this followup
is pending. This does not expand F01/D03/native acceptance.
