from pathlib import Path
import ast, hashlib, json, zipfile, datetime, subprocess

root=Path('/workspace/AIyou')
evidence=Path('/workspace/scratch/aiyou-now-recent-records-20261017')
base='75e130d146e77ab722ea6a498a0a9b65ca0b5143'
items={}
def add(name,data):
    assert name not in items,name
    items[name]=data
def file(name,path):add(name,Path(path).read_bytes())
def document(name,value):add(name,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())

paths=[]
class Recorder:
    def __init__(self):self.h=hashlib.sha256();self.n=0
    def update(self,data):
        if self.n%2==0:
            assert data.endswith(b'\0')
            paths.append(data[:-1].decode())
        self.n+=1;self.h.update(data)
    def hexdigest(self):return self.h.hexdigest()
class RecordingHashlib:
    @staticmethod
    def sha256(data=None):return Recorder() if data is None else hashlib.sha256(data)
tree=ast.parse((root/'scripts/verify-ai-protocol-results.py').read_text())
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='input_fingerprint')
ns={'root':root,'hashlib':RecordingHashlib}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'<production fingerprint>','exec'),ns)
digest=ns['input_fingerprint']()
report=json.loads((evidence/'verified-contracts.json').read_text())
assert report['source_sha256']==digest and sum(m['tests']for m in report['results'])==1013
assert digest==json.loads((evidence/'full-inputs.json').read_text())['source_sha256']
for name in paths:file('closure/source-inputs/'+name,root/name)
file('closure/verified-report.json',evidence/'verified-contracts.json')
document('closure/methods.json',{r['module']:r['methods']for r in report['results']})
times={}
for module in report['results']:
    label=module['module'].split(':')[-1]
    folder=evidence/'raw-xml'/label
    path=folder/'inputs-at-test.json';key=f'closure/captures/{label}.json'
    file(key,path);times[key]=path.stat().st_mtime_ns
    for xml in module['xml']:
        path=folder/Path(xml['path']).name
        assert hashlib.sha256(path.read_bytes()).hexdigest()==xml['sha256']
        key=f'closure/xml/{label}/{path.name}';file(key,path);times[key]=path.stat().st_mtime_ns
document('closure/file-times.json',times)

old=root/'docs/evidence/f05-restored-people-publication-host.zip'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='f5ce596a9bfe58bb6d318d58582e5087d56787819f83524ae310f1872c64c1c7'
with zipfile.ZipFile(old)as z:
    for name in z.namelist():
        if name.startswith(('historical-queue/','historical-python/')):add(name,z.read(name))
    previous=json.loads(z.read('closure/verified-report.json'))
    before={tuple(c)for r in previous['results']for c in r['methods']}
    after={tuple(c)for r in report['results']for c in r['methods']}
    assert len(before)==1009 and before<=after and len(after-before)==4
    document('method-delta.json',{'base':base,'previous':1009,'current':1013,'added':sorted(after-before),'removed':[]})

for path in sorted(evidence.iterdir()):
    if path.is_file() and (path.suffix in ('.log','.json','.xml','.kt')or path.name.startswith('baseline-')or path.name=='package-evidence.py'):
        if path.name not in ('archive-receipt.json','verified-contracts.json','final-validation.json','writer-completed.json'):
            file('logs/'+path.name,path)
for path in sorted((evidence/'targeted-01-xml').glob('*.xml')):file('intermediate-targeted/'+path.name,path)
for path in sorted((evidence/'corrected-targeted-xml').glob('*.xml')):file('corrected-targeted/'+path.name,path)
for path in sorted((evidence/'full-01').rglob('*')):
    if path.is_file():file('intermediate-full-01/'+str(path.relative_to(evidence/'full-01')),path)
native='app/src/test/kotlin/com/t1doo/aiyou/MixedCapturePresentationTest.kt'
file('uncompiled-native-source/'+native,root/native)
document('uncompiled-native-source/status.json',{'source':native,'status':'NOT COMPILED / NOT RUN','existing_methods_extended':2,'new_methods':1,'exact_inventory_added':'scripts/verify-test-results.py','claim':'No Android/Compose/device/UI result is inferred from host state tests'})
file('verify.py',root/'scripts/verify-image-grid-evidence.py')
add('README.md',b'''# Now: today's recent records and original reader entry

Verify with the unchanged portable verifier:
python3 scripts/verify-image-grid-evidence.py docs/evidence/f01-now-recent-records-host.zip --repo-root .

1013 actual unique JVM methods = accepted75e1009 plus4, with zero failures/errors/skips.
All1009 previous methods remain. Exact source bytes, captures, nanosecond XML times,
raw XML and method inventories are bound. Final Git blob verification is recorded
outside this archive after the commit. First full1012 passed, then the reader-exit
warning regression was reproduced and corrected. Final full1013 is authoritative;
no repeated identical-source full run is claimed.

This is a missing visible feature, not an existing failing transaction. The baseline
production MainActivity Now route selects MixedCaptureScreen. That component has no
record-list consumption or reader callback although save publishes durable entries.
Both original plans require today's recent records. Baseline component and route
bytes are preserved; NO baseline red Compose or host test is claimed.

The production screen now uses the already published records, device-zone capture-day
half-open bounds and original source order, at most5. Current text/image-only entries
reuse the existing MemoryCard, full-original reader and attachment route. No thumbnail
decode, schema, SQL mutation, permission, dependency, cache, AI call or network change.
Stable item keys and Main's existing nowList preserve scrolling across inserts/reading.
Only explicit new-content/continue-record buttons scroll. Date/zone checks are memory
only, each minute while composed. Original input/saving/receipts remain unchanged.

New actual VM/SQL test saves Chinese text plus a real authenticated encrypted image,
verifies immediate published record and Chinese search, keeps next draft, performs
actual user-confirmed trash and restore, checks recent-record removal/return, same ID,
AI_NONE restore policy and exact image bytes. Other tests cover the failed draft-warning preservation on the actual onDispose
controller callback and explicit save recovery (one genuine red before correction),
lost ACK/readback,
explicit stable-identity retry, source-order/cap/current-version and23/25-hour DST days,
half-open day bounds and unreadable/disposed owner. Host platform shells are used.

Intermediate targeted10 methods passed before the final UI-only shortcut adjustment;
their raw XML/log/capture are retained, not represented as a separate final cohort.
An intermediate complete1012 pass before the warning fix is also preserved.
Final complete1013 closure is authoritative. Compose source extends2 existing methods
and adds1, with exact inventory registration. NONE was compiled/run. Reader navigation,
200% font/320dp, scroll stability, IME, Preview/device/accessibility remain NOT RUN.

Historical queue149/Python151 are retained solely for portable verifier compatibility,
neither suite rerun here. Old AI preparation assertion failure root remains UNKNOWN;
original evidence archives/logs remain unchanged. CI246/cd5/771 FAIL by parent original
notification emails, cause UNKNOWN;75e and new commit CI UNKNOWN. No Actions/alternate
access. SDK terms/notification permissions remain unapproved, no download/configuration.
Genuine Room11/12 schema pairs still require approved toolchain, real KSP commits and
native migration/SQLCipher verification. No new APK or native acceptance is claimed.
''')
manifest={'format':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'cohorts':[{'id':'closure','source_prefix':'closure/source-inputs/','source_sha256':digest,
                      'tests':1013,'execution_git_head':report['head'],'source_git_base':base}],
          'python_rerun':False,'queue_rerun':False,
          'files':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for name,data in sorted(items.items())}}
document('manifest.json',manifest)
output=root/'docs/evidence/f01-now-recent-records-host.zip'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for name,data in sorted(items.items()):z.writestr(name,data)
print(json.dumps({'archive':str(output),'bytes':output.stat().st_size,
                  'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'source_sha256':digest,
                  'source_inputs':len(paths),'zip_members':len(items),'methods':1013,'added':4,
                  'python_rerun':False,'queue_rerun':False},indent=2))
