# Now: today's recent records and original reader entry

Verify with the unchanged portable verifier:
python3 scripts/verify-image-grid-evidence.py docs/evidence/f01-now-recent-records-host.zip --repo-root .

1013 actual unique JVM methods = accepted75e1009 plus4, with zero failures/errors/skips.
All1009 previous methods remain. Exact source bytes, captures, nanosecond XML times,
raw XML and method inventories are bound. Final Git blob verification is recorded
outside this archive after the commit. First full1012 passed, then the reader-exit
warning regression was reproduced and corrected. Final full1013 is authoritative;
no repeated identical-source full run is claimed.

This is a missing visible feature, not an existing failing transaction. The baseline
production MainActivity Now route selects MixedCaptureScreen. That component has no
record-list consumption or reader callback although save publishes durable entries.
Both original plans require today's recent records. Baseline component and route
bytes are preserved; NO baseline red Compose or host test is claimed.

The production screen now uses the already published records, device-zone capture-day
half-open bounds and original source order, at most5. Current text/image-only entries
reuse the existing MemoryCard, full-original reader and attachment route. No thumbnail
decode, schema, SQL mutation, permission, dependency, cache, AI call or network change.
Stable item keys and Main's existing nowList preserve scrolling across inserts/reading.
Only explicit new-content/continue-record buttons scroll. Date/zone checks are memory
only, each minute while composed. Original input/saving/receipts remain unchanged.

New actual VM/SQL test saves Chinese text plus a real authenticated encrypted image,
verifies immediate published record and Chinese search, keeps next draft, performs
actual user-confirmed trash and restore, checks recent-record removal/return, same ID,
AI_NONE restore policy and exact image bytes. Other tests cover the failed draft-warning preservation on the actual onDispose
controller callback and explicit save recovery (one genuine red before correction),
lost ACK/readback,
explicit stable-identity retry, source-order/cap/current-version and23/25-hour DST days,
half-open day bounds and unreadable/disposed owner. Host platform shells are used.

Intermediate targeted10 methods passed before the final UI-only shortcut adjustment;
their raw XML/log/capture are retained, not represented as a separate final cohort.
An intermediate complete1012 pass before the warning fix is also preserved.
Final complete1013 closure is authoritative. Compose source extends2 existing methods
and adds1, with exact inventory registration. NONE was compiled/run. Reader navigation,
200% font/320dp, scroll stability, IME, Preview/device/accessibility remain NOT RUN.

Historical queue149/Python151 are retained solely for portable verifier compatibility,
neither suite rerun here. Old AI preparation assertion failure root remains UNKNOWN;
original evidence archives/logs remain unchanged. CI246/cd5/771 FAIL by parent original
notification emails, cause UNKNOWN;75e and new commit CI UNKNOWN. No Actions/alternate
access. SDK terms/notification permissions remain unapproved, no download/configuration.
Genuine Room11/12 schema pairs still require approved toolchain, real KSP commits and
native migration/SQLCipher verification. No new APK or native acceptance is claimed.
