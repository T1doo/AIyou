import sys,re,time,json
from pathlib import Path
from runpy import run_path
root=Path(__file__).resolve().parent;mode=sys.argv[1]
sys.argv=['device.py','library'];api=run_path(str(root/'device.py'));adb=api['adb'];nodes=api['nodes']
def rect(n):return tuple(map(int,re.findall(r'\d+',n.get('bounds'))))
def tap(n):
    l,t,r,b=rect(n);assert r>l and b>t
    adb('shell','input','tap',str((l+r)//2),str((t+b)//2))
def find(text,scroll=False,bottom=False):
    for _ in range(10):
        ns=nodes();found=[n for n in ns if n.get('text')==text or n.get('content-desc')==text]
        if bottom and found:return max(found,key=lambda n:rect(n)[1])
        if len(found)==1:return found[0]
        if scroll:
            lists=[n for n in ns if n.get('package')=='com.t1doo.aiyou' and n.get('scrollable')=='true']
            if lists:
                l,t,r,b=rect(max(lists,key=lambda n:(rect(n)[2]-rect(n)[0])*(rect(n)[3]-rect(n)[1])))
                adb('shell','input','swipe',str(r-24),str(t+(b-t)*3//4),str(r-24),str(t+(b-t)//4),'350')
        time.sleep(.2)
    raise RuntimeError('Actual UI target unavailable: '+text)
def click(text,scroll=False,bottom=False):tap(find(text,scroll,bottom))
def capture(name):
    nodes();(root/(name+'.xml')).write_bytes((root/'window.xml').read_bytes());(root/(name+'.png')).write_bytes(adb('exec-out','screencap','-p'))
def open_history():
    ns=nodes()
    if any(n.get('text') in ('问题收藏','问题正文','关闭','保存问题') for n in ns):return
    click('已保存的问题（仅本机）',scroll=True);find('问题收藏')
def profile(name):
    open_history();find('关闭',scroll=True)
    for _ in range(6):
        ns=nodes();parents={c:p for p in ns for c in p}
        label=next(n for n in ns if n.get('text')=='关闭');button=label
        while button.get('clickable')!='true':button=parents[button]
        assert button.get('enabled')=='true'
        b=rect(button);bounds=rect(ns[0])
        if b[2]-b[0]>=144 and b[3]-b[1]>=144 and bounds[0]<=b[0]<b[2]<=bounds[2] and bounds[1]<=b[1]<b[3]<=bounds[3]:break
        lists=[n for n in ns if n.get('package')=='com.t1doo.aiyou' and n.get('scrollable')=='true']
        assert lists,'Partial close control has no scrollable viewport'
        l,t,r,bottom=rect(max(lists,key=lambda n:(rect(n)[2]-rect(n)[0])*(rect(n)[3]-rect(n)[1])))
        adb('shell','input','swipe',str(r-24),str(t+(bottom-t)*3//4),str(r-24),str(t+(bottom-t)//4),'350')
    else:raise RuntimeError('Close control cannot be fully exposed after bounded actual scrolling')
    capture(name)
    receipt={'close_button':b,'active_window':bounds,'font_scale':adb('shell','settings','get','system','font_scale').decode().strip(),'rotation':adb('shell','settings','get','system','user_rotation').decode().strip(),'no_save_delete_or_use_clicked':True}
    (root/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(receipt)
    click('关闭')

if mode=='entry':
    click('回忆',bottom=True)
    for _ in range(8):
        e=[n for n in nodes() if n.get('class')=='android.widget.EditText']
        if len(e)==1:break
    assert len(e)==1;tap(e[0]);adb('shell','input','text','Keyboard')
    ime=adb('shell','dumpsys','input_method').decode(errors='replace')
    if re.search(r'(?m)^\s*mInputShown=true\b',ime):adb('shell','input','keyevent','4')
    find('问一问 · 选取本机出处');capture('entry-with-query')
    click('问一问 · 选取本机出处');find('问一问 · 返回原文列表');capture('local-source-entry')
    click('问一问 · 返回原文列表');click('筛选');click('更多查找设置');click('清空全部查找，包括搜索词')
    print('PASS: local-source entry reachable without More, no model connection/consent/send clicked; query cleared')
elif mode=='normal':
    click('设置');profile('history-normal')
elif mode=='large':
    adb('shell','settings','put','system','font_scale','2.0')
elif mode=='large-profile':profile('history-large')
elif mode=='landscape':
    adb('shell','settings','put','system','accelerometer_rotation','0');adb('shell','settings','put','system','user_rotation','1')
elif mode=='landscape-profile':profile('history-landscape-large')
elif mode=='restore':
    original=json.loads((root/'original-settings.json').read_text())
    for k,v in original.items():adb('shell','settings','delete' if v=='null' else 'put','system',k,*([] if v=='null' else [v]))
    after={k:adb('shell','settings','get','system',k).decode().strip() for k in original};assert after==original
    (root/'restored-settings.json').write_text(json.dumps(after,indent=2)+'\n');print('PASS: original device settings restored')
else:raise ValueError(mode)
