# F05 stale people editor source authority repair

Verify with the unchanged repository script:
python3 scripts/verify-image-grid-evidence.py docs/evidence/f05-people-source-fence-host.zip --repo-root .
No extraction, SDK, network or new dependency is needed; verify.py is also retained.

Final closure: actual 991 unique JVM methods, baseline inventory988 plus3;
all original methods retained, zero failures/errors/skips. Raw XML, input captures,
nanosecond mtimes, exact methods, report and every source-input byte are included.
Execution HEAD is the base before commit; final Git blobs and captured fingerprint
bind the tested source. Android sources are byte-bound, not proof of compilation.

Three before-fix regressions actually wrote names from an old reader/editor into
an unseen new original or a trash-restored generation. Raw failed XML/logs/input
capture are preserved. Ten real ViewModel/SQL cases pass after fixing authority.
The final regression helper also waits for an explicit serial refresh barrier.
The first full round failed an unchanged AI fixture request-arrival 1-second
readiness assertion, before its revocation action. Its cause remains UNKNOWN.
The unchanged isolated case passed; one bounded full retry uses max-workers=1
without changing test assertions or deadlines. Failed full-round XML/logs are
retained under failed-full-01/ and logs/. Final full-round log is full-02-jvm.log.
No tests here use a live model or Android platform. SQL is production code on host
SQLite; the actual App ViewModel/controller runs on existing JVM platform shells.

The editor captures its original hash, never changes its original revision, and
refuses reads with another source/hash or a different previously observed access
generation. Failure retains user input and the old source anchor, without success
or new write. Same-source name conflict reload and uncertain ACK retry still work;
a fresh session after refreshing the original can make an explicit new write.

Historical queue149 and Python151 are copied byte-for-byte for compatibility with
the existing verifier, not rerun or additive coverage. No Python suite rerun here.
No schema/migration/workflow/dependency/permission change, no SDK download or terms
acceptance, no device/model use, no deployment. Existing Android/real Room11/12,
SQLCipher/Compose/Preview/device gates remain NOT RUN, no new APK, CI UNKNOWN.
Actions remains unaccessed. Independent review remains pending.
