from pathlib import Path
import ast,hashlib,json,zipfile,datetime,subprocess
root=Path('/workspace/AIyou');evidence=Path('/workspace/scratch/aiyou-fence-review-20261017');items={}
def add(name,data):
 assert name not in items,name
 items[name]=data
def file(name,path):add(name,Path(path).read_bytes())
def document(name,value):add(name,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
paths=[]
class Recorder:
 def __init__(self):self.h=hashlib.sha256();self.n=0
 def update(self,data):
  if self.n%2==0:assert data.endswith(b'\0');paths.append(data[:-1].decode())
  self.n+=1;self.h.update(data)
 def hexdigest(self):return self.h.hexdigest()
class RecordingHashlib:
 @staticmethod
 def sha256(data=None):return Recorder() if data is None else hashlib.sha256(data)
tree=ast.parse((root/'scripts/verify-ai-protocol-results.py').read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='input_fingerprint')
ns={'root':root,'hashlib':RecordingHashlib};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<production fingerprint>','exec'),ns)
digest=ns['input_fingerprint']();report=json.loads((evidence/'verified-contracts.json').read_text())
assert report['source_sha256']==digest and sum(m['tests']for m in report['results'])==991
for name in paths:file('closure/source-inputs/'+name,root/name)
file('closure/verified-report.json',evidence/'verified-contracts.json');document('closure/methods.json',{r['module']:r['methods']for r in report['results']})
times={}
for module in report['results']:
 label=module['module'].split(':')[-1];folder=evidence/'raw-xml'/label;path=folder/'inputs-at-test.json';key=f'closure/captures/{label}.json';file(key,path);times[key]=path.stat().st_mtime_ns
 for xml in module['xml']:
  path=folder/Path(xml['path']).name;assert hashlib.sha256(path.read_bytes()).hexdigest()==xml['sha256'];key=f'closure/xml/{label}/{path.name}';file(key,path);times[key]=path.stat().st_mtime_ns
document('closure/file-times.json',times)
base='e24f25a1dc43359d101e28f431c796e10a3b4397';old=root/'docs/evidence/f05-manual-people-host.zip'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='f171ea518ca30d0a8b61a0b8748dcec3b6c2ae30ee6641e52f4817a090b53369'
with zipfile.ZipFile(old)as z:
 for name in z.namelist():
  if name.startswith('historical-queue/')or name.startswith('historical-python/'):add(name,z.read(name))
 previous=json.loads(z.read('closure/verified-report.json'));before={tuple(c)for r in previous['results']for c in r['methods']};after={tuple(c)for r in report['results']for c in r['methods']}
 assert len(before)==988 and before<=after and len(after-before)==3
 document('method-delta.json',{'base':base,'previous':988,'current':991,'added':sorted(after-before),'removed':[]})
add('reproducer/baseline-controller.kt',subprocess.check_output(['git','show',base+':app/src/main/java/com/t1doo/aiyou/records/ManualPeopleController.kt'],cwd=root))
for path in sorted(evidence.iterdir()):
 if path.is_file()and(path.suffix in('.log','.xml')or path.name in('reproducer-before-fix-inputs.json','viewmodel-after-fix-inputs.json','fingerprint-verification.json','review-receipt.json','full-01-observation.json','ai-boundary-isolated-inputs.json','package-evidence.py')):file('logs/'+path.name,path)
for path in sorted((evidence/'full-01-raw').rglob('*')):
 if path.is_file():file('failed-full-01/'+path.relative_to(evidence/'full-01-raw').as_posix(),path)
file('verify.py',root/'scripts/verify-image-grid-evidence.py')
add('README.md',b'''# F05 stale people editor source authority repair

Verify with the unchanged repository script:
python3 scripts/verify-image-grid-evidence.py docs/evidence/f05-people-source-fence-host.zip --repo-root .
No extraction, SDK, network or new dependency is needed; verify.py is also retained.

Final closure: actual 991 unique JVM methods, baseline inventory988 plus3;
all original methods retained, zero failures/errors/skips. Raw XML, input captures,
nanosecond mtimes, exact methods, report and every source-input byte are included.
Execution HEAD is the base before commit; final Git blobs and captured fingerprint
bind the tested source. Android sources are byte-bound, not proof of compilation.

Three before-fix regressions actually wrote names from an old reader/editor into
an unseen new original or a trash-restored generation. Raw failed XML/logs/input
capture are preserved. Ten real ViewModel/SQL cases pass after fixing authority.
The final regression helper also waits for an explicit serial refresh barrier.
The first full round failed an unchanged AI fixture request-arrival 1-second
readiness assertion, before its revocation action. Its cause remains UNKNOWN.
The unchanged isolated case passed; one bounded full retry uses max-workers=1
without changing test assertions or deadlines. Failed full-round XML/logs are
retained under failed-full-01/ and logs/. Final full-round log is full-02-jvm.log.
No tests here use a live model or Android platform. SQL is production code on host
SQLite; the actual App ViewModel/controller runs on existing JVM platform shells.

The editor captures its original hash, never changes its original revision, and
refuses reads with another source/hash or a different previously observed access
generation. Failure retains user input and the old source anchor, without success
or new write. Same-source name conflict reload and uncertain ACK retry still work;
a fresh session after refreshing the original can make an explicit new write.

Historical queue149 and Python151 are copied byte-for-byte for compatibility with
the existing verifier, not rerun or additive coverage. No Python suite rerun here.
No schema/migration/workflow/dependency/permission change, no SDK download or terms
acceptance, no device/model use, no deployment. Existing Android/real Room11/12,
SQLCipher/Compose/Preview/device gates remain NOT RUN, no new APK, CI UNKNOWN.
Actions remains unaccessed. Independent review remains pending.
''')
manifest={'format':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cohorts':[{'id':'closure','source_prefix':'closure/source-inputs/','source_sha256':digest,'tests':991,'execution_git_head':report['head'],'source_git_base':base}],'python_rerun':False,'queue_rerun':False,'files':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for name,data in sorted(items.items())}}
document('manifest.json',manifest);output=root/'docs/evidence/f05-people-source-fence-host.zip'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,data in sorted(items.items()):z.writestr(name,data)
print(json.dumps({'archive':str(output),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'source_sha256':digest,'source_inputs':len(paths),'zip_members':len(items),'methods':991,'added':3,'python_rerun':False,'queue_rerun':False},indent=2))
