# F05 manual people associations and explicit combined person filter

Verify offline without extraction, SDK, network or dependencies:
python3 scripts/verify-image-grid-evidence.py docs/evidence/f05-manual-people-host.zip --repo-root .
The repository verifier is unchanged from the accepted baseline. The ZIP also has verify.py.

closure/ holds original XML, exact method lists, input captures, nanosecond mtimes,
verified report, and every source-input byte from the final 988-method JVM run.
All accepted 962 methods remain; method-delta.json lists 26 new methods (SQL11,
portability6, actual ViewModel7, actual App search controller2). Earlier SQL11,
partial24 and targeted26 rounds are separate evidence, never additive coverage.
Execution HEAD is the accepted base before committing tested changes. Final Git
blob comparisons and the captured input fingerprint bind the tested source.
Android sources in the fingerprint prove byte binding, not Android compilation.

current-python/tests.log is the actual current 153-case run: accepted151 plus2
schema admission controls. The retained historical queue149 and Python151 are
copied unchanged from the accepted base; queue149 was NOT rerun or added again.
All early failures are preserved: first test-setup smart-cast/type compile errors,
then a new test incorrectly counting trash as permanent erasure; a subsequent
compile caught a wrong test property name. Fixes preserve the existing contracts.
The final target/full rounds must have zero failures/errors/skips. No blind CI rerun.

Actual host scope: production SQL on host SQLite, real JCA AEAD and package codecs,
real App ViewModel/controllers on platform shells, original search proof/resolve.
Manual names are record metadata, never inferred identities or historical facts.
Default LOCAL_ONLY unchanged. Restore creates independent AI_NONE copies without
remote grants; old receipts cannot overwrite later names or resurrect erased copies.
No model calls, dependencies, credentials, permissions or plaintext cache added.
D06 answer prototype unchanged; real Activity still has no answer provider.

SDK preflight FAIL and missing real Room11 predecessor/v12 gate FAIL are preserved.
No fabricated Room11/12 JSON. Actual KSP11 must be obtained and checked in from the
accepted v11 source before KSP12 can run, then both require exact-head byte checks.
Android/Room11->12/SQLCipher/Compose/Preview/device/lint/assemble all NOT RUN.
Three new Compose and two new native test SOURCE methods are registered but unrun.
No APK, installation, SDK terms acceptance, notification setup or deployment.
No Actions access; prior denial respected. Old CI failures remain tied to their
own heads and unknown causes; current CI UNKNOWN. Independent review pending.
