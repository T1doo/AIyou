from pathlib import Path
import ast,hashlib,json,zipfile,datetime,re
root=Path('/workspace/AIyou');evidence=Path('/workspace/scratch/aiyou-manual-people-tests')
items={}
def add(name,data):
 assert name not in items,name
 items[name]=data
def file(name,path):add(name,Path(path).read_bytes())
def document(name,value):add(name,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
paths=[]
class Recorder:
 def __init__(self):self.h=hashlib.sha256();self.n=0
 def update(self,data):
  if self.n%2==0:assert data.endswith(b'\0');paths.append(data[:-1].decode())
  self.n+=1;self.h.update(data)
 def hexdigest(self):return self.h.hexdigest()
class RecordingHashlib:
 @staticmethod
 def sha256(data=None):return Recorder() if data is None else hashlib.sha256(data)
tree=ast.parse((root/'scripts/verify-ai-protocol-results.py').read_text())
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='input_fingerprint')
ns={'root':root,'hashlib':RecordingHashlib}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'<production fingerprint>','exec'),ns)
digest=ns['input_fingerprint']()
report=json.loads((evidence/'verified-contracts.json').read_text())
assert report['source_sha256']==digest
assert sum(m['tests'] for m in report['results'])==988
for name in paths:file('closure/source-inputs/'+name,root/name)
file('closure/verified-report.json',evidence/'verified-contracts.json')
document('closure/methods.json',{r['module']:r['methods'] for r in report['results']})
times={}
for module in report['results']:
 label=module['module'].split(':')[-1];folder=evidence/'raw-xml'/label
 path=folder/'inputs-at-test.json';key=f'closure/captures/{label}.json';file(key,path);times[key]=path.stat().st_mtime_ns
 for xml in module['xml']:
  path=folder/Path(xml['path']).name;assert hashlib.sha256(path.read_bytes()).hexdigest()==xml['sha256']
  key=f'closure/xml/{label}/{path.name}';file(key,path);times[key]=path.stat().st_mtime_ns
document('closure/file-times.json',times)
old=root/'docs/evidence/d06-selected-answer-host.zip'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='87fe16d87b3fee3409e68869e92f2e7c079585d322e8d896de24aee67f86834a'
with zipfile.ZipFile(old) as z:
 for name in z.namelist():
  if name.startswith('historical-queue/') or name.startswith('historical-python/'):add(name,z.read(name))
 base=json.loads(z.read('closure/verified-report.json'))
 base_methods={tuple(case) for r in base['results'] for case in r['methods']}
 current_methods={tuple(case) for r in report['results'] for case in r['methods']}
 assert len(base_methods)==962 and base_methods<=current_methods and len(current_methods-base_methods)==26
 document('method-delta.json',{'accepted_base':'cbaf2618f7d8c2cb6f85d6dd621c001944958ffc','old':962,'current':988,
  'added':sorted(current_methods-base_methods),'removed':sorted(base_methods-current_methods)})
file('current-python/tests.log',evidence/'python-tests-01.log')
text=items['current-python/tests.log'].decode();assert re.findall(r'Ran (\d+) tests',text)==['153'] and text.strip().endswith('EXIT_CODE=0') and '\nOK\n' in text
for path in sorted(evidence.iterdir()):
 if path.is_file() and (path.suffix in ('.log','.xml') or path.name in ('people-sql-01-inputs.json','people-all-02-inputs.json','people-all-04-inputs.json','fingerprint-verification.json','scope-preflight.json','self-review.json','device-inventory.json','original-plan-hashes.json','unknown-lock-preserved.json','http-dependencies.json','package-evidence.py')):
  file('logs/'+path.name,path)
file('verify.py',root/'scripts/verify-image-grid-evidence.py')
add('README.md',b'''# F05 manual people associations and explicit combined person filter

Verify offline without extraction, SDK, network or dependencies:
python3 scripts/verify-image-grid-evidence.py docs/evidence/f05-manual-people-host.zip --repo-root .
The repository verifier is unchanged from the accepted baseline. The ZIP also has verify.py.

closure/ holds original XML, exact method lists, input captures, nanosecond mtimes,
verified report, and every source-input byte from the final 988-method JVM run.
All accepted 962 methods remain; method-delta.json lists 26 new methods (SQL11,
portability6, actual ViewModel7, actual App search controller2). Earlier SQL11,
partial24 and targeted26 rounds are separate evidence, never additive coverage.
Execution HEAD is the accepted base before committing tested changes. Final Git
blob comparisons and the captured input fingerprint bind the tested source.
Android sources in the fingerprint prove byte binding, not Android compilation.

current-python/tests.log is the actual current 153-case run: accepted151 plus2
schema admission controls. The retained historical queue149 and Python151 are
copied unchanged from the accepted base; queue149 was NOT rerun or added again.
All early failures are preserved: first test-setup smart-cast/type compile errors,
then a new test incorrectly counting trash as permanent erasure; a subsequent
compile caught a wrong test property name. Fixes preserve the existing contracts.
The final target/full rounds must have zero failures/errors/skips. No blind CI rerun.

Actual host scope: production SQL on host SQLite, real JCA AEAD and package codecs,
real App ViewModel/controllers on platform shells, original search proof/resolve.
Manual names are record metadata, never inferred identities or historical facts.
Default LOCAL_ONLY unchanged. Restore creates independent AI_NONE copies without
remote grants; old receipts cannot overwrite later names or resurrect erased copies.
No model calls, dependencies, credentials, permissions or plaintext cache added.
D06 answer prototype unchanged; real Activity still has no answer provider.

SDK preflight FAIL and missing real Room11 predecessor/v12 gate FAIL are preserved.
No fabricated Room11/12 JSON. Actual KSP11 must be obtained and checked in from the
accepted v11 source before KSP12 can run, then both require exact-head byte checks.
Android/Room11->12/SQLCipher/Compose/Preview/device/lint/assemble all NOT RUN.
Three new Compose and two new native test SOURCE methods are registered but unrun.
No APK, installation, SDK terms acceptance, notification setup or deployment.
No Actions access; prior denial respected. Old CI failures remain tied to their
own heads and unknown causes; current CI UNKNOWN. Independent review pending.
''')
manifest={'format':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'cohorts':[{'id':'closure','source_prefix':'closure/source-inputs/','source_sha256':digest,'tests':988,
  'execution_git_head':report['head'],'source_git_base':'cbaf2618f7d8c2cb6f85d6dd621c001944958ffc'}],
 'current_python_tests':153,'new_python_methods':2,'historical_queue_tests':149,'queue_rerun':False,
 'files':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(items.items())}}
document('manifest.json',manifest)
output=root/'docs/evidence/f05-manual-people-host.zip'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(items.items()):z.writestr(name,data)
print(json.dumps({'archive':str(output),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
 'source_sha256':digest,'source_inputs':len(paths),'files':len(items),'methods':988,'added':26,'python':153,'new_python_methods':2},indent=2))
