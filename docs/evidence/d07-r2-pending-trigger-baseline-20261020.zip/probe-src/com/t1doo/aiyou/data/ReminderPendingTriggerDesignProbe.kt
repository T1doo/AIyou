package com.t1doo.aiyou.data

import com.t1doo.aiyou.domain.*
import com.t1doo.aiyou.model.*
import org.junit.Assert.*
import org.junit.Test

/** Isolated R1 baseline probe. No platform APIs, production edits or accepted gate changes. */
class ReminderPendingTriggerDesignProbe {
    @Test fun successfulPlatformScheduleWithoutDatabaseAckMustNotLoseItsOnlyDueTrigger() {
        exercise(ackCommitted = false)
    }

    @Test fun committedDatabaseAckWithUnknownReturnAlreadyAcceptsTheOnlyDueTrigger() {
        exercise(ackCommitted = true)
    }

    private fun exercise(ackCommitted: Boolean) = LocalCandidateFixture().use { local ->
        var actual = SqlManualTaskRepository(local.gateway, LocalCandidateFixture.KEY)
        var schedules = 0
        try {
            val due = ManualTaskDateSqlTest.date("2042-11-19", "09:30", "Pacific/Chatham")
            val availability = TaskReminderAvailability(true, TaskReminderPermission.GRANTED, TaskReminderPermission.GRANTED)
            val initial = actual.create(ManualTaskCreate("synthetic-one", "合成明确待办", 55, "UTC", "create", due))
            val confirmed = actual.changeReminder(TaskReminderMutation(initial, TaskReminderMode.EXACT, 99, "confirm"))
            val command = confirmed.reminder!!.commands.single()
            val uncertain = object : TaskReminderRepository by actual {
                override fun acknowledgeReminder(command: TaskReminderCommand, result: TaskReminderPhase, atMillis: Long): Boolean {
                    if (ackCommitted) assertTrue(actual.acknowledgeReminder(command, result, atMillis))
                    error("Synthetic system ACK unavailable at selected boundary")
                }
            }
            val driver = object : TaskReminderDriver {
                override fun availability() = availability
                override fun schedule(command: TaskReminderCommand): TaskReminderPhase { schedules++; return TaskReminderPhase.SCHEDULED }
                override fun cancel(command: TaskReminderCommand) = TaskReminderPhase.REVOKED
            }
            assertEquals(0, TaskReminderDispatcher(uncertain, driver) { 110 }.drain())
            assertEquals(1, schedules)
            assertEquals(if (ackCommitted) TaskReminderPhase.SCHEDULED else TaskReminderPhase.PENDING,
                actual.snapshots().single().reminder!!.phase)
            actual.wipeKey(); local.reopen()
            actual = SqlManualTaskRepository(local.gateway, LocalCandidateFixture.KEY)
            val dueMillis = due.instant()!!.toEpochMilli()
            // One real callback; do not drain/re-schedule an alarm at or after its past due time.
            assertTrue("The authenticated current token must retain its sole actual due callback even before schedule ACK",
                actual.acceptReminderTrigger(command.token, dueMillis, availability))
            assertFalse(actual.acceptReminderTrigger(command.token, dueMillis, availability))
            assertEquals(TaskReminderPhase.TRIGGER_ACCEPTED, actual.snapshots().single().reminder!!.phase)
            assertEquals(1, schedules)
        } finally { actual.wipeKey() }
    }
}
