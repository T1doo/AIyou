# 因果失败与本轮范围

- 首个CLI额外传--console=plain与既有jvm wrapper重复，未进入编译；原工具输出保留在会话，完整帮助文本不在此包，不能将其算产品编译。
- r1-vm-compile.log：UI包装误触SelectedImageSource接口、回调返回类型、构造参数尾lambda和递归推断；按编译原文修复。
- r1-playback-tests.log：新测试nullable capability调用；r1-playback-tests-retry.log和对应failure XML：新测试把list传给SQLite vararg，非生产数据修复。
- r1-production-gate-native-retry.log：宿主缺ArchTaskExecutor；只补已在生产app锁定的Room运行依赖，无生产SDK/权限变化。
- r1-full-native-4a2a4a5.log：新中断行fixture arrayOf异构推断编译错误；显式Any?修正，业务门未降级。
- 自审发现旧Compose闭包在配置销毁后仍被File Request持有：改VM路由代数与前台一次领取，加回归后重做必要完整合同/队列/原生门。

只有final目录的三门作为最终b71结果；intermediate和其他日志不重复计数。APK/Compose/Preview、真设备/实录没有借用旧CI或合成输入充当通过。
