"""Verify a FAILURE artifact's bytes/observations. This does not pass the product test gate."""
import argparse,hashlib,json,zipfile,xml.etree.ElementTree as E
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('archive');p.add_argument('--repo-root');a=p.parse_args()
with zipfile.ZipFile(a.archive)as z:
    m=json.loads(z.read('manifest.json'));assert m['format']=='AIyou.failure-evidence.v1'and m['test_gate']=='FAIL'
    assert set(z.namelist())==set(m['files'])|{'manifest.json'}
    for n,v in m['files'].items():
        b=z.read(n);assert len(b)==v['bytes']and hashlib.sha256(b).hexdigest()==v['sha256'],n
    h=hashlib.sha256()
    for n in sorted(m['source_inputs']):
        b=z.read('failure/source-inputs/'+n);h.update(n.encode()+b'\0');h.update(hashlib.sha256(b).digest())
        if a.repo_root:assert b==(Path(a.repo_root)/n).read_bytes(),n
    assert h.hexdigest()==m['source_sha256']
    times=json.loads(z.read('file-times.json'))
    for run in ('first-full-failure','second-full-failure'):
        actual=set();failed=[]
        for module in ('ai','domain','remote-text'):
            prefix='runs/'+run+'/'+module+'/';capture=json.loads(z.read(prefix+'inputs-at-test.json'))
            assert capture['source_sha256']==m['source_sha256']
            for n in z.namelist():
                if n.startswith(prefix+'TEST-')and n.endswith('.xml'):
                    assert times[n]>=times[prefix+'inputs-at-test.json']
                    t=E.fromstring(z.read(n));assert int(t.get('errors','0'))==int(t.get('skipped','0'))==0
                    for c in t.findall('testcase'):
                        k=(c.get('classname'),c.get('name'));assert k not in actual;actual.add(k)
                        if c.find('failure')is not None:
                            assert 'expected:<10> but was:<11>' in c.find('failure').get('message','')
                            failed.append(k)
        assert actual=={tuple(k)for k in m['full_method_inventory']}and len(actual)==1039
        assert failed==[tuple(m['failed_method'])]
    for folder,count in [('targeted-xml',24),('isolated-date-epoch',1)]:
        cases=[]
        for n in z.namelist():
            if n.startswith('runs/'+folder+'/TEST-')and n.endswith('.xml'):
                t=E.fromstring(z.read(n));assert all(int(t.get(k,'0'))==0 for k in ('failures','errors','skipped'));cases.extend(t.findall('testcase'))
        assert len(cases)==count,(folder,len(cases))
print(json.dumps({'artifact_integrity':'PASS','test_gate':'FAIL; no acceptance claimed','full_runs':2,'methods_per_run':1039,'failures_each_run':1,'targeted':24,'isolated':1,'source_inputs':len(m['source_inputs']),'source_sha256':m['source_sha256']},indent=2))
