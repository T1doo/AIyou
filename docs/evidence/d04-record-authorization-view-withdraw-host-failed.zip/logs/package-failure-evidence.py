from pathlib import Path
import ast,hashlib,json,zipfile,datetime,xml.etree.ElementTree as E
r=Path('/workspace/AIyou');e=Path('/workspace/scratch/aiyou-record-authorization-ui-20261017');items={};paths=[]
def add(n,b):assert n not in items,n;items[n]=b
def file(n,p):add(n,Path(p).read_bytes())
class Recorder:
    def __init__(self):self.h=hashlib.sha256();self.n=0
    def update(self,b):
        if self.n%2==0:assert b.endswith(b'\0');paths.append(b[:-1].decode())
        self.n+=1;self.h.update(b)
    def hexdigest(self):return self.h.hexdigest()
class RecordingHashlib:
    @staticmethod
    def sha256(b=None):return Recorder()if b is None else hashlib.sha256(b)
fn=next(n for n in ast.parse((r/'scripts/verify-ai-protocol-results.py').read_text()).body if isinstance(n,ast.FunctionDef)and n.name=='input_fingerprint')
ns={'root':r,'hashlib':RecordingHashlib};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<unchanged input fingerprint>','exec'),ns);digest=ns['input_fingerprint']()
assert digest==json.loads((e/'full-inputs.json').read_text())['source_sha256']=='f48527eef386f4537224372f35bac9007a2f74799660e9ef6f667b5f6a0ae10c'
for p in paths:file('failure/source-inputs/'+p,r/p)
methods=set();failed=[]
for x in (e/'second-full-failure').rglob('TEST-*.xml'):
    for c in E.parse(x).getroot().findall('testcase'):
        k=(c.get('classname'),c.get('name'));assert k not in methods;methods.add(k)
        if c.find('failure')is not None:failed.append(k)
assert len(methods)==1039 and len(failed)==1
times={}
for folder in ('initial-targeted-failure','second-targeted-failure','targeted-xml','first-full-failure','second-full-failure','isolated-date-epoch'):
    for p in sorted((e/folder).rglob('*')):
        if p.is_file():
            n='runs/'+str(p.relative_to(e));file(n,p);times[n]=p.stat().st_mtime_ns
for p in sorted(e.iterdir()):
    if p.is_file()and(p.suffix in ('.log','.json')or p.name in ('package-failure-evidence.py','validate-final.py'))and p.name not in ('archive-receipt.json','final-validation.json','writer-completed.json'):
        file('logs/'+p.name,p)
file('verify.py',e/'verify-failure-evidence.py')
file('docs/D04_APP_RECORD_AI_SESSION.md',r/'docs/D04_APP_RECORD_AI_SESSION.md')
add('file-times.json',(json.dumps(times,indent=2)+'\n').encode())
add('README.md',b'''# BLOCKED: existing detail authorization view/withdrawal, host test gate FAIL

This is FAILURE evidence for parent review. No green acceptance closure is claimed.
Product source is wired only into the existing processing dialog. No new config page,
grant-confirm call, secretRef, credential, sender, permission, dependency or schema.
Normal installs still lack a production connection/consent-creation route. Existing local
choices remain; this closes the old misleading remote-policy instruction for valid
metadata already present. No production model availability or native acceptance is claimed.

Final targeted24PASS =9 new actual ViewModel/product SQL methods +4 existing local
processing VM +11 admitted backend SQL. New9 passed in BOTH complete runs. Actual same
encrypted-owner contracts are represented with existing canonicalv8 host SQLite, not Room.
Cases include unconfigured/default/no sending, explicit cancel/withdrawal, real COMMIT
then lostACK/exact request replay, later authority historical receipt, source revisionABA,
configABA, deletion/fence, repository owner replacement and page close/disposal. UI states
freeze rendered source/version/hash/generation/owner; unknown immutable requests survive
their own epoch refresh. No production confirm factory or sender is called.

Two initial targeted runs failed and are preserved with source/XML/log: initial24/2FAIL
from wrong healthy retry route and an unreliable StateFlow counter wait; corrected24/1FAIL
then reached a test query after actual storage closure. Existing metadata refresh now
publishes the current owner; delayed-read completion uses actual IO-queue draft ACK; final
zero-job check reopens the durable DB independently. No timeout/assertion relaxation.
Third targeted24PASS. A new API has no claimed baseline business-red proof.

BOTH FULL RUNS FAIL:1039 unique methods each,178AI/71domain/790remote. Each fails exactly
MetadataSourceGenerationViewModelTest.committedDateWithLostAckCanBeConfirmedAfterCloseTrashRestoreReopenWithoutAnotherWrite
atline105: search epoch expected10,actual11. Prior date version check passed. CauseUNKNOWN:
do not infer SDK/code/quota/environment. Exact isolated method on unchanged inputs passes1.
It does not explain or erase the full failures. No further full loop, no changed/skipped
test, date/index logic, timeout or gate. The original product verifier still rejects the
failed suite; see logs/test-gate-failed.log. This work is blocked from independent admission
and cannot be described as a passing full regression or finishedD04.

This artifact's verify.py checks hash/source/method inventories and the reported failures;
its integrityPASS is NOT product acceptance. It requires the two failures to remain.
python3 verify.py <archive> --repo-root <checkout>
All source inputs and raw failed/targeted/isolated XML, timestamps, logs and ownership/
reachability limits are inspectable. A separate final receipt binds them to actual Git
blobs and remote head; normal dev push is for review only, not release/main/deploy.

Core/domain/model/data backend, schema/migrations/fixtures/key provider, manifest,
dependencies/workflows/gates/MainActivity and prior evidence stay unchanged. Real Room11
then12 export/fixture pairs and approved SDK remain prerequisites for a formal sameRoom
no-key draft catalog12to13; no alternative store or dummy refs. The Compose reader/dialog
sources are bound but NOT compiled/rendered by host shells. Android/Room/SQLCipher/Compose/
Preview/device NOTRUN; noAPK. No SDK diagnosis/acceptance/download, Actions/log/API or
alternative route. Prior CI failure causesUNKNOWN; newCI UNKNOWN. Parent review pending.
''')
m={'format':'AIyou.failure-evidence.v1','test_gate':'FAIL','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':'aa61658306dd0a7df251f1fe0501ae7bdef256d9','source_sha256':digest,'source_inputs':sorted(paths),'full_method_inventory':sorted(methods),'failed_method':failed[0],'files':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for n,b in sorted(items.items())}}
add('manifest.json',(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode())
out=r/'docs/evidence/d04-record-authorization-view-withdraw-host-failed.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for n,b in sorted(items.items()):z.writestr(n,b)
print(json.dumps({'archive':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_sha256':digest,'source_inputs':len(paths),'zip_members':len(items),'test_gate':'FAIL','targeted':24,'new_vm_sql':9,'full_runs':2,'methods_per_run':1039,'failures_per_run':1},indent=2))
