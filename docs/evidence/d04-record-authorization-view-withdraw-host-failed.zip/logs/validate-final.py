from pathlib import Path
import hashlib,json,subprocess,zipfile,sys
r=Path('/workspace/AIyou');e=Path('/workspace/scratch/aiyou-record-authorization-ui-20261017')
base='aa61658306dd0a7df251f1fe0501ae7bdef256d9';branch='codex/d04-record-authorization-view-withdraw-20261017'
def git(*args):return subprocess.check_output(['git',*args],cwd=r)
phase=sys.argv[1];assert phase in ('staged','committed')
head=git('rev-parse','HEAD').decode().strip();assert git('branch','--show-current').decode().strip()==branch
archive='docs/evidence/d04-record-authorization-view-withdraw-host-failed.zip';receipt=json.loads((e/'archive-receipt.json').read_text())
assert hashlib.sha256((r/archive).read_bytes()).hexdigest()==receipt['sha256']
count=0
with zipfile.ZipFile(r/archive)as z:
    for n in z.namelist():
        if n.startswith('failure/source-inputs/'):
            p=n[len('failure/source-inputs/'):];data=z.read(n);assert data==(r/p).read_bytes(),p
            assert data==git('show',(':'if phase=='staged'else'HEAD:')+p),p;count+=1
for p in [archive,'docs/D04_APP_RECORD_AI_SESSION.md']:
    assert git('show',(':'if phase=='staged'else'HEAD:')+p)==(r/p).read_bytes(),p
pre=json.loads((e/'preflight.json').read_text())
for p,d in pre['originals'].items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==d,p
allowed={'app/src/main/java/com/t1doo/aiyou/records/'+p for p in ['LocalProcessingController.kt','LocalProcessingDialog.kt','LocalRecordsViewModel.kt','OriginalReadingScreen.kt']}
allowed.update(['checks/ai-protocol/remote-text/src/test/kotlin/com/t1doo/aiyou/records/RecordAuthorizationViewModelTest.kt','docs/D04_APP_RECORD_AI_SESSION.md',archive])
changed=set(git('diff','--name-only',base).decode().splitlines());assert changed==allowed,(changed,allowed)
for p in ['core','schemas','scripts','.github','gradle','app/src/main/AndroidManifest.xml','app/src/main/java/com/t1doo/aiyou/MainActivity.kt','app/src/test','app/build.gradle.kts','checks/ai-protocol/remote-text/build.gradle.kts','docs/D03_MIXED_CAPTURE.md']:
    subprocess.run(['git','diff','--exit-code',base,'--',p],cwd=r,check=True,stdout=subprocess.DEVNULL)
for p in git('ls-tree','-r','--name-only',base,'docs/evidence').decode().splitlines():
    if p.endswith('.zip'):assert git('show',base+':'+p)==(r/p).read_bytes(),p
for a in [base,'01584dd7df71d9ffa3754ffa2555fe4580c6abc0','7383e502418f5f9fc0c540ef2072742359343d40']:
    subprocess.run(['git','merge-base','--is-ancestor',a,'HEAD'],cwd=r,check=True)
lock=r/'.git/codex-index-refresh.lock';assert lock.stat().st_size==0 and lock.stat().st_mtime_ns==1792195365150796372
result={'phase':phase,'head':head,'branch':branch,'source_inputs_bound_to_git_blobs':count,'source_sha256':receipt['source_sha256'],'archive_sha256':receipt['sha256'],'protected_roots_originals_prior_archives_unknown_lock':'UNCHANGED','test_gate':'FAIL; two full runs1039/1FAIL, targeted24PASS; artifact/Git verification is not test acceptance','native':'NOT RUN; Compose UI sources bound but not host-compiled/rendered; no APK','normal_user_data_limit':pre['normal_user_data_limit']}
if phase=='committed':
    refs=git('ls-remote','--heads','origin','main',branch,'codex/d04-record-authorization-port-20261017','codex/f01-discard-retry-queue-message-20261017').decode().splitlines()
    for sha,name in [(head,branch),(base,'codex/d04-record-authorization-port-20261017'),('8a295f9ff46d00f7ecaaf003f47d49b34211ace9','codex/f01-discard-retry-queue-message-20261017'),('7383e502418f5f9fc0c540ef2072742359343d40','main')]:assert sha+'\trefs/heads/'+name in refs
    assert git('status','--porcelain')==b''
    assert git('rev-list','--left-right','--count','origin/'+branch+'...HEAD').decode().strip()=='0\t0'
    assert git('rev-list','--left-right','--count',base+'...HEAD').decode().strip()=='0\t1'
    result.update(remote_refs=refs,remote_diff='0/0',base_diff='0/1',main_diff=git('rev-list','--left-right','--count','origin/main...HEAD').decode().strip(),uncommitted=0,unpushed=0,CI='UNKNOWN; no Actions or alternative access')
(e/('precommit-validation.json'if phase=='staged'else'final-validation.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
