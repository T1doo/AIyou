import com.t1doo.aiyou.data.*;
import com.t1doo.aiyou.model.*;
import java.util.*;

/** Read-only source audit: executes existing compiled ports against an owned synthetic temporary DB only. */
public final class MetadataAbaProbe {
  public static void main(String[] args) throws Exception {
    try (ManualPeopleFixture fixture = new ManualPeopleFixture(true)) {
      RecordEventDateFixture base = fixture.getBase();
      String id = UUID.randomUUID().toString();
      String text = "合成只读审查原文";
      base.entry(id, text);
      String hash = OriginalExports.INSTANCE.hash(text);
      RecordFavoriteMutation favorite = new RecordFavoriteMutation(id, 1, hash, 0L, true, UUID.randomUUID().toString());
      RecordEventDate date = new RecordEventDate("2024-02-29", "UTC");
      RecordEventDateMutation event = new RecordEventDateMutation(id, 1, hash, 0L, date, UUID.randomUUID().toString());
      ManualPeopleMutation people = new ManualPeopleMutation(fixture.getPeople().read(id), List.of("不应写入的旧资格"), UUID.randomUUID().toString());
      SqlRecycleBinRepository bin = new SqlRecycleBinRepository(base.getGateway(), base.getTags(), (sql, key) -> false);
      RecycleRecord before = bin.read(id);
      SourceVersion source = new SourceVersion(id, 1L);
      RecycleRecord trashed = bin.apply(new RecycleMutation(source, before.getGeneration(), false, UUID.randomUUID().toString()));
      RecycleRecord restored = bin.apply(new RecycleMutation(source, trashed.getGeneration(), true, UUID.randomUUID().toString()));
      if (restored.getGeneration() <= before.getGeneration() || restored.getEntry().getCurrentRevision() != 1 ||
          !OriginalExports.INSTANCE.hash(restored.getEntry().getOriginalText()).equals(hash)) throw new AssertionError("Probe did not establish same-version/hash ABA");
      boolean favoriteAccepted = base.getFavorites().set(favorite).isFavorite();
      boolean dateAccepted = date.equals(base.getDates().set(event).getDate());
      boolean peopleRejected = false;
      try { fixture.getPeople().replace(people); }
      catch (com.t1doo.aiyou.domain.ManualPeopleConflict expected) { peopleRejected = true; }
      fixture.reopen();
      boolean favoritePersisted = fixture.getBase().getFavorites().read(id).isFavorite();
      boolean datePersisted = date.equals(fixture.getBase().getDates().read(id).getDate());
      if (!favoriteAccepted || !dateAccepted || !peopleRejected || !favoritePersisted || !datePersisted) throw new AssertionError("Unexpected probe outcome");
      System.out.println("{\"scope\":\"synthetic temporary DB, product SQL ports only, not Android\",\"revision_unchanged\":1,\"hash_unchanged\":true," +
        "\"generation_before\":" + before.getGeneration() + ",\"generation_after\":" + restored.getGeneration() +
        ",\"old_favorite_intent_accepted_and_persisted\":" + favoritePersisted + ",\"old_event_date_intent_accepted_and_persisted\":" + datePersisted +
        ",\"old_people_intent_rejected\":" + peopleRejected + "}");
    }
  }
}
