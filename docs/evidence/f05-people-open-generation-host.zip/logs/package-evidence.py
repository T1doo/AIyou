from pathlib import Path
import ast,hashlib,json,zipfile,datetime,subprocess
root=Path('/workspace/AIyou');evidence=Path('/workspace/scratch/aiyou-people-open-generation-20261017');items={}
def add(name,data):
 assert name not in items,name
 items[name]=data
def file(name,path):add(name,Path(path).read_bytes())
def document(name,value):add(name,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
paths=[]
class Recorder:
 def __init__(self):self.h=hashlib.sha256();self.n=0
 def update(self,data):
  if self.n%2==0:assert data.endswith(b'\0');paths.append(data[:-1].decode())
  self.n+=1;self.h.update(data)
 def hexdigest(self):return self.h.hexdigest()
class RecordingHashlib:
 @staticmethod
 def sha256(data=None):return Recorder() if data is None else hashlib.sha256(data)
tree=ast.parse((root/'scripts/verify-ai-protocol-results.py').read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='input_fingerprint')
ns={'root':root,'hashlib':RecordingHashlib};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<production fingerprint>','exec'),ns)
digest=ns['input_fingerprint']();report=json.loads((evidence/'verified-contracts.json').read_text())
assert report['source_sha256']==digest and sum(m['tests']for m in report['results'])==997
for name in paths:file('closure/source-inputs/'+name,root/name)
file('closure/verified-report.json',evidence/'verified-contracts.json');document('closure/methods.json',{r['module']:r['methods']for r in report['results']})
times={}
for module in report['results']:
 label=module['module'].split(':')[-1];folder=evidence/'raw-xml'/label;path=folder/'inputs-at-test.json';key=f'closure/captures/{label}.json';file(key,path);times[key]=path.stat().st_mtime_ns
 for xml in module['xml']:
  path=folder/Path(xml['path']).name;assert hashlib.sha256(path.read_bytes()).hexdigest()==xml['sha256'];key=f'closure/xml/{label}/{path.name}';file(key,path);times[key]=path.stat().st_mtime_ns
document('closure/file-times.json',times)
base='44512d6bf9e628677cfa6e9370183429e4dfa03a';old=root/'docs/evidence/f05-people-source-fence-host.zip'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='26c19923b8e0c2c7570b3148ae432f74f534f9061d556d168a54b1085057a41a'
with zipfile.ZipFile(old)as z:
 for name in z.namelist():
  if name.startswith('historical-queue/')or name.startswith('historical-python/'):add(name,z.read(name))
 previous=json.loads(z.read('closure/verified-report.json'));before={tuple(c)for r in previous['results']for c in r['methods']};after={tuple(c)for r in report['results']for c in r['methods']}
 assert len(before)==991 and before<=after and len(after-before)==6
 document('method-delta.json',{'base':base,'previous':991,'current':997,'added':sorted(after-before),'removed':[]})
add('reproducer/baseline-controller.kt',subprocess.check_output(['git','show',base+':app/src/main/java/com/t1doo/aiyou/records/ManualPeopleController.kt'],cwd=root))
for path in sorted(evidence.iterdir()):
 if path.is_file()and(path.suffix in('.log','.xml')or path.name in('before-fix-inputs.json','after-fix-inputs.json','fingerprint-verification.json','review-receipt.json','full-01-observation.json','ai-boundary-isolated-inputs.json','package-evidence.py','readonly-probe-classpath.json')):file('logs/'+path.name,path)
with zipfile.ZipFile(old)as z:
 for name in z.namelist():
  if name.startswith('logs/reproducer-before-fix')or name.startswith('logs/viewmodel-after-fix')or name in('logs/full-01-jvm.log','logs/full-01-GuardedSendContractTest.xml','logs/ai-boundary-isolated.log','logs/ai-boundary-isolated.xml','logs/full-01-observation.json','logs/full-02-jvm.log','logs/ai-boundary-isolated-inputs.json'):
   add('previous-source-fence/'+name,z.read(name))
for name in('before-fix-tests.kt','before-fix-controller.kt'):
 file('reproducer/'+name,evidence/name)
file('readonly-probe/MetadataAbaProbe.java',evidence/'MetadataAbaProbe.java')
file('verify.py',root/'scripts/verify-image-grid-evidence.py')
add('README.md',b'''# Bind people editor authority to the rendered reading source before first IO

Verify with the unchanged repository script:
python3 scripts/verify-image-grid-evidence.py docs/evidence/f05-people-open-generation-host.zip --repo-root .
No extraction, SDK, network or new dependency is needed; verify.py is retained.

The closure contains actual 997 unique JVM methods, baseline991 plus6, with zero
failures/errors/skips and every original method retained. Raw XML, exact methods,
input captures, nanosecond times and every captured source byte are included.
Execution HEAD is before committing the tested changes; source fingerprint and
final Git blob comparison bind tested inputs, not HEAD alone. Bound Android source
is not proof of Android compilation. Six new host methods cover five initial-read
boundaries and a retained reading-button source; all16 people ViewModel cases pass.

Five before-fix cases fail on baseline445. A delayed first read or retry after a
first-read failure could adopt a restored generation, or late initial data could
publish after a generation change. No input/save was possible before first read;
the invalid write was an explicit subsequent action in an old source session.
The new reading button carries source version/hash/generation and owner identity
from the existing source ledger. Missing people metadata never implies generation0.
The editor preserves that authority even if its first read fails. Source checks
run before and after metadata reads; UI source changes revoke old controls. Stale
rendered buttons are refused; refreshed sources, AI_NONE records, ordinary adds,
removes, same-source metadata reload and uncertain-ACK retries remain supported.
These are same-ViewModel new sessions, not process-restart or Android acceptance.

previous-source-fence/ retains the earlier three red/green evidence and the original
AI readiness failure records byte-for-byte. That failure was line652's 1-second
server request-arrival assertion before revocation. An unchanged isolated run and
one bounded single-worker full rerun passed; root cause remains UNKNOWN. This new
slice changes no AI source or assertions and does not claim to resolve that cause.
Historical queue149/Python151 are retained only for the existing evidence verifier;
neither suite was rerun or added to this closure. No live model or SDK use.

No schema, dependency, permission, migration or workflow change. Real Room11/12,
Android/SQLCipher/Compose/Preview/device checks remain NOT RUN, no new APK. No SDK
terms acceptance/download, no Actions access or deployment; CI UNKNOWN. The new
Compose source fixture was adjusted to provide explicit source versions, unrun.
The read-only Java probe used existing compiled SQL ports on an owned synthetic
temporary DB: revision/hash unchanged, generation1->3, old favorite/event-date
intents accepted and persisted, old people intent rejected. No full UI-chain
claim or source fix for these other functions. Probe is not a JUnit count.
Independent parent review is pending.
''')
manifest={'format':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cohorts':[{'id':'closure','source_prefix':'closure/source-inputs/','source_sha256':digest,'tests':997,'execution_git_head':report['head'],'source_git_base':base}],'python_rerun':False,'queue_rerun':False,'files':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for name,data in sorted(items.items())}}
document('manifest.json',manifest);output=root/'docs/evidence/f05-people-open-generation-host.zip'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,data in sorted(items.items()):z.writestr(name,data)
print(json.dumps({'archive':str(output),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'source_sha256':digest,'source_inputs':len(paths),'zip_members':len(items),'methods':997,'added':6,'python_rerun':False,'queue_rerun':False},indent=2))
