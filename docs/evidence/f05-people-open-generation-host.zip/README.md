# Bind people editor authority to the rendered reading source before first IO

Verify with the unchanged repository script:
python3 scripts/verify-image-grid-evidence.py docs/evidence/f05-people-open-generation-host.zip --repo-root .
No extraction, SDK, network or new dependency is needed; verify.py is retained.

The closure contains actual 997 unique JVM methods, baseline991 plus6, with zero
failures/errors/skips and every original method retained. Raw XML, exact methods,
input captures, nanosecond times and every captured source byte are included.
Execution HEAD is before committing the tested changes; source fingerprint and
final Git blob comparison bind tested inputs, not HEAD alone. Bound Android source
is not proof of Android compilation. Six new host methods cover five initial-read
boundaries and a retained reading-button source; all16 people ViewModel cases pass.

Five before-fix cases fail on baseline445. A delayed first read or retry after a
first-read failure could adopt a restored generation, or late initial data could
publish after a generation change. No input/save was possible before first read;
the invalid write was an explicit subsequent action in an old source session.
The new reading button carries source version/hash/generation and owner identity
from the existing source ledger. Missing people metadata never implies generation0.
The editor preserves that authority even if its first read fails. Source checks
run before and after metadata reads; UI source changes revoke old controls. Stale
rendered buttons are refused; refreshed sources, AI_NONE records, ordinary adds,
removes, same-source metadata reload and uncertain-ACK retries remain supported.
These are same-ViewModel new sessions, not process-restart or Android acceptance.

previous-source-fence/ retains the earlier three red/green evidence and the original
AI readiness failure records byte-for-byte. That failure was line652's 1-second
server request-arrival assertion before revocation. An unchanged isolated run and
one bounded single-worker full rerun passed; root cause remains UNKNOWN. This new
slice changes no AI source or assertions and does not claim to resolve that cause.
Historical queue149/Python151 are retained only for the existing evidence verifier;
neither suite was rerun or added to this closure. No live model or SDK use.

No schema, dependency, permission, migration or workflow change. Real Room11/12,
Android/SQLCipher/Compose/Preview/device checks remain NOT RUN, no new APK. No SDK
terms acceptance/download, no Actions access or deployment; CI UNKNOWN. The new
Compose source fixture was adjusted to provide explicit source versions, unrun.
The read-only Java probe used existing compiled SQL ports on an owned synthetic
temporary DB: revision/hash unchanged, generation1->3, old favorite/event-date
intents accepted and persisted, old people intent rejected. No full UI-chain
claim or source fix for these other functions. Probe is not a JUnit count.
Independent parent review is pending.
