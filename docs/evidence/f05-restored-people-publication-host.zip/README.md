# Restored people metadata reaches direct reading in the restore-success publication

Verify with the unchanged repository script:
python3 scripts/verify-image-grid-evidence.py docs/evidence/f05-restored-people-publication-host.zip --repo-root .
Actual closure1009 unique JVM methods = baseline1006 plus3, no failures/errors/skips.
Every method, XML, input capture, nanosecond timestamp and source byte is bound.
Final Git blob checks bind tested bytes although execution HEAD is before commit.
Two existing uncompiled Compose fixtures are retained separately, not new coverage.

Baseline771: actual new class3 methods,2 failures and1 positive. Restored names were
already correctly committed/encrypted, but restore DONE published new entries with
the old available people map, so direct reading said no association. A controlled
people snapshot read failure also looked available instead of unavailable. No DB
loss, missing ciphertext or permanent search omission is claimed. Names and stable
restore receipt are verified in real product SQL.

Main opens packages after clearing person/query filters. Closing/back returns to
BROWSE. Its entry click only changes navigation, then passes the same VM state to
OriginalReadingScreen. New host tests authenticate/confirm the actual package on
the actual VM actor, close it, and assert the direct-reader input state. The real
empty BROWSE controller has zero invalidation callbacks; there is no hidden search
refresh or editor-opening repair. This is not Compose or device execution.

The four-line production fix reads the borrowed people's snapshots and publishes
them with the successful entries/tags/favorites/dates state. Snapshot failure is
optional metadata failure: unreadable/error/empty map, while committed restore DONE
and its durable receipt remain successful. An explicit same-package replay repairs
the read without duplicate IDs, metadata rewriting or reauthorizing old intents.

The third host method holds an actual import after commit, closes the package,
queues an old source reader, and performs real independent policy ABA1->3. Late
metadata publication cannot change the old editor's immutable source generation or
load its snapshot. Old callback cannot write; an explicit new session3 can add to
only the intended original. This positive already passed on baseline and remains
passing. Targeted33 actual methods pass; all prior1006 methods are retained.

No schema, model/domain API, SQL mutation/receipt, generation fence, migration,
permission, dependency, workflow, verifier or AI-source change. Original plans and
all previous archives remain unchanged. Historical queue149/Python151 are retained
only for the portable verifier; neither suite was rerun in this slice.

CI correction: parent confirmed original GitHub notification emails for246,cd5 and
771 all reported Android CI FAIL. No detailed errors were provided: cause UNKNOWN,
not attributed to SDK. No Actions access/alternate route. New commit CI UNKNOWN.
Local SDK terms remain unapproved, with no acceptance/download/configuration.
Real Room11/12, Android/SQLCipher/Compose/Preview/device checks remain NOT RUN;
no new APK. Old AI preparation assertion line652 before revocation655 still has
UNKNOWN root cause, original logs preserved, no AI assertions/deadlines changed.
Parent independent review for this slice is pending.
