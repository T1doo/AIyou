from pathlib import Path
import ast,hashlib,json,zipfile,datetime,subprocess
root=Path('/workspace/AIyou');evidence=Path('/workspace/scratch/aiyou-restored-people-publication-20261017');items={}
def add(name,data):
 assert name not in items,name
 items[name]=data
def file(name,path):add(name,Path(path).read_bytes())
def document(name,value):add(name,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
paths=[]
class Recorder:
 def __init__(self):self.h=hashlib.sha256();self.n=0
 def update(self,data):
  if self.n%2==0:assert data.endswith(b'\0');paths.append(data[:-1].decode())
  self.n+=1;self.h.update(data)
 def hexdigest(self):return self.h.hexdigest()
class RecordingHashlib:
 @staticmethod
 def sha256(data=None):return Recorder() if data is None else hashlib.sha256(data)
tree=ast.parse((root/'scripts/verify-ai-protocol-results.py').read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='input_fingerprint')
ns={'root':root,'hashlib':RecordingHashlib};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<production fingerprint>','exec'),ns)
digest=ns['input_fingerprint']();report=json.loads((evidence/'verified-contracts.json').read_text())
assert report['source_sha256']==digest and sum(m['tests']for m in report['results'])==1009
for name in paths:file('closure/source-inputs/'+name,root/name)
file('closure/verified-report.json',evidence/'verified-contracts.json');document('closure/methods.json',{r['module']:r['methods']for r in report['results']})
times={}
for module in report['results']:
 label=module['module'].split(':')[-1];folder=evidence/'raw-xml'/label;path=folder/'inputs-at-test.json';key=f'closure/captures/{label}.json';file(key,path);times[key]=path.stat().st_mtime_ns
 for xml in module['xml']:
  path=folder/Path(xml['path']).name;assert hashlib.sha256(path.read_bytes()).hexdigest()==xml['sha256'];key=f'closure/xml/{label}/{path.name}';file(key,path);times[key]=path.stat().st_mtime_ns
document('closure/file-times.json',times)
base='771eb998a80906fa605769501378848eb7f038a3';old=root/'docs/evidence/f05-metadata-visible-reread-host.zip'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='8bf71b0eae54df834331ab69aa17ac91daaa3b98ba3e3aae8ebceb5853bb9a58'
with zipfile.ZipFile(old)as z:
 for name in z.namelist():
  if name.startswith('historical-queue/')or name.startswith('historical-python/'):add(name,z.read(name))
 previous=json.loads(z.read('closure/verified-report.json'));before={tuple(c)for r in previous['results']for c in r['methods']};after={tuple(c)for r in report['results']for c in r['methods']}
 assert len(before)==1006 and before<=after and len(after-before)==3
 document('method-delta.json',{'base':base,'previous':1006,'current':1009,'added':sorted(after-before),'removed':[]})
for name in('RecordPackageController.kt',):
 add('reproducer/baseline-'+name,subprocess.check_output(['git','show',base+':app/src/main/java/com/t1doo/aiyou/records/'+name],cwd=root))
for path in sorted(evidence.iterdir()):
 if path.is_file()and(path.suffix in('.log','.xml')or path.name.endswith('-inputs.json')or path.name in('before-fix-inputs.json','after-fix-inputs.json','fingerprint-verification.json','review-receipt.json','full-01-observation.json','ai-boundary-isolated-inputs.json','package-evidence.py','targeted-summary.json','read-only-preflight-and-ci-notifications.json','write-authorization-preflight.json')):file('logs/'+path.name,path)
with zipfile.ZipFile(old)as z:
 for name in z.namelist():
  if name.startswith('previous-people/'):
   add('previous-people/'+name,z.read(name))
for path in sorted((evidence/'after-fix-02-xml').glob('*.xml')):file('intermediate/after-fix-02/'+path.name,path)
for path in sorted((evidence/'targeted-xml').glob('*.xml')):file('targeted/'+path.name,path)
file('reproducer/before-fix-tests.kt',evidence/'before-fix-tests.kt')
for name in('RecordFavoritePresentationTest.kt','RecordEventDatePresentationTest.kt'):
 file('uncompiled-ui-source/'+name,root/'app/src/test/kotlin/com/t1doo/aiyou'/name)
file('verify.py',root/'scripts/verify-image-grid-evidence.py')
add('README.md',b"# Restored people metadata reaches direct reading in the restore-success publication\n\nVerify with the unchanged repository script:\npython3 scripts/verify-image-grid-evidence.py docs/evidence/f05-restored-people-publication-host.zip --repo-root .\nActual closure1009 unique JVM methods = baseline1006 plus3, no failures/errors/skips.\nEvery method, XML, input capture, nanosecond timestamp and source byte is bound.\nFinal Git blob checks bind tested bytes although execution HEAD is before commit.\nTwo existing uncompiled Compose fixtures are retained separately, not new coverage.\n\nBaseline771: actual new class3 methods,2 failures and1 positive. Restored names were\nalready correctly committed/encrypted, but restore DONE published new entries with\nthe old available people map, so direct reading said no association. A controlled\npeople snapshot read failure also looked available instead of unavailable. No DB\nloss, missing ciphertext or permanent search omission is claimed. Names and stable\nrestore receipt are verified in real product SQL.\n\nMain opens packages after clearing person/query filters. Closing/back returns to\nBROWSE. Its entry click only changes navigation, then passes the same VM state to\nOriginalReadingScreen. New host tests authenticate/confirm the actual package on\nthe actual VM actor, close it, and assert the direct-reader input state. The real\nempty BROWSE controller has zero invalidation callbacks; there is no hidden search\nrefresh or editor-opening repair. This is not Compose or device execution.\n\nThe four-line production fix reads the borrowed people's snapshots and publishes\nthem with the successful entries/tags/favorites/dates state. Snapshot failure is\noptional metadata failure: unreadable/error/empty map, while committed restore DONE\nand its durable receipt remain successful. An explicit same-package replay repairs\nthe read without duplicate IDs, metadata rewriting or reauthorizing old intents.\n\nThe third host method holds an actual import after commit, closes the package,\nqueues an old source reader, and performs real independent policy ABA1->3. Late\nmetadata publication cannot change the old editor's immutable source generation or\nload its snapshot. Old callback cannot write; an explicit new session3 can add to\nonly the intended original. This positive already passed on baseline and remains\npassing. Targeted33 actual methods pass; all prior1006 methods are retained.\n\nNo schema, model/domain API, SQL mutation/receipt, generation fence, migration,\npermission, dependency, workflow, verifier or AI-source change. Original plans and\nall previous archives remain unchanged. Historical queue149/Python151 are retained\nonly for the portable verifier; neither suite was rerun in this slice.\n\nCI correction: parent confirmed original GitHub notification emails for246,cd5 and\n771 all reported Android CI FAIL. No detailed errors were provided: cause UNKNOWN,\nnot attributed to SDK. No Actions access/alternate route. New commit CI UNKNOWN.\nLocal SDK terms remain unapproved, with no acceptance/download/configuration.\nReal Room11/12, Android/SQLCipher/Compose/Preview/device checks remain NOT RUN;\nno new APK. Old AI preparation assertion line652 before revocation655 still has\nUNKNOWN root cause, original logs preserved, no AI assertions/deadlines changed.\nParent independent review for this slice is pending.\n")
manifest={'format':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cohorts':[{'id':'closure','source_prefix':'closure/source-inputs/','source_sha256':digest,'tests':1009,'execution_git_head':report['head'],'source_git_base':base}],'python_rerun':False,'queue_rerun':False,'files':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for name,data in sorted(items.items())}}
document('manifest.json',manifest);output=root/'docs/evidence/f05-restored-people-publication-host.zip'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,data in sorted(items.items()):z.writestr(name,data)
print(json.dumps({'archive':str(output),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'source_sha256':digest,'source_inputs':len(paths),'zip_members':len(items),'methods':1009,'added':3,'python_rerun':False,'queue_rerun':False},indent=2))
