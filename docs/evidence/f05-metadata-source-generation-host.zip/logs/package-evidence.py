from pathlib import Path
import ast,hashlib,json,zipfile,datetime,subprocess
root=Path('/workspace/AIyou');evidence=Path('/workspace/scratch/aiyou-metadata-source-generation-20261017');items={}
def add(name,data):
 assert name not in items,name
 items[name]=data
def file(name,path):add(name,Path(path).read_bytes())
def document(name,value):add(name,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
paths=[]
class Recorder:
 def __init__(self):self.h=hashlib.sha256();self.n=0
 def update(self,data):
  if self.n%2==0:assert data.endswith(b'\0');paths.append(data[:-1].decode())
  self.n+=1;self.h.update(data)
 def hexdigest(self):return self.h.hexdigest()
class RecordingHashlib:
 @staticmethod
 def sha256(data=None):return Recorder() if data is None else hashlib.sha256(data)
tree=ast.parse((root/'scripts/verify-ai-protocol-results.py').read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='input_fingerprint')
ns={'root':root,'hashlib':RecordingHashlib};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<production fingerprint>','exec'),ns)
digest=ns['input_fingerprint']();report=json.loads((evidence/'verified-contracts.json').read_text())
assert report['source_sha256']==digest and sum(m['tests']for m in report['results'])==1004
for name in paths:file('closure/source-inputs/'+name,root/name)
file('closure/verified-report.json',evidence/'verified-contracts.json');document('closure/methods.json',{r['module']:r['methods']for r in report['results']})
times={}
for module in report['results']:
 label=module['module'].split(':')[-1];folder=evidence/'raw-xml'/label;path=folder/'inputs-at-test.json';key=f'closure/captures/{label}.json';file(key,path);times[key]=path.stat().st_mtime_ns
 for xml in module['xml']:
  path=folder/Path(xml['path']).name;assert hashlib.sha256(path.read_bytes()).hexdigest()==xml['sha256'];key=f'closure/xml/{label}/{path.name}';file(key,path);times[key]=path.stat().st_mtime_ns
document('closure/file-times.json',times)
base='246bf214cfeec44226c87ea3e700c45f54d5df8e';old=root/'docs/evidence/f05-people-open-generation-host.zip'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='aee57a445207c8c69d81692d5f1c6dd4290e390165c89f4d9aefa1c34faba536'
with zipfile.ZipFile(old)as z:
 for name in z.namelist():
  if name.startswith('historical-queue/')or name.startswith('historical-python/'):add(name,z.read(name))
 previous=json.loads(z.read('closure/verified-report.json'));before={tuple(c)for r in previous['results']for c in r['methods']};after={tuple(c)for r in report['results']for c in r['methods']}
 assert len(before)==997 and before<=after and len(after-before)==7
 document('method-delta.json',{'base':base,'previous':997,'current':1004,'added':sorted(after-before),'removed':[]})
for name in('RecordFavoriteController.kt','RecordEventDateController.kt'):
 add('reproducer/baseline-'+name,subprocess.check_output(['git','show',base+':app/src/main/java/com/t1doo/aiyou/records/'+name],cwd=root))
for path in sorted(evidence.iterdir()):
 if path.is_file()and(path.suffix in('.log','.xml')or path.name.endswith('-inputs.json')or path.name in('before-fix-inputs.json','after-fix-inputs.json','fingerprint-verification.json','review-receipt.json','full-01-observation.json','ai-boundary-isolated-inputs.json','package-evidence.py','readonly-probe-classpath.json')):file('logs/'+path.name,path)
with zipfile.ZipFile(old)as z:
 for name in z.namelist():
  if name.startswith('previous-source-fence/'):
   add('previous-people/'+name,z.read(name))
for path in sorted((evidence/'after-fix-02-xml').glob('*.xml')):file('intermediate/after-fix-02/'+path.name,path)
for path in sorted((evidence/'targeted-xml').glob('*.xml')):file('targeted/'+path.name,path)
file('reproducer/before-fix-tests.kt',evidence/'before-fix-tests.kt')
for name in('RecordFavoritePresentationTest.kt','RecordEventDatePresentationTest.kt'):
 file('uncompiled-ui-source/'+name,root/'app/src/test/kotlin/com/t1doo/aiyou'/name)
file('verify.py',root/'scripts/verify-image-grid-evidence.py')
add('README.md',b"# Freeze source generation for explicit favorite/date first commits\n\nVerify with the unchanged repository script:\npython3 scripts/verify-image-grid-evidence.py docs/evidence/f05-metadata-source-generation-host.zip --repo-root .\nNo SDK, network or new dependency is needed. Every raw XML, method, capture,\nnanosecond timestamp and captured source byte is retained. Final Git blob checks\nbind tested inputs even though execution HEAD precedes the new commit.\n\nActual JVM closure: 1004 unique methods, baseline997 plus7, no failures/errors/skips.\nThe original four controller/VM/SQL reproducers fail on246: reading-button argument\nflow creates an intent; a held pre-SQL set sees independent trash/restore1->3, or a\npre-commit failure remains pending across the actual VM recycle controller's\ntrash/restore. Explicit retry then first-committed the old intent. Favorite and\ndate each have both cases. Input/save requires loaded metadata; no automatic write\non editor reopening is claimed. Same-VM editor reopening is not process restart.\nThese are actual controllers, actual records serial queue and product SQL, with\nhost lifecycle/storage shells. They do not execute Compose, Android or devices.\n\nThe normal same-owner FIFO alone does not let a queued write jump over UI trash\nand restore. Main navigation invalidates retained old route buttons; closing an\nunattempted date editor prevents its queued write. The actionable counterexample\nis pending unknown-commit retry, or an independent SQL owner changing source while\nIO is held. No claim is based solely on the earlier direct SQL Java probe.\n\nThe rendered source carries version/hash/generation. Missing source-ledger proof\nnever defaults to0. Both mutations require an explicit sourceGeneration with no\noptional bypass. Initial SQL writes compare it inside their metadata CAS\ntransaction. Existing metadata survives restoration. A verified matching committed\nreceipt still only acknowledges its existing result (no write, version or epoch\nincrement), including across generation change. Two actual VM positive controls\nprove lost-ACK acknowledgment after trash/restore. Fresh source actions, ordinary\nadd/clear, same-source retries, close/navigation and later-choice CAS remain tested.\nThe seventh method checks missing-ledger refusal and retained/fresh reading sources.\nSQL's existing COALESCE source-ledger0 contract supports real legacy access-row\nabsence; metadata row absence is never used to infer source authority.\n\nThe first post-change attempt did not compile due to four fixture call-site\nadaptation issues; its log is preserved, not counted as runtime tests. Corrections\nonly supplied the actual source ledger, fixed one unintended RecycleMutation\nargument, and matched the required editor constructor. The next targeted31 run had2 failures: a real newly saved record briefly lacked\nits published source ledger and could not be immediately favorited; the save now\npublishes that ledger before its acknowledgment. One cleanup-only fixture tried\nto fetch live authority for a deleted record; it now uses its originally retained\nintent. Both raw XML and logs are retained. No old assertion or deadline changed. Baseline red source and XML remain exact.\n\nNo schema/migration, dependency version, permission, workflow or AI-source change.\nOne host build source-copy entry includes the new production helper; assertions\nand result verifiers were not relaxed. Existing native test call sites were\nadapted to explicit generation but remain uncompiled/unrun. Additional uncompiled\nCompose fixtures are included separately; they are not host test coverage.\n\nHistorical queue149/Python151 are retained only for the portable verifier; neither\nsuite was rerun. The preceding people archives remain unchanged. Previous AI\nfailure records are retained; its line652 1-second request-arrival assertion failed\nbefore revocation655. Root cause is UNKNOWN; passing unchanged reruns do not explain\nit. No real model call, SDK terms acceptance/download, Actions access, or deployment.\nReal Room11/12, Android/SQLCipher/Compose/Preview/device checks remain NOT RUN;\nno new APK, CI UNKNOWN. Independent parent review is pending.\n")
manifest={'format':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cohorts':[{'id':'closure','source_prefix':'closure/source-inputs/','source_sha256':digest,'tests':1004,'execution_git_head':report['head'],'source_git_base':base}],'python_rerun':False,'queue_rerun':False,'files':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for name,data in sorted(items.items())}}
document('manifest.json',manifest);output=root/'docs/evidence/f05-metadata-source-generation-host.zip'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,data in sorted(items.items()):z.writestr(name,data)
print(json.dumps({'archive':str(output),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'source_sha256':digest,'source_inputs':len(paths),'zip_members':len(items),'methods':1004,'added':7,'python_rerun':False,'queue_rerun':False},indent=2))
