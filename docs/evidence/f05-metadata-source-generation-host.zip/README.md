# Freeze source generation for explicit favorite/date first commits

Verify with the unchanged repository script:
python3 scripts/verify-image-grid-evidence.py docs/evidence/f05-metadata-source-generation-host.zip --repo-root .
No SDK, network or new dependency is needed. Every raw XML, method, capture,
nanosecond timestamp and captured source byte is retained. Final Git blob checks
bind tested inputs even though execution HEAD precedes the new commit.

Actual JVM closure: 1004 unique methods, baseline997 plus7, no failures/errors/skips.
The original four controller/VM/SQL reproducers fail on246: reading-button argument
flow creates an intent; a held pre-SQL set sees independent trash/restore1->3, or a
pre-commit failure remains pending across the actual VM recycle controller's
trash/restore. Explicit retry then first-committed the old intent. Favorite and
date each have both cases. Input/save requires loaded metadata; no automatic write
on editor reopening is claimed. Same-VM editor reopening is not process restart.
These are actual controllers, actual records serial queue and product SQL, with
host lifecycle/storage shells. They do not execute Compose, Android or devices.

The normal same-owner FIFO alone does not let a queued write jump over UI trash
and restore. Main navigation invalidates retained old route buttons; closing an
unattempted date editor prevents its queued write. The actionable counterexample
is pending unknown-commit retry, or an independent SQL owner changing source while
IO is held. No claim is based solely on the earlier direct SQL Java probe.

The rendered source carries version/hash/generation. Missing source-ledger proof
never defaults to0. Both mutations require an explicit sourceGeneration with no
optional bypass. Initial SQL writes compare it inside their metadata CAS
transaction. Existing metadata survives restoration. A verified matching committed
receipt still only acknowledges its existing result (no write, version or epoch
increment), including across generation change. Two actual VM positive controls
prove lost-ACK acknowledgment after trash/restore. Fresh source actions, ordinary
add/clear, same-source retries, close/navigation and later-choice CAS remain tested.
The seventh method checks missing-ledger refusal and retained/fresh reading sources.
SQL's existing COALESCE source-ledger0 contract supports real legacy access-row
absence; metadata row absence is never used to infer source authority.

The first post-change attempt did not compile due to four fixture call-site
adaptation issues; its log is preserved, not counted as runtime tests. Corrections
only supplied the actual source ledger, fixed one unintended RecycleMutation
argument, and matched the required editor constructor. The next targeted31 run had2 failures: a real newly saved record briefly lacked
its published source ledger and could not be immediately favorited; the save now
publishes that ledger before its acknowledgment. One cleanup-only fixture tried
to fetch live authority for a deleted record; it now uses its originally retained
intent. Both raw XML and logs are retained. No old assertion or deadline changed. Baseline red source and XML remain exact.

No schema/migration, dependency version, permission, workflow or AI-source change.
One host build source-copy entry includes the new production helper; assertions
and result verifiers were not relaxed. Existing native test call sites were
adapted to explicit generation but remain uncompiled/unrun. Additional uncompiled
Compose fixtures are included separately; they are not host test coverage.

Historical queue149/Python151 are retained only for the portable verifier; neither
suite was rerun. The preceding people archives remain unchanged. Previous AI
failure records are retained; its line652 1-second request-arrival assertion failed
before revocation655. Root cause is UNKNOWN; passing unchanged reruns do not explain
it. No real model call, SDK terms acceptance/download, Actions access, or deployment.
Real Room11/12, Android/SQLCipher/Compose/Preview/device checks remain NOT RUN;
no new APK, CI UNKNOWN. Independent parent review is pending.
