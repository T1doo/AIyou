D05 accepted-browser host evidence, 2026-10-20.
Host command: python3 scripts/jvm-gradle.py -p checks/ai-protocol :remote-text:test --tests '*SourceMemory*'
27 unique actual methods PASS; 0 failures/errors/skips. XML copied before any later run.
Python tools: 168 tests PASS; tokens PASS.
Source hashes are for the listed files; this is not a device result or a complete build-input proof.
Host tested product HEAD ef70385018e5b9b46dcfab592c2b927ddde23333.
Working-tree Compose scrolling correction was not executed by this host command.
The exact product sources remain equal to independently reviewed 4b18560ba3508a77a3e22013ea31af792d5cb372 per trusted handoff.
No new independent reviewer was run here.
Prior CI metadata is preserved, not original CI logs. Normal log redirects were denied with HTTP403; no retry/bypass.
No APK/artifact download attempted. No SDK agreements accepted or packages installed.
