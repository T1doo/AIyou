package com.t1doo.aiyou.records

import android.app.Application
import com.t1doo.aiyou.data.*
import com.t1doo.aiyou.domain.*
import com.t1doo.aiyou.model.*
import java.io.ByteArrayOutputStream
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

/** Source-read-only audit; existing compiled fixture owns every temporary DB/file. Not a JUnit or Android test. */
fun main()=runBlocking {
    val type=Class.forName("com.t1doo.aiyou.data.ManualPeoplePortabilityTest\$PeopleMediaFixture")
    val fixture=type.getDeclaredConstructor(Boolean::class.javaPrimitiveType).apply{isAccessible=true}.newInstance(true)
    fun field(name:String):Any=type.getDeclaredMethod(name).apply{isAccessible=true}.invoke(fixture)
    val base=field("getBase") as PermanentErasureFixture
    val people=field("getPeople") as SqlManualPeopleRepository
    val media=field("getMedia") as SqlRecordMediaPackageRepository
    val packages=field("getPackages") as SqlRecordPackageRepository
    val originals=field("getOriginals") as SqlOriginalExportRepository
    val id=field("seed") as String
    val name="合成人物恢复核对"
    people.replace(ManualPeopleMutation(people.read(id),listOf(name),UUID.randomUUID().toString()))
    val snapshot=originals.capture(listOf(SourceVersion(id,1)),UUID.randomUUID().toString(),50)
    val prepared=media.seal(media.preview(snapshot),"synthetic readonly restore probe".toCharArray())
    val bytes=try{ByteArrayOutputStream().use{out->prepared.writeTo(out){true};out.toByteArray()}}finally{prepared.release()}
    val original=SqliteVmEntryRepository(base.db,base.gateway,RemoteTextTransactions(base.gateway)){}
    val search=SqlLocalSearchRepository(base.gateway,base.tags,people=people)
    val store=object:EntryRepository by original,AutoCloseable {
        override val manualPeople=people
        override val manualTags=base.tags
        override val favorites=SqlRecordFavoriteRepository(base.gateway)
        override val eventDates=SqlRecordEventDateRepository(base.gateway)
        override val recordPackages=packages
        override val mediaPackages=media
        override val localProcessing=SqlLocalProcessingRepository(base.gateway)
        override val localSearch=search
        override suspend fun prepare(){check(base.db.read("PRAGMA user_version").single().single()==12L)}
        override fun close()=original.close()
    }
    val vm=LocalRecordsViewModel(Application(),{store})
    var controller:LocalOriginalSearchController?=null
    try {
        withTimeout(10_000){vm.state.first{it.ready&&!it.opening}}
        check(vm.state.value.manualPeople[id]?.names==listOf(name))
        val c=vm.recordPackages;c.open();var ui=checkNotNull(vm.state.value.recordPackage)
        c.chooseRestore(ui.session);ui=checkNotNull(vm.state.value.recordPackage)
        val key=checkNotNull(ui.requestKey);check(c.claimPicker(ui.session,key))
        c.picked(ui.session,key,RecordPackageControllerTest.Document(bytes));c.authenticate(ui.session,"synthetic readonly restore probe".toCharArray())
        ui=checkNotNull(withTimeout(10_000){vm.state.first{it.recordPackage?.phase==RecordPackagePhase.RESTORE_PREVIEW}}.recordPackage)
        val verified=checkNotNull(ui.verified);c.confirmRestore(ui.session,verified.manifest.backupId,verified.digest,ui.epoch)
        ui=checkNotNull(withTimeout(10_000){vm.state.first{it.recordPackage?.phase==RecordPackagePhase.DONE}}.recordPackage)
        val restored=vm.state.value.entries.single{it.id!=id}.id
        val persisted=people.read(restored).names
        val displayed=vm.state.value.manualPeople[restored]?.names.orEmpty()
        check(persisted==listOf(name));check(displayed.isEmpty());check(vm.state.value.manualPeopleAvailable)
        c.close(ui.session)
        val lookup=LocalOriginalSearchController({vm.state.value},{OriginalSearchInput(person=name,peopleSnapshot=vm.state.value.manualPeople)},Dispatchers.IO,
            matcher={entries,input->LocalOriginalSearchMatcher.indexed(entries,input,search)},onInvalidated={vm.refreshLocalSearch()})
        controller=lookup
        lookup.sync(true)
        withTimeout(10_000){vm.state.first{it.manualPeople[restored]?.names==persisted}}
        lookup.sync(true)
        val found=withTimeout(10_000){lookup.state.first{it.stage==OriginalSearchStage.READY}}
        check(found.hits.any{it.entry.id==restored})
        println("{\"scope\":\"actual VM package restore and indexed-search callback on owned synthetic DB; not Compose/Android\",\"restored_names_persisted\":true,\"immediate_reading_people_snapshot_missing\":true,\"manual_people_available_was_true\":true,\"indexed_search_auto_refresh_recovered_names\":true,\"restored_record_found_after_actual_refresh_callback\":true,\"database_data_loss\":false}")
    } finally {
        controller?.close();vm.clearForHostTest();check(original.closed.await(5,TimeUnit.SECONDS));bytes.fill(0)
        (fixture as AutoCloseable).close()
    }
}
