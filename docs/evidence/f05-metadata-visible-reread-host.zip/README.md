# Visible metadata reread refreshes the source ledger

Verify with the unchanged script:
python3 scripts/verify-image-grid-evidence.py docs/evidence/f05-metadata-visible-reread-host.zip --repo-root .
Actual closure1006 unique JVM methods = baseline1004 plus2, no failures/errors/skips.
Every method, raw XML, input capture, nanosecond timestamp and source byte is bound.
Final Git blob comparison binds execution inputs although execution HEAD is before
this tested change is committed. Two extra uncompiled Compose fixtures are separate.

Two actual controller/VM/product-SQL reproducers fail oncd5. An independent real
local-policy port performs LOCAL_ONLY1 -> AI_NONE2 -> LOCAL_ONLY3, leaving entry
contents/version/policy/list unchanged. The old held set correctly conflicts, but
the visible favorite/date reread only refreshed metadata, leaving source-ledger1.
A new user choice/preview+confirmation still failed. No private refreshLocalSearch
or h.refresh() is used in these two new methods. The date close/reopen variant also
failed before the fix; its exact source, XML and capture are preserved separately.
Two unique red methods; the date variant is not a third unique method.

Favorite reread and date load now read the actual borrowed source ledger and
publish it with metadata. Favorite reread removes conflicted old intents and
permits a new explicit choice on the refreshed source. Date keeps its immutable
old editor source, shows a conflict, and asks the user to close and reopen. The
actual visible close/open actions create a new editor with the fresh rendered
source, followed by new input/preview/confirmation. Old input or pending mutations
are never silently rebound. Read failures remain unavailable. Existing pending
uncertain intents keep their original generation; SQL first-commit fencing and
read-only acknowledgment of matching committed receipts are unchanged.
Targeted33 methods, including all9 generation VM methods, pass. Baseline1004 remain.

No schema, migration, model/domain API, SQL port, dependency, permission, workflow,
verification-script or AI-source changes. Android/SQLCipher/Room11/12/Compose/
Preview/device checks remain NOT RUN, no new APK; the adapted Compose source ports
are uncompiled. SDK terms unapproved, no download/acceptance/configuration, no
Actions access, CI UNKNOWN. Old AI preparation failure remains UNKNOWN; raw records
are preserved through prior archives. Historical queue149/Python151 are retained
only for the existing portable verifier; neither suite was rerun.

readonly-audit/ is an optional source-read-only synthetic DB probe of the separate
people-restore display candidate, not a JUnit count or an implemented fix. Its
runtime log and receipt confirm names persisted but immediate reading cache missed
the new names while marked available. Actual indexed search invoked its real
refresh callback and found the restored record. This is a transient reading-label
gap, not DB loss/persistent search omission, and is not fixed here. First probe
fixture omitted the required originalExport capability; its correctly refused open
and source/log are preserved. One bounded corrected run supplied the actual port
and passed. Probe command/classpath are execution records for this selected
environment, not a claim that other environments share its compiled files. Search's WAITING
mismatch invokes Main's refreshLocalSearch callback, so stale snapshot source alone
does not prove persistent omission or data loss. Actual MainActivity uses the
default ViewModel binder with no AI provider; no new ordinary-user late-AI path
was established. Manual tags' explicit cross-revision contract was not reclassified.
Parent independent review is pending for this slice.
