from pathlib import Path
import ast,hashlib,json,zipfile,datetime,subprocess
root=Path('/workspace/AIyou');evidence=Path('/workspace/scratch/aiyou-metadata-visible-reread-20261017');items={}
def add(name,data):
 assert name not in items,name
 items[name]=data
def file(name,path):add(name,Path(path).read_bytes())
def document(name,value):add(name,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
paths=[]
class Recorder:
 def __init__(self):self.h=hashlib.sha256();self.n=0
 def update(self,data):
  if self.n%2==0:assert data.endswith(b'\0');paths.append(data[:-1].decode())
  self.n+=1;self.h.update(data)
 def hexdigest(self):return self.h.hexdigest()
class RecordingHashlib:
 @staticmethod
 def sha256(data=None):return Recorder() if data is None else hashlib.sha256(data)
tree=ast.parse((root/'scripts/verify-ai-protocol-results.py').read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='input_fingerprint')
ns={'root':root,'hashlib':RecordingHashlib};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<production fingerprint>','exec'),ns)
digest=ns['input_fingerprint']();report=json.loads((evidence/'verified-contracts.json').read_text())
assert report['source_sha256']==digest and sum(m['tests']for m in report['results'])==1006
for name in paths:file('closure/source-inputs/'+name,root/name)
file('closure/verified-report.json',evidence/'verified-contracts.json');document('closure/methods.json',{r['module']:r['methods']for r in report['results']})
times={}
for module in report['results']:
 label=module['module'].split(':')[-1];folder=evidence/'raw-xml'/label;path=folder/'inputs-at-test.json';key=f'closure/captures/{label}.json';file(key,path);times[key]=path.stat().st_mtime_ns
 for xml in module['xml']:
  path=folder/Path(xml['path']).name;assert hashlib.sha256(path.read_bytes()).hexdigest()==xml['sha256'];key=f'closure/xml/{label}/{path.name}';file(key,path);times[key]=path.stat().st_mtime_ns
document('closure/file-times.json',times)
base='cd5e53661dedcf93acaf04267432ad65228460c0';old=root/'docs/evidence/f05-metadata-source-generation-host.zip'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='bab7ab0fe482a65f244eb550139265eeb9c2e0e9b145b9a30d882c516517d447'
with zipfile.ZipFile(old)as z:
 for name in z.namelist():
  if name.startswith('historical-queue/')or name.startswith('historical-python/'):add(name,z.read(name))
 previous=json.loads(z.read('closure/verified-report.json'));before={tuple(c)for r in previous['results']for c in r['methods']};after={tuple(c)for r in report['results']for c in r['methods']}
 assert len(before)==1004 and before<=after and len(after-before)==2
 document('method-delta.json',{'base':base,'previous':1004,'current':1006,'added':sorted(after-before),'removed':[]})
for name in('RecordFavoriteController.kt','RecordEventDateController.kt'):
 add('reproducer/baseline-'+name,subprocess.check_output(['git','show',base+':app/src/main/java/com/t1doo/aiyou/records/'+name],cwd=root))
for path in sorted(evidence.iterdir()):
 if path.is_file()and(path.suffix in('.log','.xml')or path.name.endswith('-inputs.json')or path.name in('before-fix-inputs.json','after-fix-inputs.json','fingerprint-verification.json','review-receipt.json','full-01-observation.json','ai-boundary-isolated-inputs.json','package-evidence.py','readonly-audit-candidates.json')):file('logs/'+path.name,path)
with zipfile.ZipFile(old)as z:
 for name in z.namelist():
  if name.startswith('previous-people/'):
   add('previous-people/'+name,z.read(name))
for path in sorted((evidence/'after-fix-02-xml').glob('*.xml')):file('intermediate/after-fix-02/'+path.name,path)
for path in sorted((evidence/'targeted-xml').glob('*.xml')):file('targeted/'+path.name,path)
file('reproducer/before-fix-tests.kt',evidence/'before-fix-tests.kt')
file('reproducer/before-close-reopen-tests.kt',evidence/'before-close-reopen-tests.kt')
file('readonly-audit/ReadonlyPeopleRestoreProbe.kt',evidence/'ReadonlyPeopleRestoreProbe.kt')
for name in('ReadonlyPeopleRestoreProbe-before-capability.kt','run-readonly-probe.py','readonly-probe-classpath.json'):
 file('readonly-audit/'+name,evidence/name)
for name in('RecordFavoritePresentationTest.kt','RecordEventDatePresentationTest.kt'):
 file('uncompiled-ui-source/'+name,root/'app/src/test/kotlin/com/t1doo/aiyou'/name)
file('verify.py',root/'scripts/verify-image-grid-evidence.py')
add('README.md',b"# Visible metadata reread refreshes the source ledger\n\nVerify with the unchanged script:\npython3 scripts/verify-image-grid-evidence.py docs/evidence/f05-metadata-visible-reread-host.zip --repo-root .\nActual closure1006 unique JVM methods = baseline1004 plus2, no failures/errors/skips.\nEvery method, raw XML, input capture, nanosecond timestamp and source byte is bound.\nFinal Git blob comparison binds execution inputs although execution HEAD is before\nthis tested change is committed. Two extra uncompiled Compose fixtures are separate.\n\nTwo actual controller/VM/product-SQL reproducers fail oncd5. An independent real\nlocal-policy port performs LOCAL_ONLY1 -> AI_NONE2 -> LOCAL_ONLY3, leaving entry\ncontents/version/policy/list unchanged. The old held set correctly conflicts, but\nthe visible favorite/date reread only refreshed metadata, leaving source-ledger1.\nA new user choice/preview+confirmation still failed. No private refreshLocalSearch\nor h.refresh() is used in these two new methods. The date close/reopen variant also\nfailed before the fix; its exact source, XML and capture are preserved separately.\nTwo unique red methods; the date variant is not a third unique method.\n\nFavorite reread and date load now read the actual borrowed source ledger and\npublish it with metadata. Favorite reread removes conflicted old intents and\npermits a new explicit choice on the refreshed source. Date keeps its immutable\nold editor source, shows a conflict, and asks the user to close and reopen. The\nactual visible close/open actions create a new editor with the fresh rendered\nsource, followed by new input/preview/confirmation. Old input or pending mutations\nare never silently rebound. Read failures remain unavailable. Existing pending\nuncertain intents keep their original generation; SQL first-commit fencing and\nread-only acknowledgment of matching committed receipts are unchanged.\nTargeted33 methods, including all9 generation VM methods, pass. Baseline1004 remain.\n\nNo schema, migration, model/domain API, SQL port, dependency, permission, workflow,\nverification-script or AI-source changes. Android/SQLCipher/Room11/12/Compose/\nPreview/device checks remain NOT RUN, no new APK; the adapted Compose source ports\nare uncompiled. SDK terms unapproved, no download/acceptance/configuration, no\nActions access, CI UNKNOWN. Old AI preparation failure remains UNKNOWN; raw records\nare preserved through prior archives. Historical queue149/Python151 are retained\nonly for the existing portable verifier; neither suite was rerun.\n\nreadonly-audit/ is an optional source-read-only synthetic DB probe of the separate\npeople-restore display candidate, not a JUnit count or an implemented fix. Its\nruntime log and receipt confirm names persisted but immediate reading cache missed\nthe new names while marked available. Actual indexed search invoked its real\nrefresh callback and found the restored record. This is a transient reading-label\ngap, not DB loss/persistent search omission, and is not fixed here. First probe\nfixture omitted the required originalExport capability; its correctly refused open\nand source/log are preserved. One bounded corrected run supplied the actual port\nand passed. Probe command/classpath are execution records for this selected\nenvironment, not a claim that other environments share its compiled files. Search's WAITING\nmismatch invokes Main's refreshLocalSearch callback, so stale snapshot source alone\ndoes not prove persistent omission or data loss. Actual MainActivity uses the\ndefault ViewModel binder with no AI provider; no new ordinary-user late-AI path\nwas established. Manual tags' explicit cross-revision contract was not reclassified.\nParent independent review is pending for this slice.\n")
manifest={'format':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cohorts':[{'id':'closure','source_prefix':'closure/source-inputs/','source_sha256':digest,'tests':1006,'execution_git_head':report['head'],'source_git_base':base}],'python_rerun':False,'queue_rerun':False,'files':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for name,data in sorted(items.items())}}
document('manifest.json',manifest);output=root/'docs/evidence/f05-metadata-visible-reread-host.zip'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,data in sorted(items.items()):z.writestr(name,data)
print(json.dumps({'archive':str(output),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'source_sha256':digest,'source_inputs':len(paths),'zip_members':len(items),'methods':1006,'added':2,'python_rerun':False,'queue_rerun':False},indent=2))
