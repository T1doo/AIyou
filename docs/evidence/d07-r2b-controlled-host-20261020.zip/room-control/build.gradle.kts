plugins { kotlin("jvm") version "2.4.21"; id("com.google.devtools.ksp") version "2.3.12" }
kotlin { jvmToolchain(17) }
val androidAars by configurations.creating { isTransitive=false }
val extracted=layout.buildDirectory.dir("aar-classes")
val unpack by tasks.registering { inputs.files(androidAars); outputs.dir(extracted); doLast { androidAars.files.forEach { jar -> copy { from(zipTree(jar)); include("classes.jar"); into(extracted.get().dir(jar.nameWithoutExtension)) } } } }
val sourceRoot=providers.gradleProperty("sourceRoot").orElse("baseline/core/data/src/main/kotlin")
kotlin.sourceSets.main { kotlin.srcDir(sourceRoot) }
val androidJars=fileTree(extracted){include("**/*.jar")}
dependencies {
 implementation(project(":core:model")); implementation(project(":core:domain"))
 implementation("org.robolectric:android-all-instrumented:15-robolectric-13954326-i7")
 implementation("org.robolectric:shadowapi:4.17")
 implementation("org.robolectric:sandbox:4.17")
 implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.9.0")
 implementation("androidx.room:room-common-jvm:2.8.5")
 implementation(androidJars)
 androidAars("androidx.room:room-runtime-android:2.8.5@aar")
 androidAars("androidx.sqlite:sqlite-android:2.7.0@aar")
 androidAars("net.zetetic:sqlcipher-android:4.19.1@aar")
 ksp("androidx.room:room-compiler:2.8.5")
}
ksp { arg("room.schemaLocation",project.layout.projectDirectory.dir("export").asFile.path) }
tasks.configureEach { if(name.startsWith("ksp"))dependsOn(unpack) }

subprojects { layout.buildDirectory.set(rootProject.layout.buildDirectory.dir("isolated-"+name)) }
