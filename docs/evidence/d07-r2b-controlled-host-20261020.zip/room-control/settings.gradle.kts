pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositories { google(); mavenCentral() } }
rootProject.name="reminder-real-room-export"
include(":core:model",":core:domain")
project(":core:model").projectDir=file(providers.gradleProperty("productRoot").orElse("baseline").get()+"/core/model")
project(":core:domain").projectDir=file(providers.gradleProperty("productRoot").orElse("baseline").get()+"/core/domain")
dependencyResolutionManagement { versionCatalogs { create("libs") { from(files("../../../gradle/libs.versions.toml")) } } }
