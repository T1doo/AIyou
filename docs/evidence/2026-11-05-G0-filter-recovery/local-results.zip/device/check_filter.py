import sys, time, re, json
from pathlib import Path
from runpy import run_path

root=Path(__file__).resolve().parent
mode=sys.argv[1]
sys.argv=['device.py','library']
api=run_path(str(root/'device.py')); adb=api['adb']; nodes=api['nodes']
def rect(n): return tuple(map(int,re.findall(r'\d+',n.get('bounds'))))
def tap_node(n):
    x,y,r,b=rect(n); assert r>x and b>y
    adb('shell','input','tap',str((x+r)//2),str((y+b)//2))
def find(label):
    for _ in range(8):
        ns=nodes(); found=[n for n in ns if n.get('text')==label or n.get('content-desc')==label]
        if len(found)==1:return found[0]
        time.sleep(.2)
    raise RuntimeError('Missing/ambiguous actual UI target: '+label)
def click(label): tap_node(find(label))
def fields():
    find('筛选回忆')
    return sorted([n for n in nodes() if n.get('class')=='android.widget.EditText'],key=lambda n:rect(n)[1])
def input_date(index,value):
    f=fields(); assert len(f)>=2
    tap_node(f[index]); adb('shell','input','text',value)
    ime=adb('shell','dumpsys','input_method').decode(errors='replace')
    if re.search(r'(mInputShown|mIsInputViewShown|isInputViewShown)=true',ime): adb('shell','input','keyevent','4')
    assert fields()[index].get('text')==value
def capture(name):
    nodes(); (root/(name+'.xml')).write_bytes((root/'window.xml').read_bytes())
    (root/(name+'.png')).write_bytes(adb('exec-out','screencap','-p'))

if mode=='cancel':
    assert fields()[0].get('text')==''
    input_date(0,'2026-11-05'); capture('staged-date')
    click('取消'); find('搜索回忆')
    click('筛选'); assert fields()[0].get('text')==''
    capture('cancel-reopened')
    print('PASS: typed date remained staged; cancel/reopen has no applied date')
elif mode=='apply':
    input_date(0,'2026-11-05'); input_date(1,'2026-11-05')
    click('应用'); find('2026-11-05 至 2026-11-05')
    find('Keyboard_return_sample'); capture('applied-date')
    print('PASS: actual Apply committed the date range to local search')
elif mode=='clear':
    click('筛选'); click('更多查找设置'); click('清空全部查找，包括搜索词')
    find('搜索回忆'); assert not any('2026-11-05 至' in n.get('text','') for n in nodes())
    click('筛选'); f=fields(); assert f[0].get('text')=='' and f[1].get('text')==''
    click('取消'); find('搜索回忆'); capture('cleared-search')
    print('PASS: explicit full clear removed date conditions; records untouched')
else: raise ValueError(mode)
