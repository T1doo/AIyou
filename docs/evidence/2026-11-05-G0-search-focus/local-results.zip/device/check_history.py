import sys, time, re, json
from pathlib import Path
from runpy import run_path

root=Path(__file__).resolve().parent; mode=sys.argv[1]
sys.argv=['device.py','library'];api=run_path(str(root/'device.py'))
adb=api['adb'];nodes=api['nodes']
def rect(n):return tuple(map(int,re.findall(r'\d+',n.get('bounds'))))
def tap(n):
    l,t,r,b=rect(n);assert r>l and b>t
    adb('shell','input','tap',str((l+r)//2),str((t+b)//2))
def find(text,bottom=False):
    for _ in range(8):
        found=[n for n in nodes() if n.get('text')==text or n.get('content-desc')==text]
        if found and bottom:return max(found,key=lambda n:rect(n)[1])
        if len(found)==1:return found[0]
        time.sleep(.2)
    raise RuntimeError('Missing or ambiguous actual UI: '+text)
def click(text,bottom=False):tap(find(text,bottom))
def editors():
    for _ in range(8):
        found=sorted([n for n in nodes() if n.get('class')=='android.widget.EditText'],key=lambda n:rect(n)[1])
        if found:return found
        time.sleep(.2)
    raise RuntimeError('No current editable in active UI window')
def hide_ime():
    ime=adb('shell','dumpsys','input_method').decode(errors='replace')
    shown=re.search(r'(?m)^\s*mInputShown=(true|false)\b',ime)
    if shown is None:raise RuntimeError('No authoritative current IME visibility; no Back sent')
    if shown.group(1)=='true':adb('shell','input','keyevent','4')
def shot(name):
    nodes();(root/(name+'.xml')).write_bytes((root/'window.xml').read_bytes())
    (root/(name+'.png')).write_bytes(adb('exec-out','screencap','-p'))
def chord(key):adb('shell','input','keycombination','113',str(key))

if mode=='noop':
    click('回忆',True)
    e=editors();assert len(e)==1;tap(e[0]);chord(29);adb('shell','input','keyevent','67')
    adb('shell','input','text','Keyboard');hide_ime()
    find('Keyboard_return_sample');click('筛选');find('筛选回忆')
    assert editors()[0].get('text')=='' and editors()[1].get('text')==''
    click('应用');find('Keyboard_return_sample')
    assert editors()[0].get('text')=='Keyboard'
    shot('noop-apply')
    print('PASS: unchanged Apply keeps actual query and matching original')
elif mode=='query-history':
    tap(editors()[0]);chord(54);hide_ime()
    after=editors()[0].get('text');assert after!='Keyboard',after
    chord(53);hide_ime();assert editors()[0].get('text')=='Keyboard'
    shot('query-redo')
    (root/'query-history.json').write_text(json.dumps({'before':'Keyboard','after_undo':after,'after_redo':'Keyboard','events':'actual adb keycombination Ctrl+Z / Ctrl+Y'})+'\n')
    print('PASS: query real Ctrl+Z/Ctrl+Y works after unchanged Apply')
elif mode=='draft-history':
    click('筛选');find('筛选回忆');e=editors();assert len(e)>=2 and e[0].get('text')==''
    tap(e[0]);adb('shell','input','text','2026-11-05');hide_ime();assert editors()[0].get('text')=='2026-11-05'
    chord(54);hide_ime();after=editors()[0].get('text');assert after!='2026-11-05',after
    chord(53);hide_ime();assert editors()[0].get('text')=='2026-11-05'
    shot('draft-redo');click('取消');find('Keyboard_return_sample')
    assert editors()[0].get('text')=='Keyboard'
    click('筛选');find('筛选回忆');assert editors()[0].get('text')==''
    click('取消');find('Keyboard_return_sample');shot('cancel-restores-active-query')
    (root/'draft-history.json').write_text(json.dumps({'before':'2026-11-05','after_undo':after,'after_redo':'2026-11-05','reopened_after_cancel':'','active_query_after_cancel':'Keyboard','events':'actual adb keycombination Ctrl+Z / Ctrl+Y'})+'\n')
    print('PASS: private date history works and Cancel discards it without applying')
elif mode=='clear':
    click('筛选');click('更多查找设置');click('清空全部查找，包括搜索词')
    find('搜索回忆');assert editors()[0].get('text')=='';shot('cleared-search')
    print('PASS: explicit search clear restored empty query')
else:raise ValueError(mode)
