import sys, re, json, time
from pathlib import Path
from runpy import run_path

root = Path(__file__).resolve().parent
mode = sys.argv[1]
sys.argv = ['device.py', 'library']
api = run_path(str(root / 'device.py'))
adb = api['adb']
nodes = api['nodes']

def bounds(node): return tuple(map(int, re.findall(r'\d+', node.get('bounds'))))
def center(node):
    left, top, right, bottom = bounds(node)
    return str((left + right) // 2), str((top + bottom) // 2)
def visible(label, bottom=False):
    for _ in range(8):
        found = [n for n in nodes() if n.get('text') == label or n.get('content-desc') == label]
        if bottom and found: return max(found, key=lambda n: bounds(n)[1])
        if len(found) == 1: return found[0]
        time.sleep(.25)
    raise RuntimeError('Expected visible UI target: ' + label)
def click(label, bottom=False): adb('shell', 'input', 'tap', *center(visible(label, bottom)))
def shot(name):
    (root / (name + '.png')).write_bytes(adb('exec-out', 'screencap', '-p'))
    (root / (name + '.xml')).write_bytes((root / 'window.xml').read_bytes())

if mode == 'tasks':
    click('待办', bottom=True)
    visible('添加待办')
    print('Actual Tasks page ready')
elif mode.startswith('capture-'):
    name = mode.removeprefix('capture-')
    visible('添加待办')
    ns = nodes()
    parents = {child: parent for parent in ns for child in parent}
    label = next(n for n in ns if n.get('text') == '添加待办')
    button = label
    while button.get('clickable') != 'true': button = parents[button]
    lists = [n for n in ns if n.get('scrollable') == 'true' and n.get('package') == 'com.t1doo.aiyou']
    if not lists:
        # Android can mark a fitting LazyColumn non-scrollable. Find its actual
        # subtree from the More row and the task checkbox/empty-state descendants.
        more = next(n for n in ns if n.get('text') == '更多')
        ancestors = []
        while more in parents:
            more = parents[more]
            if any(c.get('class') == 'android.widget.CheckBox' or c.get('text') == '还没有正式待办' for c in more.iter('node')):
                ancestors.append(more); break
        assert ancestors, 'No actual task list subtree found'
        lists = ancestors
    assert len(lists) == 1
    viewport = bounds(lists[0]); control = bounds(button)
    assert viewport[0] <= control[0] < control[2] <= viewport[2], (viewport, control)
    assert viewport[1] <= control[1] < control[3] <= viewport[3], (viewport, control)
    assert control[3] - control[1] >= 144
    rows = []
    for checkbox in [n for n in ns if n.get('class') == 'android.widget.CheckBox']:
        title = checkbox.get('content-desc')
        row = checkbox
        while row in parents:
            row = parents[row]
            if any(c.get('text') == title for c in row.iter('node')): break
        rect = bounds(row); rows.append(rect)
        assert not (max(rect[0],control[0])<min(rect[2],control[2]) and
                    max(rect[1],control[1])<min(rect[3],control[3])), ('Create action covers a task row', rect, control)
    pets = [n for n in ns if n.get('content-desc') == '打开陪伴伙伴']
    assert len(pets) == 1
    shot(name)
    receipt = {'viewport': viewport, 'create_button': control, 'companion': bounds(pets[0]),
        'create_label': bounds(label),
        'visible_task_rows': rows,
        'font_scale': adb('shell', 'settings', 'get', 'system', 'font_scale').decode().strip(),
        'rotation': adb('shell', 'settings', 'get', 'system', 'user_rotation').decode().strip()}
    (root / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(receipt)
elif mode == 'landscape':
    adb('shell', 'settings', 'put', 'system', 'accelerometer_rotation', '0')
    adb('shell', 'settings', 'put', 'system', 'user_rotation', '1')
elif mode == 'large':
    adb('shell', 'settings', 'put', 'system', 'user_rotation', '0')
    adb('shell', 'settings', 'put', 'system', 'font_scale', '2.0')
elif mode == 'normal':
    original = json.loads((root / 'original-settings.json').read_text())
    value = original['font_scale']
    adb('shell', 'settings', 'delete' if value == 'null' else 'put', 'system', 'font_scale', *([] if value == 'null' else [value]))
elif mode == 'recap-open':
    click('回忆', bottom=True)
    visible('搜索回忆')
    click('更多')
    click('找回工具')
    click('生成本机日／周回顾')
    visible('返回回忆')
    print('Actual local recap route opened without generation')
elif mode == 'recap-return':
    click('回忆', bottom=True)
    visible('找回工具')
    ns = nodes()
    assert not any(n.get('text') == '找回与审阅' for n in ns)
    shot('memory-return')
    print('Caller tools visible after actual return; modal panel is closed')
elif mode == 'restore':
    original = json.loads((root / 'original-settings.json').read_text())
    for key, value in original.items():
        adb('shell', 'settings', 'delete' if value == 'null' else 'put', 'system', key, *([] if value == 'null' else [value]))
    after = {key: adb('shell', 'settings', 'get', 'system', key).decode().strip() for key in original}
    assert after == original, (original, after)
    (root / 'restored-settings.json').write_text(json.dumps(after, indent=2) + '\n')
    print('Original rotation and font settings restored:', after)
else: raise ValueError(mode)
